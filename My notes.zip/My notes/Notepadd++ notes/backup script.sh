$ cat /opt/app/t1enb1d4/oracle/local/bin/orarman
#!/bin/ksh
# Version: orarman,v 2.42
# $Id: orarman|3c39690 2016-02-15 10:01:05 -0600 Jim Thorn <jt7190@att.com> $
# Copyright 2001-2008 AT&T Intellectual Property. All rights reserved.
#-----------------------------------------------------------------------------
# Project Name : Oracle utilities
# Script Name  : orarman
# Language     : Korn Shell (ksh88, ksh93), and pdksh
# Support      : Send questions and/or issues to: dbascps@camail.sbc.com
# Description  : Script to drive Oracle RMAN command.
#
# Usage        : orarman -s OracleSid -c Command [-o CmdOption]
#                        [-v MediaVendor] [-t Type] [-l Level]
#                        [-n #Channels] [-f FilesPerSet]
#                        [-m MaxOpenFiles ] [-S Nd|Nh|Nm] [-T Tag]
#                        [-C ConfigDir] [-D] [-V]
#
#                Where:
#                  -s OracleSid     Oracle System Identifier name
#                  -s OracleSid     Oracle System Identifier name
#                  -c Command       Command to perform; CRCAT, REGDB, UNREGDB, RESYNCCAT,
#                                       BKUPDB, BKUPTS, BKUPARC, BKUPFRA, BKUPCTL,
#                                       CHGARCXCHK, SHOWALL, DELOBSOLETE, DELEXPIRED,
#                                       MONFRA, RESTOREVAL
#                  -o CmdOption     Command specific options;
#                                       BKUPARC      : FORCE|ALLARC
#                                       DELOBSOLETE  : FORCE
#                                       BKUPDB|BKUPTS: VALIDATE
#                                       BKUPDB       : CLONE|NOCLONE|PROXY|NOPROXY
#                  -v MediaVendor   Media Manager Vendor Product; TSM,
#                                   NETBACKUP, AVAMAR, DDBOOST or NONE (Disk)
#                  -t Type          Type of DB backup; ONLINE or OFFLINE
#                  -l Level         Backup Level; FULL or 0-4
#                  -n #Channels     Number of Channels
#                  -f FilesPerSet   Number of FilesPerSet
#                  -m MaxOpenFiles  Number of MaxOpenFiles
#                  -S N             Nd - days, Nh - hours, or Nm - minutes to skip
#                                   backing up recently backed up data files,
#                                   or recently archived redo log files
#                  -T Tag           Tag used to make Patrol notification unique
#                                   when using multiple backups per instance
#                  -C ConfigDir     is an alternate configuration directory
#                                   to look for configuration files in.
#                                   Defaults: 1: /opt/app/VTIER/oracle/local/etc
#                                             2: /var/opt/oracle
#                  -D               Turn on Debug mode for script
#                  -V               Turn on Verbose mode for the script.
#
#                Notes:
#                   1)  Where it makes sense, command line options are case
#                       insensitive, e.g. "BKUPDB is the same as "bkupdb"
#
# Dependencies : This script depends on the following scripts which must be installed in
#                Oracle's Local Bin, a.k.a. LOCAL_BASE/bin.
#
#                oraprof      - Set the Oracle Instance's Environment Variables
#
#                oranotify    - Handle any notification messages in a consistant manner
#
# Configuration: Valid files include only the following, no other files are
#                read by this script.
#
#                  CONFIG_DIR/global.cfg
#                  CONFIG_DIR/owner_${LOGNAME}.cfg         -or- CONFIG_DIR/global_${LOGNAME}.cfg
#                  CONFIG_DIR/instance_${ORACLE_SID}.cfg   -or- CONFIG_DIR/${ORACLE_SID}.cfg
#
# Parameters   : All configuration file parameters supported by this script.
#               RMAN_FRA_ACTIVE             = 0,off,no,false | 1,on,yes,true
#               RMAN_FRA_FULL_PCT           = [ FRA pct full to initiate FRA backup]
#               RMAN_CAT_ACTIVE             = 0,off,no,false | 1,on,yes,true
#               RMAN_CAT_ALIAS              =
#               RMAN_CAT_PASSWORD           =
#               RMAN_CAT_SCHEMA             =
#               RMAN_ARC_ALARM_FREEKB       =
#               RMAN_ARC_BKUP_FREEKB        =
#               RMAN_ARC_INCLUDE            = 0,off,no,false | 1,on,yes,true
#               RMAN_DBF_BKUP_TYPE          = [online|offline]
#               RMAN_DBF_BKUP_USER_BEGIN    = user_begin_exit_script
#               RMAN_DBF_BKUP_USER_FAIL     = user_fail_exit_script
#               RMAN_DBF_BKUP_USER_SUCCESS  = user_success_exit_script
#               RMAN_DBF_LEVEL              = [full|0|1]
#               RMAN_DBF_INCR_TYPE          = [d|c]
#               RMAN_TABLESPACE             = tablespace_name
#               RMAN_FAILURE_SEVERITY       = [critical|warning]
#               RMAN_MEDIA_VENDOR           = [none|netbackup|tsm|ddboost]
#               RMAN_ARC_BKUPDIR            = archive_log_backup_dir_list
#               RMAN_DBF_BKUPDIR            = database_file_backup_dir_list
#               RMAN_SPFILE_BKUP_DIR        =
#               RMAN_CHANNEL_TYPE           = [disk|sbt_tape]
#               RMAN_ARC_CHANNEL_TYPE       = [disk|sbt_tape]
#               RMAN_DBF_CHANNEL_TYPE       = [disk|sbt_tape]
#               RMAN_CHANNEL_COUNT          =
#               RMAN_ARC_CHANNEL_COUNT      =
#               RMAN_DBF_CHANNEL_COUNT      =
#               RMAN_FILESPERSET            = see RMAN doc for FILEPERSET
#               RMAN_ARC_FILESPERSET        = "
#               RMAN_DBF_FILESPERSET        = "
#               RMAN_MAXOPENFILES           = see RMAN doc for MAXOPENFILES
#               RMAN_ARC_MAXOPENFILES       = "
#               RMAN_DBF_MAXOPENFILES       = "
#               RMAN_MAXSETSIZE             = see RMAN doc for MAXSETSIZE
#               RMAN_ARC_MAXSETSIZE         = "
#               RMAN_DBF_MAXSETSIZE         = "
#               RMAN_SECTIONSIZE            = see RMAN doc for SECTION SIZE
#               RMAN_DBF_SECTIONSIZE        = "
#               RMAN_RATE                   = see RMAN doc for RATE
#               RMAN_ARC_RATE               = "
#               RMAN_DBF_RATE               = "
#               RMAN_BLKSIZE                = see RMAN doc for BLKSIZE
#               RMAN_SBT_LIBRARY            = see RMAN doc for SBT_LIBRARY
#               RMAN_FIX_AIX_SBT_LIBRARY    = 0,off,no,false | 1,on,yes,true
#               RMAN_CMD_DEBUG              = 0,off,no,false | 1,on,yes,true
#               RMAN_CMD_DEBUG_LEVEL        = n
#               RMAN_POST_RUN_SQL           = SQL command to execute after run command
#
#               Run the delete obsolete using command line options as a separate daily cron job
#               RMAN_DELOBSOLETE_RUN        = 0,off,no,false | 1,on,yes,true
#               RMAN_DELOBSOLETE_FORCE      = 0,off,no,false | 1,on,yes,true
#               RMAN_DELOBSOLETE_RECOVERY_WINDOW_CHK = 0,off,no,false | 1,on,yes,true
#
#               RMAN_NB_ORA_CLIENT          =
#               RMAN_NB_ORA_SERV            =
#               RMAN_ARC_NB_ORA_POLICY      =
#               * RMAN_ARC_NB_ORA_CLASS     = Replaced by Policy in NBU 4.5, but still works
#               RMAN_ARC_NB_ORA_SCHED       =
#               RMAN_DBF_NB_ORA_POLICY      =
#               * RMAN_DBF_NB_ORA_CLASS     = Replaced by Policy in NBU 4.5, but still works
#               RMAN_DBF_NB_ORA_SCHED       =
#
#               RMAN_DBF_PROXY_COPY         = 0,off,no,false | 1,on,yes,true
#               RMAN_DBF_NB_ORA_PC_STREAMS  = see NetBackup doc for NB_ORA_PC_STREAMS
#               RMAN_DBF_NB_ORA_PC_SCHED    = see NetBackup doc for NB_ORA_PC_SCHED
#
#               RMAN_DBF_CLONE              = Set to True for Storage Based Clone Backup
#               RMAN_TDPO_OPTFILE           =
#
#               RMAN_LOG_DIR                =
#               RMAN_FILENAME_FORMAT        = SIMPLE        # Use old style names
#               RMAN_DEBUG                  = 0,off,no,false | 1,on,yes,true
#               RMAN_VERBOSE                = 0,off,no,false | 1,on,yes,true
#               LOCAL_BIN                   =
#               LOG_DIR                     =
#               DEBUG                       = 0,off,no,false | 1,on,yes,true
#               VERBOSE                     = 0,off,no,false | 1,on,yes,true
#               RMAN_BKUPFRA_NOEMAIL        = 0 #default
#
#               PATROL_START_NOTIFY         = script notifying patrol of start
#               PATROL_END_NOTIFY           = script notifying patrol of end
#
#               RMAN_ARC_DEST_DIR           = destination of archivelogs to be backed up and
#                                             deleted.  For example, used by GoldenGate installations
#                                             which keep a seperate archivelog destinations.
#
#               RMAN_EDS_LOGGER               = 0,off,no,false | 1,on,yes,true
#               RMAN_CHECK_LOGICAL_CORRUPTION = 0,off,no,false | 1,on,yes,true
#                                               Used to turn on "check logical" during backup command.
#               RMAN_ARC_EMAIL                = email successful message for BKUPARC job.
#               RMAN_AVAMAR_AVTAR_FILE        = Avamar config file
#
#               RMAN_DDBOOST_STORAGE
#               RMAN_DDBOOST_BKUP_HOST
#               RMAN_DG_2ND_ORACLE_SID        = set to 2nd Oracle SID needed for RESTORE Validate function
#               RMAN_DG_2ND_AVAMAR_AVTAR_FILE = set to 2nd avtar flags file for 2nd Oracle SID for RESTOERvAL.
#               RMAN_Check_Prev_L0_Bkup       =
#               RMAN_BKUPFRA_USE_ARCH_POLICY  = defaults to false, but if set to true will use the
#                                               NBU policy for _ARCH for the BKUPFRA job.
#               RMAN_BYPASS_EBR_VIP_CHECK     = defaults to FALSE, if set to TRUE, then RAC backup jobs will
#                                               allow the BKUPDB job to FRA to run on a RAC node where the
#                                               EBR vip is not running, since this type of backup will be
#                                               backing up to local disk.
#
#-----------------------------------------------------------------------------
# Revision History: At end of script
#-----------------------------------------------------------------------------
set +u

# Default PATH
export PATH=/usr/bin:/bin

# Set Default permissions
umask 022

# Determine the some commands based on the Platform
OSName=`uname -s 2>/dev/null| tr '[:lower:]' '[:upper:]'`
case ${OSName} in
        "AIX")
                ID="/usr/bin/id"
                AWK="/usr/bin/awk"
                DF="/usr/bin/df -kP"
                MAIL="/usr/bin/mailx"
                PING="/usr/sbin/ping"
                PS="/usr/bin/ps -o user=LONGUSERNAME -o pid,ppid,pcpu,start,tty,time,args"
                if [[ "$(uname -v)$(uname -r)" > "52" ]]
                then
                        LS="/usr/bin/ls -X"
                else
                        LS="/usr/bin/ls"
                fi
                SHELL="/usr/bin/ksh"
                export AIXTHREAD_SCOPE="S"
                ;;
        "HP-UX")
                ID="/usr/bin/id"
                AWK="/usr/bin/awk"
                DF="/usr/bin/df -kP"
                MAIL="/usr/bin/mailx"
                PING="/usr/sbin/ping"
                PS="env UNIX95=1 /usr/bin/ps -x -o user=LONGUSERNAME -o pid,ppid,cpu,stime,tty,time,args"
                LS="/usr/bin/ls"
                SHELL="/usr/bin/ksh"
                ;;
        "LINUX")
                ID="/usr/bin/id"
                AWK="/bin/awk"
                DF="/bin/df -kP"
                MAIL="/bin/mail"
                PS="/bin/ps -w o user=LONGUSERNAME -o pid,ppid,pcpu,start,tty,time,args"
                PING="/bin/ping"
                LS="/bin/ls"
                SHELL="/bin/bash --posix"
                ;;
        "SUNOS")
                ID="/usr/xpg4/bin/id"
                AWK="/usr/bin/nawk"
                DF="/usr/bin/df -k"
                MAIL="/usr/bin/mailx"
                PING="/usr/sbin/ping"
                PS="/usr/bin/ps -o user=LONGUSERNAME -o pid,ppid,pcpu,stime,tty,time,args"
                LS="/usr/bin/ls"
                SHELL="/usr/bin/ksh"
                ;;
        *)
                echo "ERROR: This Operating System is Not Supported: ${OSName}" >&2
                exit 1
                ;;
esac

# Script Name
ScriptName=$(basename ${0})

# Current host name
HostName=$(uname -n)

# Current users name
UserName=$(${ID} -un)

# Current users Home Directory
UserHome=$(eval echo ~${UserName})

# Start Date and time stamps
DateTime="$(date +'%m%d%y_%H%M%S')"

# Current Process ID
Pid=${$}

# Define Boolean True
True="1"

# Define Boolean False
False="0"

if [[ -n ${DEBUG} ]]
then
        Debug=${True}
        DebugOpt="-D"
        set -xv
else
        Debug=${False}
        DebugOpt=""
fi

if [[ -n ${VERBOSE} ]]
then
        Verbose=${True}
        VerboseOpt="-V"
else
        Verbose=${False}
        VerboseOpt=""
fi

# vTier Setup
if [[ -d /opt/app/${UserName}/oracle/local/etc ]]
then
        VTierTop=/opt/app
elif [[ -d /pac ]]
then
        VTierTop=/pac
fi

# Script Defaults
if [[ -n ${VTierTop} ]] && [[ -d ${VTierTop}/${UserName} ]]
then
        export LOCAL_BASE=${VTierTop}/${UserName}/oracle/local
        ConfigDir=${LOCAL_BASE}/etc
else
        export LOCAL_BASE=${UserHome}/local
        ConfigDir=/var/opt/oracle
fi

LocalBin=${LOCAL_BASE}/bin
LockDir=${LOCAL_BASE}/locks
LogDir=${LOCAL_BASE}/log
TmpDir=${LOCAL_BASE}/tmp

NotifyCmd="oranotify"

# Pass this option on to other scripts, so that they inherit same features
ConfigDirOpt="-C ${ConfigDir}"

typeset -u FailureSeverity="CRITICAL"

# Following 2 parameters set up as default values for sending email reports for ARTT
NotifyEmailMonitor="oracle@bkuptrack.sbc.com"
NotifyEmailMonitor_Flag=${True}

#-----------------------------------------------------------------------------
# Function   : CycleAvamarLog
# Description: Cycle avamar.log file to avamar.log.MMYY format.  This will allow
#               maintenance jobs to remove the older files based last update time.
#----------------------------------------------------------------------------
function CycleAvamarLog
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: CycleAvamarLog${*}" >&2

        cur_mmyy=`date +"%m%y"`
        file_mmyy="FirstCycle"
#       echo "cur_mmyy=$cur_mmyy"
        if [[ -f ${LogDir}/CurrentMonth.log ]]
        then
#               echo "checking CurrentMonth.log if current.."
                file_mmyy=`cat ${LogDir}/CurrentMonth.log`
                cat ${LogDir}/CurrentMonth.log|grep $cur_mmyy >/dev/null
                mmyy_status=${?}
#               echo "mmyy_status=$mmyy_status"
        else
                echo "${LogDir}/CurrentMonth.log does not exist"
                echo "Creating initial CurrentMonth.log file"
                echo $cur_mmyy >${LogDir}/CurrentMonth.log
                mmyy_status=0
        fi
        if [[ ${mmyy_status} -eq 1 ]]
        then
                echo "Month changed, cycle avamar log file..."
                AvamarLogFile=`grep "logfile=" ${LOCAL_BASE}/etc/${AvamarAvtarFile}| awk -F'=' '{print $2}'  `
#               echo "AvamarLogFile=$AvamarLogFile"
                if [[ -f ${AvamarLogFile}${file_mmyy}.Z ]] then
                        rm ${AvamarLogFile}${file_mmyy}.Z
                fi
                mv -f ${AvamarLogFile} ${AvamarLogFile}${file_mmyy}
                compress ${AvamarLogFile}${file_mmyy}
#               echo "cur_mmyy=$cur_mmyy"
                echo $cur_mmyy >${LogDir}/CurrentMonth.log
        fi

}


#-----------------------------------------------------------------------------
# Function   : ReportToBkupMonitor
# Description: Email will be sent to report SUCCESSFUL backups only to a
#              RMAN .cfg Parameters:
#                RMAN_NOTIFY_EMAIL_MONITOR - if not set in .cfg file, defaults to
#                                       oracle@bkuptrack.sbc.com.
#                RMAN_NOTIFY_EMAIL_MONITOR_FLAG - defaults to true, if not set in
#                                       .cfg file.
#----------------------------------------------------------------------------
function ReportToBkupMonitor
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ReportToBkupMonitor ${*}" >&2

        typeset MsgSev MsgText MsgFile MsgFileOpt

        Service=${ORACLE_SID-unknown}

        # Message Severity
        MsgSev="${1}"

        # Message Text
        MsgText="${2}"

        # Message File
        MsgFile="${3}"

        whence sh > /dev/null 2>&1
        if (( ${?} == 0 ))
        then
                WHENCE="whence"
        else
                WHENCE="type -p"
        fi
        ${WHENCE} "mailx" > /dev/null 2>&1
        if (( ${?} == 0 ))
        then
                DefaultEmailCmd=mailx
        else
                ${WHENCE} "mail" > /dev/null 2>&1
                if (( ${?} == 0 ))
                then
                        DefaultEmailCmd=mail
                else
                        DefaultEmailCmd=unknown
                fi
        fi
        EmailCmd="${NotifyEmailCmd-${DefaultEmailCmd}}"

        ${WHENCE} "${EmailCmd}" > /dev/null 2>&1
        if (( ${?} != 0 ))
        then
                ReportMsg "ERROR" "Email Command: ${EmailCmd} Not Found!"
                return
        fi

        echo ${MsgText}| grep "SUCCESS"  >/dev/null 2>&1
        ExitStatus=${?}


        if [[ ${NotifyEmailMonitor_Flag} = ${True} && -n ${NotifyEmailMonitor} && -f ${MsgFile} ]] && (( ${ExitStatus} == 0 ))
        then
                print "Emailing to DB Backup Monitoring ${NotifyEmailMonitor}"
                ${EmailCmd} -s "${HostName}:${ScriptName}:${Service}: ${MsgText}" ${NotifyEmailMonitor} <${MsgFile}
        fi
        return
}


#-----------------------------------------------------------------------------
# Function   : ReportMsg
# Description: Handle all the reporting/logging of messages and errors
#              based on a severity level assigned to it.
#----------------------------------------------------------------------------
function ReportMsg
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ReportMsg ${*}" >&2

        typeset MsgSev MsgText MsgFile MsgFileOpt backup_status

        Service=${ORACLE_SID-unknown}

        # Message Severity
        MsgSev="${1}"

        # Message Text
        MsgText="${2}"

        # Message File
        MsgFile="${3}"

        if [[ -f ${MsgFile} ]]
        then
                MsgFileOpt="-f ${MsgFile}"
        fi
        if [[ -n ${MsgSev} ]]
        then
                print "${MsgSev}: ${ScriptName}: ${Service}: ${MsgText}" >&2
                if [[ -x ${LocalBin}/${NotifyCmd} ]]
                then
                    if  [[ ${Command} != "BKUPFRA" ]] ||
                        [[ ${Command}  = "BKUPFRA" && ${FRANoEmail} != ${True} ]]
                    then
                        ${LocalBin}/${NotifyCmd} -s ${Service} -l ${MsgSev} -n ${ScriptName} -m "${MsgText}" ${MsgFileOpt} ${ConfigDirOpt} ${DebugOpt} ${VerboseOpt}
                    fi
                fi
                # Call function to send data to Backup Monitor Process
                ReportToBkupMonitor "${MsgSev}" "${MsgText}" "${MsgFile}";
        else
                print "${ScriptName}: ${MsgText}" >&2
        fi

        if [[ -n ${MsgSev} && -f ${LogFile} ]]
        then
                print "${MsgSev}: ${ScriptName}: ${Service}: ${MsgText}" >> ${LogFile}
        elif [[ -f ${LogFile} ]]
        then
                print "${ScriptName}: ${Service}: ${MsgText}" >> ${LogFile}
        fi

        if [[ ${MsgSev} = "WARNING" ]]
        then
                MsgWarning=", with Warnings"
        fi

#       echo "MsgSev=${MsgSev}"
#       echo "Command=${Command}"
#       echo "BkupValidate=${BkupValidate}"

        #
        #        Use LOGGER message to write to Alert Log file.
        #
        if [[ ${MsgSev} = "LOGGER" ]] &&
           [[ ${Command} = "BKUPDB"  || ${Command} = "BKUPFRA" || ${Command} = "BKUPARC" ]] &&
           [[ ${BkupValidate} != ${True} ]]
        then

#               echo "MsgText=${MsgText}"

                echo ${MsgText}| grep "SUCCESS"  >/dev/null 2>&1
                FoundStatus=${?}
                if (( ${FoundStatus} == 0 ))
                then
                        backup_status="SUCCESS"
                fi

                echo ${MsgText}| grep "FAIL"  >/dev/null 2>&1
                FoundStatus=${?}
                if (( ${FoundStatus} == 0 ))
                then
                        backup_status="FAILED"
                fi

                if [[ -z ${backup_status} ]]
                then
                        echo "LOGGER information is not sent because status is not SUCCESS or FAILURE"
                        return;
                fi
        #
        #       Report to Oracle Alert Log
        #
                # Derive the Major version of the Oracle Software
                #
                oracle_major_vers=`ls -1 ${ORACLE_HOME}/lib/libcommon*.* 2>/dev/null | head -1 | sed -e 's/.*libcommon//' -e 's/\..*//'`
                if [ -z "${oracle_major_vers}" ]
                then
                        oracle_major_vers=0
                fi

                if [ ${oracle_major_vers} -gt 10 ]
                then
                        SqlConnect="/ as sysdba"
                        SqlCommand="select 'Cmd1:'||value from v"'$diag_info'" where name ='Diag Trace';"
                        RunSql "${SqlCommand}"
                        SqlError=${?}
                        if (( ${SqlError} != 0 ))
                                then
                                ReportMsg "" "Database connection failed, or SQL command failed!"
                                ReturnCode=1
                        fi
                        export AlertLogDir=$(grep "^Cmd1:" ${TmpFile1} | awk -F':' '{print $2}')
                        Alert_Log="${AlertLogDir}/alert_${OracleSid}.log"
                else
                        SqlConnect="/ as sysdba"
                SqlCommand="select 'Cmd1:'||value from v"'$parameter'" where name ='user_dump_dest';"
                        RunSql "${SqlCommand}"
                        if (( ${SqlError} != 0 ))
                                then
                                ReportMsg "" "Database connection failed, or SQL command failed!"
                                ReturnCode=1
                        fi
                        export AlertLogDir=$(grep "^Cmd1:" ${TmpFile1} | awk -F':' '{print $2}')
                        Alert_Log="${AlertLogDir}/alert_${OracleSid}.log"
                fi
#               echo "Alert_log=${Alert_Log}"
                LevelString=""
                if [[ ${DbfLevel} = "0" ]] || [[ ${DbfLevel} = "1" ]]
                then
                        LevelString="Level ${DbfLevel}"
                fi
                if [[ ${backup_status} = "SUCCESS" ]]
                then
                        print "Function: orarman - SID:${OracleSid} ${Command} ${LevelString} SUCCESSFUL at $(date +'%m-%d-%y_%H:%M:%S')"
                        if [ -r ${Alert_Log} ]
                        then
                                print "Function: orarman - SID:${OracleSid} ${Command} ${LevelString} SUCCESSFUL at $(date +'%m-%d-%y_%H:%M:%S')" >>${Alert_Log}
                        fi

                elif [[ ${backup_status} = "FAILED" ]]
                then
                        print "Function: orarman - SID:${OracleSid} ${Command} ${LevelString} FAILED at $(date +'%m-%d-%y_%H:%M:%S')"
                        if [ -r ${Alert_Log} ]
                        then
                                print "Function: orarman - SID:${OracleSid} ${Command} ${LevelString} FAILED at $(date +'%m-%d-%y_%H:%M:%S')" >>${Alert_Log}
                        fi
                fi
        fi
        return

} # End of ReportMsg


#-----------------------------------------------------------------------------
# Name: ShowUsage
# Desc: Print usage syntax.
#-----------------------------------------------------------------------------
function ShowUsage
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ShowUsage ${*}" >&2

        print "\nUSAGE: ${ScriptName} -s OracleSid -c Command [-o CmdOption] [-v MediaVendor]" >&2
        print "       [-t Type] [-l Level] [-i D|C] [-n #Channels] [-f FilesPerSet]" >&2
        print "       [-m MaxOpenFiles] [-S Nd|Nh|Nm] [-T Tag] [-C ConfigDir] [-D] [-V]" >&2
        print "\n   Where:" >&2
        print "      -s OracleSid     Name of the Oracle System Identifier" >&2
        print "      -c Command       Command to perform; CRCAT, REGDB, UNREG, RESYNCCAT, BKUPDB," >&2
        print "                           BKUPTS, BKUPARC, BKUPFRA, BKUPCTL, CHGARCXCHK," >&2
        print "                           SHOWALL, DELOBSOLETE, DELEXPIRED, MONFRA, RESTOREVAL" >&2
        print "                           (RESTOREVAL should only be run to test new installs)" >&2
        print "      -o CmdOption     Command specific options;" >&2
        print "                           BKUPARC       : FORCE|ALLARC" >&2
        print "                           DELOBSOLETE   : FORCE" >&2
        print "                           BKUPDB|BKUPTS : VALIDATE" >&2
        print "                           BKUPDB        : CLONE|PROXY|NOPROXY" >&2
        print "      -v MediaVendor   Media Manager Vendor; TSM, NETBACKUP, AVAMAR, DDBOOST or" >&2
        print "                           NONE (Disk)" >&2
        print "      -t Type          Type of DB backup; ONLINE/HOT or OFFLINE/COLD" >&2
        print "      -l Level         Backup Level; FULL or 0-4" >&2
        print "      -i D|C           Incremental Type Differential or Cumulative; D or C" >&2
        print "      -n #Channels     Number of Channels" >&2
        print "      -f FilesPerSet   Number of FilesPerSet" >&2
        print "      -m MaxOpenFiles  Number of MaxOpenFiles" >&2
        print "      -S N             Nd - days, Nh - hours, or Nm - minutes to skip" >&2
        print "                           backing up recently backed up data files," >&2
        print "                           or recently archived redo log files" >&2
        print "      -T Tag           Tag to make backup unique for Patrol" >&2
        print "      -C ConfigDir     Alternate configuration file directory," >&2
        print "                           default = /var/opt/oracle" >&2
        print "      -D               Turn on Debug mode for script" >&2
        print "      -V               Turn on Verbose mode for the script" >&2
        print "\n   Notes:" >&2
        print "      1)  Where it makes sense, command line options are case insensitive," >&2
        print "              e.g. \"BKUPDB\" is the same as \"bkupdb\"" >&2
        print "\n   Version: $ScriptId \n" >&2
        print "\n" >&2

        return

} # End of ShowUsage

#-----------------------------------------------------------------------------
# Function   : RAC_Check
# Description: This function will run RAC prechecks:
#               - Is RAC cluster vip online on this server
#               - Is NB_ORA_CLIENT pingable.
#              If it fails orarman scripts will stop and send email.
#----------------------------------------------------------------------------
function RAC_Check
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: RAC_Check ${*}" >&2

        typeset ReturnCode=0
        typeset status=0


#
#       If this is not running RAC, exit routine.
#
        SqlConnect="/ as sysdba"
        SqlCommand="select 'Cmd1:'||upper(rpad(value,5)) from v"'$parameter'" where name ='cluster_database';"
        RunSql "${SqlCommand}"
        SqlError=${?}
        if (( ${SqlError} != 0 ))
        then
                ReportMsg "" " Parameter cluster_database parameter check Failed, or SQL command failed!"
                ReturnCode=1
        fi
        export ClusterDatabase=$(grep "^Cmd1:" ${TmpFile1} | awk -F':' '{print $2}')
        if  [[ ${ClusterDatabase} != "TRUE" ]]
        then
#               echo 'This is not a RAC DB'
                return 0;
        fi

        if [[ ${MediaVendor} != "NETBACKUP" && ${MediaVendor} != "AVAMAR" ]]
        then
                print "function RAC_Check can only be called if rman_media_vendor = "NETBACKUP" or "AVAMAR", backup will stop."
                ReportMsg "${FailureSeverity}"  "function RAC_Check can only be called if rman_media_vendor = "NETBACKUP" or "AVAMAR", backup will stop."
                return 1
        elif [[ -z ${NB_ORA_CLIENT} && ${MediaVendor} = "NETBACKUP" ]]
        then
                print "RMAN_NB_ORA_CLIENT $NB_ORA_CLIENT is not defined,  backup will stop"
                ReportMsg "${FailureSeverity}"  "RMAN_NB_ORA_CLIENT $NB_ORA_CLIENT is not defined, backup will stop."
                return 1
        elif [[ ${MediaVendor} = "AVAMAR" ]]
        then
                if [[ ! -f  ${LOCAL_BASE}/etc/${AvamarAvtarFile}  ]]
                then
                        print "Avamar Flags file - ${LOCAL_BASE}/etc/${AvamarAvtarFile} does not exist, backup will stop."
                        ReportMsg "${FailureSeverity}"  "Avamar Flags file - ${LOCAL_BASE}/etc/${AvamarAvtarFile} does not exist, backup will stop."
                        return 1
                fi
                grep "path=" ${LOCAL_BASE}/etc/${AvamarAvtarFile} > ${TmpFile9} 2>&1
                status=$?
                if [[ ${status} -ne 0 ]]
                then
                        print "PATH variable not found in Avamar Flags file,  backup will stop"
                        ReportMsg "${FailureSeverity}"  "PATH variable not found in Avamar Flags file,  backup will stop."
                        return 1
                fi
                unset avamar_vip;
                let i=0;
                while [ -z ${avamar_vip} ]  && (( ${i} < 10 ))
                do
                        let i=$i+1;
                        cut -d/ -f$i ${TmpFile9}  > ${TmpFile10}
                        grep -i "ebr" ${TmpFile10} >${TmpFile11} 2>&1
                        status=$?
                        if [[ ${status} -eq 0 ]]
                        then
                                avamar_vip=`cat ${TmpFile11}`
                        fi
                done
                crs_ebr_vip=${avamar_vip%%.*}

                if [ -z ${crs_ebr_vip} ]
                then
                        print "PATH variable expected an EBR vip, but not found in Avamar Flags file,  backup will stop"
                        ReportMsg "${FailureSeverity}"  "PATH variable expected an EBR vip, but not found in Avamar Flags file,  backup will stop."
                        return 1
                fi
        elif [[ ${MediaVendor} = "NETBACKUP" ]]
        then
                crs_ebr_vip=${NB_ORA_CLIENT%%.*}
        fi
        if [[ -f /opt/app/oragrid/oracle/product/grid/bin/crsctl ]]
        then
                /opt/app/oragrid/oracle/product/grid/bin/crsctl status resource ${crs_ebr_vip}|grep "STATE=ONLINE" >${TmpFile7} 2>&1
                status=$?
                # if CRS service running
                if [[ ${status} -eq 0 ]]
                then
                        grep $HostName ${TmpFile7} >/dev/null
                        status=$?
                        # if CRS service not running on local node
#                       cat ${TmpFile7}
                        if [[ ${status} -ne 0 ]]
                        then
                                print "RAC cluster vip ${crs_ebr_vip} not running on this server, backup will stop. RAC cluster vip current `cat ${TmpFile7}`"
                                print "RAC cluster vip ${crs_ebr_vip} not running on this server, backup will stop. RAC cluster vip current `cat ${TmpFile7}`" >> ${LogFile} 2>&1
                                exit;
                        fi
#               else
#                        print "RAC cluster vip ${crs_ebr_vip} not running on RAC Cluster"
#                        print "RAC cluster vip ${crs_ebr_vip} not running on RAC Cluster" >> ${LogFile} 2>&1
#                        return 1

                fi
        fi

        #
        # Check to make sure we can find ping before executing  - we don't want a ping error stopping the backupj
        #
# pulling ping enhancement out of release, not enough time to test on all OSs.
#
# Notes:  PING path is set in the top of this program.
#
#       Syntax is different:  HP: ping <node> -n 1
#                            AIX/LINUX: ping -c 1 <node>
#                            Solaris:  ping -c 1 <node> works because "-c 1" is ignored.  But need to investigate.
#                            HPUX:    ping <node> -n 1
#
#       #echo "b-testing with ping ${Command}"
#       #echo "b-ChanType=${ChanType}"
#
#       if [[ ${ChanType} = "SBT_TAPE" ]] &&
#           [[ ${Command} = "BKUPDB" || ${Command} = "BKUPTS" || ${Command} = "BKUPARC" || ${Command} = "BKUPCTL" ]]  ||
#          [[ ${Command} = "BKUPFRA" ]]
#       then
#
#               whence sh > /dev/null 2>&1
#               if (( ${?} == 0 ))
#               then
#                       WHENCE="whence"
#               else
#                       WHENCE="type -p"
#               fi
#               ${WHENCE} "ping" > /dev/null 2>&1
#               if (( ${?} == 0 ))
#               then
#                       ping -c 1 ${NB_ORA_CLIENT} 2>&1 >/dev/null
#                       status=$?
#                       if [[ ${status} -ne 0 ]]
#                       then
#                               ReturnCode=1
#                               print "RMAN_NB_ORA_CLIENT $NB_ORA_CLIENT is not pingable, backup will stop"
#                               ReportMsg "${FailureSeverity}"  "RMAN_NB_ORA_CLIENT $NB_ORA_CLIENT is not pingable, backup will stop."
#                       fi
#               else
#                       ${WHENCE} ${PING} > /dev/null 2>&1
#                       if (( ${?} == 0 ))
#                       then
#                               ${PING} -c 1 ${NB_ORA_CLIENT} 2>&1 >/dev/null
#                               status=$?
#                               if [[ ${status} -ne 0 ]]
#                               then
#                                       ReturnCode=1
#                                       print "RMAN_NB_ORA_CLIENT $NB_ORA_CLIENT is not pingable, backup will stop"
#                                       ReportMsg "${FailureSeverity}"  "RMAN_NB_ORA_CLIENT $NB_ORA_CLIENT is not pingable, backup will stop."
#                               fi
#                       else
#                               print 'WARNING-No Ping check on the NB_ORA_CLIENT' >> ${LogFile} 2>&1
#                       fi
#               fi
#       fi
        return ${ReturnCode};
} # end of RAC_Check


#-----------------------------------------------------------------------------
# Function   : EDS_Report
# Description: Handles existing EDS/Bellsouth installations and puts entries in
# EDS table, if it exists.
#
#----------------------------------------------------------------------------
function EDS_Report
{
        typeset -u action=${1}
        if (( ${EDSLogger} ))
        then
                echo "Executing EDS Logging $action"
                if [[ ${action} = "START" ]]
                then
                        SqlConnect="/ as sysdba"
                        SqlCommand="execute eds_reports.startbk('RMAN','HOT','DISK','N/A');"
                        RunSql "${SqlCommand}"
                        SqlError=${?}
                elif [[ ${action} = "END" ]]
                then
                        SqlConnect="/ as sysdba"
                        SqlCommand="execute eds_reports.endbk('N/A',0,0);"
                        RunSql "${SqlCommand}"
                        SqlError=${?}
                else
                        ReturnCode=1
                fi
                if (( ${SqlError} != 0 ))
                then
                        ReportMsg "" "Database connection failed, or SQL command failed!"
                        ReturnCode=1
                fi
        fi
}

#-----------------------------------------------------------------------------
# Function   : ChkAvamarFlagsFile
# Desciption : Check current avagent.log file to see if the variables from
#              a "grep" command is the same as in the avamar flags file.  If
#              not, then update the avamar flags file.
# Logic for Avamar flags file update: (updated 2/15/16)
#
# 1)    If avagent.log file not readable -> Exit
# 2)    Read avagent.log file and get following values:
#        AvGridName, Avamar PATH
# 3)    Determine TargetEnv, Target Deploy based on Avamar PATH
#       CLOUD Automation has two domains
#       A)   /Cloud/Cloud_unix (production servers)
#       B)    /Cloud/Cloud_unix_nonprod (test/dev servers)
#       Manual Installs or other Automation outside Cloud
#       A)   /unix/unix (production servers)
#       B)    /unix/unix_nonprod (test/dev/servers)
# 4)    Determine the size of the database, which will be passed into the Avamar API
# 5)    Call Avamar API and expect 1 row returned, if no row, contine and
#       try to read /var/avamar/${ORACLE_SID}_dd.cfg, to override ddr and ddr-index
#       values.  This is managed by the EBR team. if file is found or not found continue,
#       because we can still have a path variable change based on avagent.log file read.
# 6)    If a single record is returned from Avamar API, compare the following values with the values
#       in the current Avamar flags file:
#
#       AvGridName(if RAC), Avamar PATH, DDR or DDRIndex.
#
#       if any have changed copy the old flags file to a new file, and create a new flags
#       with the correct values. Possible update to flags file include:
#               --server  ( if RAC only)
#               --ddr
#               --ddr-index
#               --path
# 7)    If no rows found in Avamar API, and ${ORACLE_SID}_dd.cfg found, check ddr and ddr-index
#       values in flags file.
# 8)    If no API rows and no ${ORACLE_SID}_dd.cfg found, continue and check the path varidable in the flags file.
# 9)    Email the DBA of changes, and update the output log of changes.
# 10)   Exit function and continue with the RMAN  backup.
#
#----------------------------------------------------------------------------
function ChkAvamarFlagsFile
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ChkAvamarFlagsFile${*}" >&2
        typeset ReturnCode=0
        typeset status=0
        AvamarPathChg=${False}
        RAC_Database=${False}
        StartDt=$(date +'%m%d%Y')
        StartTm=$(date +'%H%M%S')

        if [  ! -r ${AVAMAR_BASE}/var/avagent.log ]
        then
                echo "Calling Set Avamar Permissions script..."
               /usr/bin/sudo /nas/common/nbu/bin/avamar_perms.sh
        fi

        if [ ! -r ${AVAMAR_BASE}/var/avagent.log ]
        then
                ReportMsg "WARNING" "Unable to read ${AVAMAR_BASE}/var/avagent.log file. To resolve, DBA should submit an USH ticket asking to execute as root the script /nas/common/nbu/bin/avamar_perms.sh. (http://systemhostingportal.it.att.com/)"
                return 0;
        fi


        if [ -r ${AVAMAR_BASE}/var/avagent.log ]
        then
#
#               code to get new path value from avagent.log file below from John Lopez.
#
                for I in 1 2 3 4 5 6 7 8 9 10 11 12
                do
                        num=$I
                        hostNaMe=`uname -n`
                        GrEp="grep -c ${hostNaMe}"
                        What=`grep '<7502>' /var/avamar/avagent.log |tail -1 | awk -v var=$num '{print $var}' | ${GrEp}`
                        if [ $What -gt 0 ];then
                                NewAvamarPath=`grep '<7502>' /var/avamar/avagent.log |tail -1 | awk -v var=$num '{print $var}'`
                        fi

                        What=`grep '<5964>' /var/avamar/avagent.log |tail -1 | awk -v var=$num '{print $var}' | grep -c ".com"`
                        if [ $What -gt 0 ];then
                                NewAvamarGrid=`grep '<5964>' /var/avamar/avagent.log |tail -1 | awk -v var=$num '{print $var}'`
                        fi

                done

# Jim notes:  NewAvamarGrid and Avamar Server name are the same.

#               echo "NewAvamarPath1=$NewAvamarPath"
#               echo "NewAvamarGrid1=$NewAvamarGrid"
                NewServerName="${NewAvamarGrid}"
                ReturnCode=0
        else
                ReportMsg "WARNING" "Unable to read ${AVAMAR_BASE}/var/avagent.log log file, no avamar flags file updates."
                ReturnCode=0
                return ${ReturnCode};
        fi

#       Based on the $NewAvamarPath variable find TargetDeploy, TargetEnv.  AvamarGridname(Servername) is $NewAvamarGrid
#       and NetworkLabel will be NEBR, EBR or GPN.
#       use logic:
#               CLOUD Automation has two domains
#               A)   /Cloud/Cloud_unix (production servers)
#               B)    /Cloud/Cloud_unix_nonprod (test/dev servers)
#
#               Manual Installs or other Automation outside Cloud
#               A)   /unix/unix (production servers)
#               B)    /unix/unix_nonprod (test/dev/servers)
#

        TargetEnv="NotSet"
        TargetDeploy="NotSet"
        echo ${NewAvamarPath} >${TmpFile13}
        grep "unix" ${TmpFile13}  >/dev/null
        status=$?
        if [[ ${status} -eq 0 ]]
        then
                TargetEnv="Production"
                TargetDeploy="Non-Cloud"
        fi

        grep "unix_nonprod" ${TmpFile13}  >/dev/null
        status=$?
        if [[ ${status} -eq 0 ]]
        then
                TargetEnv="Test/Dev"
        fi

        grep "Cloud_unix" ${TmpFile13}  >/dev/null
        status=$?
        if [[ ${status} -eq 0 ]]
        then
                TargetDeploy="Cloud"
        fi

#       echo "TargetDeploy=${TargetDeploy}"
#       echo "TargetEnv=${TargetEnv}"
#
#       grab network type from the path variable
#
        grep -i "nebr" ${TmpFile13}  >/dev/null
        status=$?
        if [[ ${status} -eq 0 ]]
        then
                Input_NetworkLabel="NEBR"
        else
                Input_NetworkLabel="GPN"
        fi
#       echo "Input_NetworkLabel=$Input_NetworkLabel"

        SqlConnect="/ as sysdba"
        SqlCommand="select 'Cmd1:'||round(sum(bytes/1024/1024/1024)) from sys.v_"'$datafile a'", sys.v_"'$tablespace B'" where a.ts#=b.ts#;";
        RunSql "${SqlCommand}"
        SqlError=${?}
        if (( ${SqlError} != 0 ))
        then
                echo " Select to total bytes failed"
                ReportMsg "" "Select to total bytes failed Failed, or SQL command failed!"
                ReturnCode=1
        fi
        export DBSizeGB=$(grep "^Cmd1:" ${TmpFile1} | awk -F':' '{print $2}')
#       echo "DBSizeGB=${DBSizeGB}"

#       Call API and parse out DDGridYN and DDIndexNum values
#       Section needs to call API with TargetDeploy, TargetEnv, AvamarGridname(Servername),NetworkLabel, and backups size.
#       Return with parameters: --ddr and --ddr-index variables.

#       Get TargetDeploy, TargetEnv, Backupsize
#       Notes: get TargetEnv from ...etc/VTIER.in file, from VP_VTIER_ENVIRONMENT and VP_AVAMAR_DOMAIN
#               The TargetDeploy is VP_AVAMAR_DOMAIN, and this value will need to be parsed out from
#               the NewAvamarPath variable.vamar Flags Configuration has changed

        Input_TargetDeploy=${TargetDeploy}
        Input_TargetEnv=${TargetEnv}
        Input_LoadSize=${DBSizeGB}
        Input_AvGridName=${NewAvamarGrid}

#       echo $Input_TargetDeploy
#       echo $Input_TargetEnv
#       echo $Input_LoadSize
#       echo $Input_AvGridName
#       echo $Input_NetworkLabel

        wget -qO- "http://atd-p1.it.att.com:8080/cgi-bin/avebrapi.sh?FORMAT=TXT&TargetDeploy=${Input_TargetDeploy}&TargetEnv=${Input_TargetEnv}&LoadSize=${Input_LoadSize}&AvGridName=${Input_AvGridName}&NetworkLabel=${Input_NetworkLabel}" >${TmpFile12}
        api_rc=`wc -l ${TmpFile12}|cut -c1`
        if (( api_rc != 1 ))
        then
                print "\n***Begin of ChkAvamarFlagsFile routine***"  >>${LogFile}
                print "Input TargetDeploy=${Input_TargetDeploy}"  >>${LogFile}
                print "Input TargetEnv=${Input_TargetEnv}"        >>${LogFile}
                print "Input LoadSize=${Input_LoadSize}"          >>${LogFile}
                print "Input AvGridName=${Input_AvGridName}"      >>${LogFile}
                print "NetworkLabel=${Input_NetworkLabel}"       >>${LogFile}
                if [[ -r ${AVAMAR_BASE}/var/${ORACLE_SID}_dd.cfg ]]
                then
                        cat ${AVAMAR_BASE}/var/${ORACLE_SID}_dd.cfg >${TmpFile12}
                        print "Found ${AVAMAR_BASE}/var/${ORACLE_SID}_dd.cfg file to override failed API call results, backup continues..." >>${LogFile}
                        AvamarAPISuccess=${True}
                else
                        print "No updates to Avamar flags file parameters (--ddr,--ddr-index) due to Avamar API failed read, backup continues...\n" >>${LogFile}
                        AvamarAPISuccess=${False}
                fi

        else
                AvamarAPISuccess=${True}
        fi
#
#  Removed below logic and added above to simplify for V242+
#
#       wget -qO- "http://atd-p1.it.att.com:8080/cgi-bin/avebrapi.sh?FORMAT=TXT&TargetDeploy=${Input_TargetDeploy}&TargetEnv=${Input_TargetEnv}&LoadSize=${Input_LoadSize}&AvGridName=${Input_AvGridName}&NetworkLabel=${Input_NetworkLabel}" >${TmpFile12}
#       api_rc=`wc -l ${TmpFile12}|cut -c1`
#       if (( api_rc != 1 ))
#       then
#               Input_NetworkLabel="EBR"
#               wget -qO- "http://atd-p1.it.att.com:8080/cgi-bin/avebrapi.sh?FORMAT=TXT&TargetDeploy=${Input_TargetDeploy}&TargetEnv=${Input_TargetEnv}&LoadSize=${Input_LoadSize}&AvGridName=${Input_AvGridName}&NetworkLabel=${Input_NetworkLabel}" >${TmpFile12}
#               api_rc=`wc -l ${TmpFile12}|cut -c1`
#               if (( api_rc != 1 ))
#               then
#                       Input_NetworkLabel="GPN"
#                       wget -qO- "http://atd-p1.it.att.com:8080/cgi-bin/avebrapi.sh?FORMAT=TXT&TargetDeploy=${Input_TargetDeploy}&TargetEnv=${Input_TargetEnv}&LoadSize=${Input_LoadSize}&AvGridName=${Input_AvGridName}&NetworkLabel=${Input_NetworkLabel}" >${TmpFile12}
#                       api_rc=`wc -l ${TmpFile12}|cut -c1`
#                       if (( api_rc != 1 ))
#                       then
#                               print "\n***Begin of ChkAvamarFlagsFile routine***"  >>${LogFile}
#                               print "Input TargetDeploy=${Input_TargetDeploy}"  >>${LogFile}
#                               print "Input TargetEnv=${Input_TargetEnv}"      >>${LogFile}
#                               print "Input LoadSize=${Input_LoadSize}"        >>${LogFile}
#                               print "Input AvGridName=${Input_AvGridName}"    >>${LogFile}
#                               print "NetworkLabel=NEBR, EBR or GPN"           >>${LogFile}
#                               print "No updates to Avamar flags file due to Avamar API failed read,  backup continues..." >>${LogFile}
###                             ReportMsg "WARNING" "Avamar API call failed to return a single row for NEBR, EBR or GPN. No avamar flags file updates."
#                               print "***End of ChkAvamarFlagsFile routine***\n"  >>${LogFile}
#                               return 0;
#                       fi
#               fi
#       fi

        if [[ ${AvamarAPISuccess} = ${True} ]]
        then
                chmod 700 ${TmpFile12}
                . ${TmpFile12}
                ExitCode=${?}
                if (( ${ExitCode} != 0 ))
                then
                        return ${ExitCode}
                fi
        fi

#       echo "TargetEnv=${TargetEnv}"
#       echo "TargetDeploy=${TargetDeploy}"
#       echo "NetworkLabel=${NetworkLabel}"
#       echo "AvGridName=${AvGridName}"
#       echo "DDGridYN=${DDGridYN}"
#       echo "DDIndexNum=${DDIndexNum}"
#
#       Find out if this is RAC - if RAC we will need to assign the virtual IP used by ASM to the flags file.
#
#       select value from v$parameter where name='cluster_database';
#
        SqlConnect="/ as sysdba"
        SqlCommand="select 'Cmd1:'||upper(rpad(value,5)) from v"'$parameter'" where name ='cluster_database';"
        RunSql "${SqlCommand}"
        SqlError=${?}
        if (( ${SqlError} != 0 ))
        then
                ReportMsg "" " Parameter cluster_database parameter check Failed, or SQL command failed!"
                ReturnCode=1
        fi
        export ClusterDatabase=$(grep "^Cmd1:" ${TmpFile1} | awk -F':' '{print $2}')
#       echo "ClusterDatabase=${ClusterDatabase}"
        ServerNameChanged=0
        if  [[ ${ClusterDatabase} = "TRUE" ]]
        then

                SqlConnect="/ as sysdba"
                SqlCommand="select 'Value:'||lower(name) from v"'$database'";"
                RunSql "${SqlCommand}"
                SqlError=${?}
                if (( ${SqlError} != 0 ))
                then
                        ReportMsg "" " Parameter cluster_database check Failed, or SQL command failed!"
                        ReturnCode=1
                fi
                RAC_DBname=$(grep "^Value:" ${TmpFile1} | awk -F':' '{print $2}')
#               echo "RAC_DBname=$RAC_DBname"
#               echo "HostName=$HostName"

                eval "sed -e 's/${HostName}/${RAC_DBname}/g'" ${TmpFile13} > ${TmpFile2}
                NewAvamarPath=`grep '/' ${TmpFile2}`
#               echo "A-NewAvamarPath=${NewAvamarPath}"
                NewServerName_wodashes="server=${NewServerName}"
                NewServerName="--${NewServerName_wodashes}"
#               echo "NewServerName_wodashes=${NewServerName_wodashes}"
#               echo "NewServerName=${NewServerName}"
                grep  ${NewServerName_wodashes} ${LOCAL_BASE}/etc/${AvamarAvtarFile} >/dev/null
                ServerNameChanged=${?}
#               echo "ServerNameChanged=${ServerNameChanged}"
        else
                NewServerName_wodashes="server=${NewServerName}"
                NewServerName="#--${NewServerName_wodashes}"
#               echo "NewServerName_wodashes=${NewServerName_wodashes}"
#               echo "NewServerName=${NewServerName}"
                grep  ${NewServerName_wodashes} ${LOCAL_BASE}/etc/${AvamarAvtarFile} >/dev/null
                ServerNameChanged=${?}
#               echo "ServerNameChanged=${ServerNameChanged}"
        fi
#
        NewAvamarPath_wodashes="path=$NewAvamarPath"
        NewAvamarPath="--path=$NewAvamarPath"
#       echo "NewAvamarPath_wodashes=$NewAvamarPath_wodashes"
#       echo "NewAvamarPath=$NewAvamarPath"

#
#       Check Avamar Flags files to see if new path variable matches
#
        grep "${NewAvamarPath_wodashes}" ${LOCAL_BASE}/etc/${AvamarAvtarFile}  >/dev/null
        PathChanged=${?}
#
#
#       Check Avamar Flags files to see if new path DDR value matches

        if [[ ${AvamarAPISuccess} = ${True} ]]
        then
                if [[ ${DDGridYN} = "Y" ]]
                then
        #               echo "DDGrid = Y"
                        NewDDR="--ddr=true"
                        NewDDR_wodashes="ddr=true"
                        grep "${NewDDR_wodashes}" ${LOCAL_BASE}/etc/${AvamarAvtarFile} >/dev/null
                        DDRChanged=${?}

                        NewDDRIndex_wodashes="ddr-index=${DDIndexNum}"
                        NewDDRIndex="--ddr-index=${DDIndexNum}"
        #               echo "NewDDRIndex_wodashes=${NewDDRIndex_wodashes}"
                        grep "${NewDDRIndex_wodashes}" ${LOCAL_BASE}/etc/${AvamarAvtarFile} >/dev/null
                        DDRIndexChanged=${?}


                elif [[ ${DDGridYN} = "N" ]]
                then
        #               echo "DDGrid = N"
                        grep "ddr=" ${LOCAL_BASE}/etc/${AvamarAvtarFile} >/dev/null
                        DDR_found=${?}
                        if (( ${DDR_found} == 0 ))
                        then
                                DDRChanged=1
                                DDRIndexChanged=1
                        else
                                DDRChanged=0
                                DDRIndexChanged=0
                        fi
                        NewDDR=" "
                        NewDDRIndexNum=" "
                else
                        echo " Bad data in Avamar API data for DDGridYN";
                        exit;
                fi
        else
                DDRChanged=0
                DDRIndexChanged=0
        fi

#       echo "PathChanged=${PathChanged}"
#       echo "ServerNameChanged=${ServerNameChanged}"
#       echo "DDRChanged=${DDRChanged}"
#       echo "DDRIndexChanged=${DDRIndexChanged}"
#       echo "NewDDR=${NewDDR}"
#       echo "NewDDRIndex=${NewDDRIndex}"
#       echo "NewDDR_wodashes=${NewDDR_wodashes}"

#
#       L0_Breadcrumb variable is set to tell us we need to run a Level 0 backup next
#
        L0_Breadcrumb=0
#
#       If Path, DDR or DDRIndex have changed, update avamar flags file.
#
        if (( ${PathChanged} == 1 || ${DDRChanged} == 1 || ${DDRIndexChanged} == 1 || ${ServerNameChanged} == 1))
        then

                cp ${LOCAL_BASE}/etc/${AvamarAvtarFile} ${LOCAL_BASE}/etc/${AvamarAvtarFile}.${StartDt}_${StartTm}
                cp ${LOCAL_BASE}/etc/${AvamarAvtarFile} ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1
                if (( ${PathChanged} == 1 ))
                then
                        sed '/--path/d' ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1 >${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp2
                        OldAvamarPath=`grep "\-\-path=" ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1`
#                       echo "OldAvamarPath=$OldAvamarPath"
                        echo ${NewAvamarPath} >> ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp2
                        cp ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp2 ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1
                        L0_Breadcrumb=1
                fi
#               cat ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1
#
                if (( ${ServerNameChanged} == 1 ))
                then
                        sed '/--server=/d' ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1 >${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp2
                        OldServerName=`grep "\-\-server=" ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1`
#                       echo "OldServerName=$OldServerName"
#                       echo "NewServerName=$NewServerName"
                        echo ${NewServerName} >> ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp2
                        cp ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp2 ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1
                        L0_Breadcrumb=1
                fi
#               cat ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1
#
                if (( ${DDRChanged} == 1 ))
                then
                        sed '/--ddr=/d' ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1 >${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp2
                        OldDDR=`grep "\-\-ddr=" ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1`
#                       echo "OldDDR=$OldDDR"
#                       echo "NewDDR=$NewDDR"
                        echo ${NewDDR} >> ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp2
                        cp ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp2 ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1
                        L0_Breadcrumb=1
                fi
#               cat ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1
#
                if (( ${DDRIndexChanged} == 1 ))
                then
                        sed '/--ddr-index=/d' ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1 >${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp2
                        OldDDRIndex=`grep "\-\-ddr\-index=" ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1`
#                       echo "OldDDRIndex=$OldDDRIndex"
#                       echo "NewDDRIndex=$NewDDRIndex"
                        echo ${NewDDRIndex} >> ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp2
                        cp ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp2 ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1
                        L0_Breadcrumb=1
                fi
#               cat ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1
#
                cp ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1 ${LOCAL_BASE}/etc/${AvamarAvtarFile}

                print "Backup of file located at ${AvamarAvtarFile}.${StartDt}_${StartTm}" >>${LogFile}
                print "\n***************** Avamar Flags file update  *******************" >>${LogFile}
                print "\nOld Avamar Flags File:" >>${LogFile}
                print "-----------------------" >>${LogFile}
                cat  ${LOCAL_BASE}/etc/${AvamarAvtarFile}.${StartDt}_${StartTm} >>${LogFile}
                print "\nNew Avamar Flags File:" >>${LogFile}
                print "-----------------------" >>${LogFile}
                cat  ${LOCAL_BASE}/etc/${AvamarAvtarFile} >>${LogFile}
                print "\n Backup of file located at ${AvamarAvtarFile}.${StartDt}_${StartTm}" >>${LogFile}
                echo "***************************************************************" >>${LogFile}

#               Email DBA Warning of changes
#
                ReportMsg "EMAIL" "Avamar Flags Auto Updated" "${LogFile}"
#
#               Leave a breadcrumb for the next run to check.  If it exists, then we will need to run a Level 0
#               on the next backup.
#
                if (( ${L0_Breadcrumb} == 1 ))
                then
                        touch ${LOCAL_BASE}/etc/Run_L0_breadcrumb.${StartDt}_${StartTm}
                fi
#       else
#               echo "No changes to Avamar Flags file required."
        fi
}
#-----------------------------------------------------------------------------
# Function   : ChkAvamarFlgChgd
# Desciption : If the last BKUPDB ran against a different Avamar Flag configuration,
#              we need to run a Level 0, and not a Level 1.
#              RMAN_Check_Prev_L0_Bkup(instance_SID.cfg param)  is set to True.
#----------------------------------------------------------------------------
function ChkAvamarFlgChgd
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ChkPrevL0Status ${*}" >&2
        typeset ReturnCode=0
        typeset status=0

        ls ${LOCAL_BASE}/etc/Run_L0_breadcrumb* >/dev/null 2>/dev/null
        status=${?}
        if (( ${status} == 0 ))
        then
                print "**Avamar Flags Configuration has changed, modifying Level 1 to Level 0 backups.**\n" >>${LogFile}
                echo "Avamar Flags Configuration has changed, modifying Level 1 to Level 0 backups."
                DbfLevel=0
        fi
}
#-----------------------------------------------------------------------------
# Function   : ChkPrevL0Status
# Desciption : If running a Level 1 backup, check if the previous Level 0 or
#              Full backup was successful. If not run a Level 0 backup if
#              RMAN_Check_Prev_L0_Bkup(instance_SID.cfg param)  is set to True.
#----------------------------------------------------------------------------
function ChkPrevL0Status
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ChkPrevL0Status ${*}" >&2
        typeset ReturnCode=0
        typeset status=0
        if  [[ ${Check_Prev_L0_Bkup} = ${True} ]]
        then
                backup_L0="'RMAN-BKUPDB Level 0','RMAN-BKUPDB Level full'"
                SqlConnect="/ as sysdba"
                SqlCommand="SELECT 'L0_Status:',ltrim(status) FROM v\$rman_backup_job_details WHERE command_id in (${backup_L0}) and end_time = (select max(end_time) from v\$rman_backup_job_details where command_id in (${backup_L0}));";

                RunSql "${SqlCommand}"
                SqlError=${?}
                if (( ${SqlError} != 0 ))
                then
                        ReportMsg "" " Level 0 backup status check Failed, or SQL command failed!"
                        ReturnCode=1
                fi
                backup_L0_success=$(grep "^L0_Status:" ${TmpFile1} | awk -F': ' '{print $2}')
                if [[ $backup_L0_success != "COMPLETED" ]]
                then
                        DbfLevel=0
                        ReportMsg "WARNING" "Previous RMAN Level 0 failed.  This Level 1 backup is being changed to Level 0 backup."
                fi

        fi
        return ${ReturnCode};
}



#-----------------------------------------------------------------------------
# Function   : ChkDBCorruption
# Desciption : During an seccessful run, lets provdie a notification if we found a
#               corrupton and provide the DBA with a warning.
#----------------------------------------------------------------------------
function ChkDBCorruption
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ChkDBCorruptin ${*}" >&2
        typeset ReturnCode=0
        typeset status=0
        DBCorruption=${False}

        SqlConnect="/ as sysdba"
        SqlCommand="SELECT * FROM v\$database_block_corruption;"
        RunSql "${SqlCommand}"
        SqlError=${?}
        if (( ${SqlError} != 0 ))
        then
                ReportMsg "" "Database connection failed, or SQL command failed!"
                ReturnCode=1
        fi
        if (( ${ReturnCode} != 0 ))
        then
                cat /dev/null >${TmpFile1}
        fi
        egrep "no rows selected" ${TmpFile1} > /dev/null 2>&1
        ExitStatus=${?}
        if (( ${ExitStatus} != 0 ))
        then
                print "Block Corruption found!"
                print "                                                           CORRUPTION" > ${TmpFile8}
                print "    FILE#        BLOCK#    BLOCKS   CHANGE#    CORRUPTION" >> ${TmpFile8}
                print "   ----------  -----------  ----------  --------------  --------------" >> ${TmpFile8}
                print "   ----------  -----------  ----------  --------------  --------------" >> ${TmpFile8}
                cat  ${TmpFile1} >> ${TmpFile8}
                DBCorruption=${True};
        fi
        return ${ReturnCode};

}

#-----------------------------------------------------------------------------
# Function   : CleanupAndExit
# Description: Handles the cleanup of temp files.
#----------------------------------------------------------------------------
function CleanupAndExit
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: CleanupAndExit ${*}" >&2

        # 10/01/10 -Used exsiting log file to get last of RMAN handles.  This list will be used to
        # scan the database to list all assocatiated RMAN tags.  This is data will be
        # passed into the standard completion email.
        if ((${MajorRel} > 9 )) && [[ ${Command} = "BKUPDB" || ${Command} = "BKUPTS" || ${Command} = "BKUPFRA" || ${Command} = "BKUPARC" || ${Command} = "BKUPCTL" ]]
        then
                cnt=0
                unset handles
                grep "handle=" ${LogFile}|cut -d" " -f2|uniq|cut -d"=" -f2 >${TmpFile4}
                for i in `cat ${TmpFile4}`
                do
                        if [[ ${cnt} = 0 ]]
                        then
                                handles="'$i'"
                        else
                                handles="$handles,
'$i'"
                        fi
                        cnt=1;
                done
                if [[ ${cnt} != 0 ]]
                then

                        SqlConnect="/ as sysdba"
                        SqlCommand="SELECT 'tag='||tag,'handle='||handle FROM v\$backup_piece_details WHERE handle IN (${handles}) order by tag;"
                        RunSql "${SqlCommand}"
                        SqlError=${?}
                        if (( ${SqlError} != 0 ))
                        then
                                ReportMsg "" "Database connection failed, or SQL command failed!"
                                ReturnCode=1
                        fi
                        if (( ${ReturnCode} != 0 ))
                        then
                                cat /dev/null >${TmpFile1}
                        fi

                        unset oldtag;
                        cat /dev/null >${TmpFile6}
                        for i in `grep "=" ${TmpFile1}`
                        do
                                handle="TAGLINE";
                                print $i >${TmpFile5}
                                . ${TmpFile5}
                                if [[ ${handle} = "TAGLINE" ]]
                                then
                                        if [[ ${tag} != ${oldtag} ]]
                                        then
                                                echo "Tag: $tag" >>${TmpFile6}
                                                oldtag=${tag};
                                        fi
                                else
                                        echo "Handle: $handle" >>${TmpFile6}
                                fi
                        done

                else
                        touch ${TmpFile6}
                fi

        fi
        # End of get Handle/Tag info

        if ((${MajorRel} > 9 )) && [[ ${Command} = "BKUPDB" || ${Command} = "BKUPTS" || ${Command} = "BKUPFRA" || ${Command} = "BKUPARC" || ${Command} = "BKUPCTL" ]]
        then
                ChkDBCorruption;
                if [[ ${DBCorruption} = ${True} ]]
                then
                        ReportMsg "EMAIL" "DB Courruption Found - FAILURE - Review v\$database_block_corruption" "${TmpFile8}"
                fi
        fi

        typeset ExitStatus=${1}
        export ExitStatus

        # if EndTime is not set, because we exited the main routine prior to running the
        # RunCmdFile function, then we will set it here.

        if  [[ -z ${EndDate} ]]
        then
                EndDate=$(date +'%m/%d/%Y')
                EndTime=$(date +'%H:%M:%S')
        fi

        #
        # If no errors occurred, remove temporary files, otherwise leave
        # them for debugging
        if (( ${ExitStatus} == 0 ))
        then

                if [[ ${Command} = "BKUPDB" || ${Command} = "BKUPTS" ]] || [[ ${Command} = "BKUPFRA" ]] ||
                        [[ ${Command} = "BKUPARC" && ${BkupArcEmail} != ${False} ]] || [[ ${Command} = "BKUPCTL" && ${BkupCtlEmail} != ${False} ]]
                then

                        print -- "------------------------------------------------------------" > ${TmpFile2}
                        print "Database                  : ${ORACLE_SID}" >> ${TmpFile2}
                        print "DBID                      : ${DbId}" >> ${TmpFile2}
                        print "Backup Status             : SUCCESSFUL" >> ${TmpFile2}
                        print "Backup Command            : ${Command}" >> ${TmpFile2}
                        print "Backup Type               : ${DbfBkupType}" >> ${TmpFile2}
                        print "Database Role             : ${DBRole}" >> ${TmpFile2}
                        if [[ ${DbfClone} = ${True} ]]
                        then
                                print "Clone Backup              : True" >> ${TmpFile2}
                                print "Clone Source Host         : ${CloneSourceHost}" >> ${TmpFile2}
                                print "Clone Source SID          : ${CloneSourceSid}" >> ${TmpFile2}
                                print "Clone Mount Host          : ${CloneMountHost}" >> ${TmpFile2}
                                print "Clone Mount SID           : ${CloneMountSid}" >> ${TmpFile2}
                        fi
                        if [[ ${DbfProxyCopy} = ${True} ]]

                                grep PATH ${LOCAL_BASE}/etc/${AvamarAvtarFile}
                        then
                                print "Proxy Copy                : True" >> ${TmpFile2}
                        fi
                        print "Media Vendor              : ${MediaVendor}" >> ${TmpFile2}
                        print "Channel Type              : ${ChanType}" >> ${TmpFile2}
                        print "Channel Count             : ${ChanCount}" >> ${TmpFile2}
                        print "FilesPerSet               : $(echo ${FilesPerSetCmd} | ${AWK} '{print $2}')" >> ${TmpFile2}
                        print "MaxSetSize                : $(echo ${MaxSetSizeCmd} | ${AWK} '{print $2}')" >> ${TmpFile2}
                        print "SectionSize               : $(echo ${SectionSizeCmd} | ${AWK} '{print $3}')" >> ${TmpFile2}
                        print "MaxOpenFiles              : $(echo ${MaxOpenFilesCmd} | ${AWK} -F '=' '{print $2}')" >> ${TmpFile2}
                        print "Backup Started at         : ${StartDate} ${StartTime}" >> ${TmpFile2}
                        print "Backup Completed at       : ${EndDate} ${EndTime}" >> ${TmpFile2}
                        print "Elapsed Seconds           : ${SECONDS}" >> ${TmpFile2}
                        print "Backup Log                : ${LogFile}" >> ${TmpFile2}
                        print "RMAN script Version       : ${ScriptId}" >> ${TmpFile2}
                        print "Hostname                  : ${HostName}" >> ${TmpFile2}
                        print "Vtiername                 : ${UserName}" >> ${TmpFile2}
                        print "RMAN_CAT_ALIAS            : ${CatAlias}" >> ${TmpFile2}
                        if [[ ${MediaVendor} = "NETBACKUP" ]]
                        then
                                print "NB_ORA_SERVER             : ${NB_ORA_SERV}" >> ${TmpFile2}
                                print "NB_ORA_CLIENT             : ${NB_ORA_CLIENT}" >> ${TmpFile2}
                                print "NB_ORA_POLICY             : ${NB_ORA_POLICY}" >> ${TmpFile2}
                        elif [[ ${MediaVendor} = "AVAMAR" ]]
                        then
                                AvamarPath="`grep -i path  ${LOCAL_BASE}/etc/${AvamarAvtarFile}|awk -F'=' '{print $2}'`"
                                print "Avamar Grid               : ${AvamarGrid}" >> ${TmpFile2}
                                print "Avamar Path               : ${AvamarPath}" >> ${TmpFile2}
                        fi

                        cat ${TmpFile6} >> ${TmpFile2}
                        print -- "------------------------------------------------------------" >> ${TmpFile2}

                        if [[ ${DBCorruption} = ${True} ]]
                        then
                                print "------------------------------------------------------------" >> ${TmpFile2}
                                print "***********************  WARNING ***************************" >> ${TmpFile2}
                                print "FOUND DB Corruption in v\$database_block_corruption, please review following:" >> ${TmpFile2}
                                cat ${TmpFile8} >> ${TmpFile2}
                                print "************************************************************" >> ${TmpFile2}
                        fi

                        if [[ -f ${LogFile} ]]
                        then
                                CString="connect catalog ${CatSchema}\/XXXX@${CatAlias};"
                                cat ${LogFile} | eval "sed -e 's/connect catalog.*/${CString}/'" >> ${TmpFile2}
                        fi
                        if [[ ${Command} = "BKUPFRA" ]]
                        then
                                ReportMsg "EMAIL" "FRA Backup SUCCESSFUL${MsgWarning}" "${TmpFile2}"
                        elif [[ ${Command} = "BKUPARC" ]]
                        then
                                ReportMsg "EMAIL" "ARC Backup SUCCESSFUL${MsgWarning}" "${TmpFile2}"
                        elif [[ ${Command} = "BKUPCTL" ]]
                        then
                                ReportMsg "EMAIL" "Control File Backup SUCCESSFUL${MsgWarning}" "${TmpFile2}"
                        else
                                ReportMsg "EMAIL" "DB Backup SUCCESSFUL${MsgWarning}" "${TmpFile2}"
                        fi

                        # Issue LOGGER Message
                        if [[ ${MediaVendor} = "NONE" ]]
                        then
                                ReportMsg "LOGGER" "BACKUP SUCCESSFUL${MsgWarning} ${ORACLE_SID} ${ScriptName}:db:DISK:${DbfBkupType}"
                        else
                                ReportMsg "LOGGER" "BACKUP SUCCESSFUL${MsgWarning} ${ORACLE_SID} ${ScriptName}:db:${MediaVendor}:${DbfBkupType}"
                        fi


                        # Notify Patrol KM of completion
                        if [[ -n ${PatrolEndNotify} && -x ${PatrolEndNotify} ]]
                        then
                                BackupName="${ScriptName}-${ORACLE_SID}"

                                if [[ -n ${PatrolTag} ]]
                                then
                                        BackupName="${BackupName}-${PatrolTag}"
                                fi
                                ${PatrolEndNotify} "${BackupName}" "${ExitStatus}"
                        fi

                        if [[ -n ${DbfBkupUserSuccess} ]]
                        then
                                export UserState="UserSuccess"
                                eval "(${DbfBkupUserSuccess}; echo RC: \${?})" >> ${TmpFile1} 2>&1
                                CmdRc=$(grep "^RC: " ${TmpFile1} 2>/dev/null | tail -1 | ${AWK} '{print $2}')
                                if (( ${CmdRc} != 0 ))
                                then
                                        ReportMsg "${FailureSeverity}" "User Success Script Failed, RC=${CmdRc}"
                                fi
                        fi
                fi
                # Send successful always for RESTOREVAL function
                if [[ "${Command}" = "RESTOREVAL" ]]
                then
                        ReportMsg "EMAIL" "DB RESTOREVAL SUCCESSFUL${MsgWarning}" "${LogFile}"
                fi


                # Clean Exit, Remove any temporary files, if not in debug mode
                if [[ ${Debug} = ${False} ]]
                then
                        rm -f ${TrcFile} 2>/dev/null
                        rm -f ${TmpFile1} 2>/dev/null
                        rm -f ${TmpFile2} 2>/dev/null
                        rm -f ${TmpFile3} 2>/dev/null
                        rm -f ${TmpFile4} 2>/dev/null
                        rm -f ${TmpFile5} 2>/dev/null
                        rm -f ${TmpFile6} 2>/dev/null
                        rm -f ${TmpFile7} 2>/dev/null
                        rm -f ${TmpFile8} 2>/dev/null
                        rm -f ${TmpFile9} 2>/dev/null
                        rm -f ${TmpFile10} 2>/dev/null
                        rm -f ${TmpFile11} 2>/dev/null
                        rm -f ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp1 2>/dev/null
                        rm -f ${LOCAL_BASE}/etc/${AvamarAvtarFile}.tmp2 2>/dev/null
                        if [[ ${DbfLevel} = "0" ]] then
                                rm ${LOCAL_BASE}/etc/Run_L0_breadcrumb.* 2>/dev/null
                        fi
                fi

                if [[ ${Command} = "BKUPDB" ]]
                then
                        EDS_Report End;
                fi
        else
                if [[ "${Command}" = "BKUPDB" || "${Command}" = "BKUPTS" ]] && [[ "${DbfBkupType}" = "OFFLINE" ]]
                then
                        SqlConnect="/ as sysdba"
                        SqlCommand="SELECT 'Cmd1:'||status FROM v\$instance;"
                        RunSql "${SqlCommand}"
                        SqlError=${?}
                        if (( ${SqlError} != 0 ))
                        then
                                ReportMsg "CRITICAL" "Unable to access the database after failure"
                        else
                                DBStatus=$(grep "^Cmd1:" ${TmpFile1} | sed -e 's/^Cmd1://' -e 's/ *$//')
                                if [[ ${DBStatus} != "OPEN" ]]
                                then
                                        SqlCommand="ALTER DATABASE OPEN;"
                                        RunSql "${SqlCommand}"
                                        SqlError=${?}
                                        if (( ${SqlError} != 0 ))
                                        then
                                                ReportMsg "CRITICAL" "Unable to re-open database after failure"
                                        fi
                                fi
                        fi
                fi

                if [[ ${Command} = "BKUPDB" || ${Command} = "BKUPTS" || ${Command} = "BKUPFRA" || ${Command} = "BKUPARC" || ${Command} = "BKUPCTL" ]]
                then

echo "LogFile=${LogFile}"
                        if [[ -f /orasoft/local/contrib/nbulogchk && ${MediaVendor} = "NETBACKUP" ]]
                        then
                                print "\n*******************************************************"  >> ${LogFile} 2>&1
                                print   "*** Begin of Review NBU transaction logs            ***"  >> ${LogFile} 2>&1
                                print   "*******************************************************\n"  >> ${LogFile} 2>&1
                                /orasoft/local/contrib/nbulogchk >> ${LogFile} 2>&1
                                print "\n*******************************************************"  >> ${LogFile} 2>&1
                                print   "*** Begin Review of NBU Daily logs ( last 50 lines) ***"  >> ${LogFile} 2>&1
                                print   "*** /usr/openv/netbackup/logs/dbclient log files    ***"  >> ${LogFile} 2>&1
                                print   "*******************************************************\n"  >> ${LogFile} 2>&1
                                tail -50 /usr/openv/netbackup/logs/dbclient/log.`date '+%m%d%y'` >> ${LogFile} 2>&1
                                print "\n*******************************************************"  >> ${LogFile} 2>&1
                                print   "*** END of Review NBU logs                          ***"  >> ${LogFile} 2>&1
                                print   "*******************************************************\n\n"  >> ${LogFile} 2>&1

                        elif [[ ${MediaVendor} = "AVAMAR" ]]
                        then

                           if [[ -r /var/avamar/avagent.log  ]]
                           then
#                               Use avamar logs to discover value of the --server variable:

                                AvamarServer="`grep '<7502>' /var/avamar/avagent.log | tail -1 | awk '{print $12}' | cut -f1 -d":"`"
                                AvamarPath="`grep '<7502>' /var/avamar/avagent.log | tail -1 | awk '{print $9 }'`"
                                print "\n*******************************************************"  >> ${LogFile} 2>&1
                                print   "*** BEGIN Discovered Avamar Flag file entries       ***"  >> ${LogFile} 2>&1
                                print   "*** Based on Avamar log system log files, your flags***"  >> ${LogFile} 2>&1
                                print   "*** should have the following values. (Avamar Server***"  >> ${LogFile} 2>&1
                                print   "*** param should only be set for RAC installs.      ***"  >> ${LogFile} 2>&1
                                print   "*** These params are retrieved from                 ***"  >> ${LogFile} 2>&1
                                print   "*** /var/avamar/avagent, and not from the avamar    ***"  >> ${LogFile} 2>&1
                                print   "*** flags file. These values should match the values***"  >> ${LogFile} 2>&1
                                print   "*** in your avamar flags file. This Avamar Path     ***"  >> ${LogFile} 2>&1
                                print   "*** variable is for non-RAC installs only           ***"  >> ${LogFile} 2>&1
                                print   "*******************************************************\n\n"  >> ${LogFile} 2>&1
                                print "Avamar Grid Server        : ${AvamarServer}" >> ${LogFile}
                                print "Avamar Path               : ${AvamarPath}"  >> ${LogFile}
                                print "\n*******************************************************"  >> ${LogFile} 2>&1
                                print   "*** END of Avamar flag file discovery               ***"  >> ${LogFile} 2>&1
                                print   "*******************************************************\n\n"  >> ${LogFile} 2>&1
                           else
                                print "\n*******************************************************"  >> ${LogFile} 2>&1
                                print   "*** Avamar /var/avamar/avagent.log is not readable, ***"  >> ${LogFile} 2>&1
                                print   "*** no avamar flag variables can be discovered.     ***"  >> ${LogFile} 2>&1
                                print   "*** Avamar Backups use a avtar flags file, and not  ***" >> ${LogFile} 2>&1
                                print   "*** no avagent.log file.  We are just trying to     ***" >> ${LogFile} 2>&1
                                print   "*** gather additional information at runtime. This  ***" >> ${LogFile} 2>&1
                                print   "*** file not readable did not cause the job to fail.***" >> ${LogFile} 2>&1
                                print   "*******************************************************\n\n"  >> ${LogFile} 2>&1
                           fi
						   
                           print " " >> ${LogFile} 2>&1
                           print " " >> ${LogFile} 2>&1
                           print " Presenting more Avamar Artifacts: " >> ${LogFile} 2>&1
                           print " ----------------------------------------" >> ${LogFile} 2>&1
                           print " Avamar Grid Server: `cat /usr/local/avamar/var/cid.bin | head -1`" >> ${LogFile} 2>&1
                           print " " >> ${LogFile} 2>&1
                           print " Avamar Flags configuration file: " >> ${LogFile} 2>&1
                           print " ----------------------------------------"  >> ${LogFile} 2>&1
                           print "\$ cat ${LOCAL_BASE}/etc/${AvamarAvtarFile}" >> ${LogFile} 2>&1
                           cat ${LOCAL_BASE}/etc/${AvamarAvtarFile} >> ${LogFile} 2>&1
                           print " " >> ${LogFile} 2>&1
                           print "Tail last 100 lines of avtar.log:" >> ${LogFile} 2>&1
                           print " -----------------------------------------"  >> ${LogFile} 2>&1
                           print "\$ tail -100 ${LOCAL_BASE}/log/y4rac1d1_avtar.log" >> ${LogFile} 2>&1
                           tail -100 ${LOCAL_BASE}/log/y4rac1d1_avtar.log >> ${LogFile} 2>&1
                           print " "  >> ${LogFile} 2>&1
                           print " Running Avtar connection command:"  >> ${LogFile} 2>&1
                           print " -----------------------------------------"  >> ${LogFile} 2>&1
                           print "\$ avtar --backups --flagfile=${LOCAL_BASE}/etc/${AvamarAvtarFile}"  >> ${LogFile} 2>&1
                           avtar --backups --flagfile=${LOCAL_BASE}/etc/${AvamarAvtarFile} >> ${LogFile} 2>&1


                        fi

                        print -- "------------------------------------------------------------" > ${TmpFile2}
                        print "Database                  : ${ORACLE_SID}" >> ${TmpFile2}
                        print "DBID                      : ${DbId}" >> ${TmpFile2}
                        print "Backup Status             : FAILURE" >> ${TmpFile2}
                        print "Backup Command            : ${Command}" >> ${TmpFile2}
                        print "Backup Type               : ${DbfBkupType}" >> ${TmpFile2}
                        print "Database Role             : ${DBRole}" >> ${TmpFile2}
                        if [[ ${DbfClone} = ${True} ]]
                        then
                                print "Clone Backup              : True" >> ${TmpFile2}
                                print "Clone Source Host         : ${CloneSourceHost}" >> ${TmpFile2}
                                print "Clone Source SID          : ${CloneSourceSid}" >> ${TmpFile2}
                                print "Clone Mount Host          : ${CloneMountHost}" >> ${TmpFile2}
                                print "Clone Mount SID           : ${CloneMountSid}" >> ${TmpFile2}
                        fi
                        if [[ ${DbfProxyCopy} = ${True} ]]
                        then
                                print "Proxy Copy                : True" >> ${TmpFile2}
                        fi
                        print "Media Vendor              : ${MediaVendor}" >> ${TmpFile2}
                        print "Channel Type              : ${ChanType}" >> ${TmpFile2}
                        print "Channel Count             : ${ChanCount}" >> ${TmpFile2}
                        print "Filesperset               : $(echo ${FilesPerSetCmd} | ${AWK} '{print $2}')" >> ${TmpFile2}
                        print "MaxSetSize                : $(echo ${MaxSetSizeCmd} | ${AWK} '{print $2}')" >> ${TmpFile2}
                        print "SectionSize               : $(echo ${SectionSizeCmd} | ${AWK} '{print $3}')" >> ${TmpFile2}
                        print "MaxOpenFiles              : $(echo ${MaxOpenFilesCmd} | ${AWK} -F '=' '{print $2}')" >> ${TmpFile2}
                        print "Backup Started at         : ${StartDate} ${StartTime}" >> ${TmpFile2}
                        print "Backup Completed at       : ${EndDate} ${EndTime}" >> ${TmpFile2}
                        print "Elapsed Seconds           : ${SECONDS}" >> ${TmpFile2}
                        print "Backup Log                : ${LogFile}" >> ${TmpFile2}
                        print "RMAN script Version       : ${ScriptId}" >> ${TmpFile2}
                        print "Hostname                  : ${HostName}" >> ${TmpFile2}
                        print "Vtiername                 : ${UserName}" >> ${TmpFile2}
                        print "RMAN_CAT_ALIAS            : ${CatAlias}" >> ${TmpFile2}
                        if [[ ${MediaVendor} = "NETBACKUP" ]]
                        then
                                print "NB_ORA_SERVER             : ${NB_ORA_SERV}" >> ${TmpFile2}
                                print "NB_ORA_CLIENT             : ${NB_ORA_CLIENT}" >> ${TmpFile2}
                                print "NB_ORA_POLICY             : ${NB_ORA_POLICY}" >> ${TmpFile2}
                        elif [[ ${MediaVendor} = "AVAMAR" ]]
                        then
                                AvamarPath="`grep -i path  ${LOCAL_BASE}/etc/${AvamarAvtarFile}|awk -F'=' '{print $2}'`"
                                print "Avamar Grid               : ${AvamarGrid}" >> ${TmpFile2}
                                print "Avamar Path               : ${AvamarPath}" >> ${TmpFile2}
                        fi

                        cat ${TmpFile6} >> ${TmpFile2}
                        print -- "------------------------------------------------------------" >> ${TmpFile2}

                        # if block corruption is found, write it to log file.
                        if [[ ${DBCorruption} = ${True} ]]
                        then
                                print "------------------------------------------------------------" >> ${TmpFile2}
                                print "***********************  WARNING ***************************" >> ${TmpFile2}
                                print "FOUND DB Corruption in v$\database_block_corruption, pleaes review follwing:" >> ${TmpFile2}
                                cat ${TmpFile8} >> ${TmpFile2}
                                print "************************************************************" >> ${TmpFile2}
                        fi

                        #  We are in the error block, so lets add nbu error info to the log file
                        if [[ -f ${LogFile} ]]
                        then
                                CString="connect catalog ${CatSchema}\/XXXX@${CatAlias};"
                                cat ${LogFile} | eval "sed -e 's/connect catalog.*/${CString}/'" >> ${TmpFile2}
                        fi

                        if [[ ${Command} = "BKUPFRA" ]]
                        then
                                ReportMsg "EMAIL" "FRA Backup FAILURE" "${TmpFile2}"
                                ReportMsg "${FailureSeverity}" "FRA Backup FAILURE"

                        elif [[ ${Command} = "BKUPARC" ]]
                        then
                                ReportMsg "EMAIL" "ARC Backup FAILURE" "${TmpFile2}"
                                ReportMsg "${FailureSeverity}" "ARC Backup FAILURE"
                        elif [[ ${Command} = "BKUPCTL" ]]
                        then
                                ReportMsg "EMAIL" "Control File Backup FAILURE" "${TmpFile2}"
                                ReportMsg "${FailureSeverity}" "Control File Backup FAILURE"
                        else
                                ReportMsg "EMAIL" "DB Backup FAILURE" "${TmpFile2}"
                                ReportMsg "${FailureSeverity}" "DB Backup FAILURE"
                        fi


                        # Issue LOGGER Message
                        if [[ ${MediaVendor} = "NONE" ]]
                        then
                                ReportMsg "LOGGER" "BACKUP FAILURE ${ORACLE_SID} ${ScriptName}:db:DISK:${DbfBkupType}"
                        else
                                ReportMsg "LOGGER" "BACKUP FAILURE ${ORACLE_SID} ${ScriptName}:db:${MediaVendor}:${DbfBkupType}"
                        fi

                        # Notify Patrol KM of completion
                        if [[ -n ${PatrolEndNotify} && -x ${PatrolEndNotify} ]]
                        then

                                BackupName="${ScriptName}-${ORACLE_SID}"

                                if [[ -n ${PatrolTag} ]]
                                then
                                        BackupName="${BackupName}-${PatrolTag}"
                                fi
                                ${PatrolEndNotify} "${BackupName}" "${ExitStatus}"
                        fi

                        if [[ -n ${DbfBkupUserFail} ]]
                        then
                                export UserState="UserFail"
                                eval "(${DbfBkupUserFail}; echo RC: \${?})" >> ${TmpFile1} 2>&1
                                CmdRc=$(grep "^RC: " ${TmpFile1} 2>/dev/null | tail -1 | ${AWK} '{print $2}')
                                if (( ${CmdRc} != 0 ))
                                then
                                        ReportMsg "${FailureSeverity}" "User Fail Script Failed, RC=${CmdRc}"
                                fi
                        fi
                elif [[ ${Command} = "BKUPARC" ]]
                then
                        # Issue LOGGER Message
                        if [[ ${MediaVendor} = "NONE" ]]
                        then
                                ReportMsg "LOGGER" "BACKUP FAILURE ${ORACLE_SID} ${ScriptName}:arc:DISK:${DbfBkupType}"
                        else
                                ReportMsg "LOGGER" "BACKUP FAILURE ${ORACLE_SID} ${ScriptName}:arc:${MediaVendor}:${DbfBkupType}"
                        fi
                fi
                if (( ${EDSLogger} ))
                then
                        logger Oracle_Alarm--\> DBBKFAILED: $ORACLE_SID --\>  "See orarman logfile for details"
                fi
        fi

        # If statement to pick up KM complete action if required, and not completed.
        if [[ ${Command} = "MONFRA" ]] || [[ ${Command} = "BKUPFRA" && ${FRANoEmail} = ${True} ]]
        then

                # Notify Patrol KM of completion
                if [[ -n ${PatrolEndNotify} && -x ${PatrolEndNotify} ]]
                then

                        BackupName="${ScriptName}-${ORACLE_SID}"
                        if [[ -n ${PatrolTag} ]]
                        then
                                BackupName="${BackupName}-${PatrolTag}"
                        fi
                        ${PatrolEndNotify} "${BackupName}" "${ExitStatus}"
                fi
        fi

        rm -f ${CmdFile} 2>/dev/null

        if [[ ${CleanupLock} = ${True} ]]
        then
                rm -f ${LockFile}
        fi

        exit ${ExitStatus}

} # End of CleanupAndExit


#-----------------------------------------------------------------------------
# Function   : ReadConfigFile
# Description: Read in the configuration file.  Configuration file is in the
#              format of:
#                 parameter [=] value
#              where parameter must begin in column 1 and start with an alpha
#              character.  The parameter is case insensitve and the equal
#              sign is optional.  The value can contain defined environment
#              variables, such as $ORACLE_SID which is defined by the script
#              itself before the configuration file is read.  For Example:
#                 TNS_ADMIN = /var/opt/oracle
#-----------------------------------------------------------------------------
function ReadConfigFile
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ReadConfigFile ${*}" >&2


        typeset ConfigFile=${1}
        typeset Parameter
        typeset Value
        typeset DbfBkupDirI=0
        typeset ArcBkupDirI=0
        typeset TablespaceI=0

        while read Line
        do
                Line=$(echo ${Line} | grep -i ^[a-z] | sed -e 's/=/ /')
                if [[ -z ${Line} ]]
                then
                        continue
                fi

                set -- ${Line}
                Parameter=$(echo ${1} | tr '[:lower:]' '[:upper:]')
                shift 1
                Value=$(eval echo "${*}")
                Value=$(eval echo "${Value}")
                case ${Parameter} in
                        LOCAL_BIN)
                                LocalBin=${Value}
                                export PATH=${PATH}:${LocalBin}
                                ;;
                        PATROL_START_NOTIFY)
                                PatrolStartNotify=${Value}
                                ;;
                        PATROL_END_NOTIFY)
                                PatrolEndNotify=${Value}
                                ;;
                        RMAN_FAILURE_SEVERITY)
                                FailureSeverity=${Value}
                                ;;
                        TMP_DIR)
                                TmpDir=${Value}
                                ;;
                        RMAN_TMP_DIR)
                                RmanTmpDir=${Value}
                                ;;
                        RMAN_CLONE_TMP_DIR)
                                CloneTmpDir=${Value}
                                ;;
                        LOG_DIR)
                                LogDir=${Value}
                                ;;
                        RMAN_LOG_DIR)
                                RmanLogDir=${Value}
                                ;;
                        RMAN_CLONE_LOG_DIR)
                                CloneLogDir=${Value}
                                ;;
                        RMAN_FRA_FULL_PCT)
                                RmanFraFullPct=${Value}
                                ;;
                        RMAN_FRA_ACTIVE)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        FRAActive=${True}
                                else
                                        FRAActive=${False}
                                fi
                                ;;
                        RMAN_BKUPFRA_NOEMAIL)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        FRANoEmail=${True}
                                else
                                        FRANoEmail=${False}
                                fi
                                ;;
                        RMAN_CAT_ACTIVE)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        CatActive=${True}
                                else
                                        CatActive=${False}
                                fi
                                ;;
                        RMAN_CHECK_LOGICAL_CORRUPTION)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        ChkLogCorrupt=${True}
                                else
                                        ChkLogCorrpt=${False}
                                fi
                                ;;
                        RMAN_CAT_ALIAS)
                                CatAlias=${Value}
                                ;;
                        RMAN_CAT_SCHEMA)
                                CatSchema=${Value}
                                ;;
                        RMAN_CAT_PASSWORD)
                                CatPassword=${Value}
                                ;;
                        RMAN_MEDIA_VENDOR)
                                MediaVendor=${Value}
                                ;;
                        RMAN_CHANNEL_TYPE)
                                ChanType=${Value}
                                if [[ ${ChanType} = "TAPE" ]]
                                then
                                        ChanType=sbt_tape
                                fi
                                ;;
                        RMAN_DBF_CHANNEL_TYPE)
                                DbfChanType=${Value}
                                if [[ ${DbfChanType} = "TAPE" ]]
                                then
                                        DbfChanType=sbt_tape
                                fi
                                ;;
                        RMAN_ARC_CHANNEL_TYPE)
                                ArcChanType=${Value}
                                if [[ ${ArcChanType} = "TAPE" ]]
                                then
                                        ArcChanType=sbt_tape
                                fi
                                ;;
                        RMAN_DBF_LEVEL)
                                DbfLevel=${Value}
                                ;;
                        RMAN_CHECK_PREV_L0_BKUP)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        Check_Prev_L0_Bkup=${True}
                                else
                                        Check_Prev_L0_Bkup=${False}
                                fi
                                ;;
                        RMAN_DBF_INCR_TYPE)
                                DbfIncrType=${Value}
                                ;;

                        RMAN_DBF_BKUP_TYPE)
                                # Hot/Online or Cold/Offline
                                DbfBkupType=${Value}
                                ;;
                        RMAN_DBF_BKUP_USER_BEGIN)
                                # Script to run at beginning
                                DbfBkupUserBegin=${Value}
                                ;;
                        RMAN_DBF_BKUP_USER_SUCCESS)
                                # Script to run after success
                                DbfBkupUserSuccess=${Value}
                                ;;
                        RMAN_DBF_BKUP_USER_FAIL)
                                # Script to run after failure
                                DbfBkupUserFail=${Value}
                                ;;
                        RMAN_CHANNEL_COUNT)
                                ChanCount=${Value}
                                ;;
                        RMAN_DBF_CHANNEL_COUNT)
                                DbfChanCount=${Value}
                                ;;
                        RMAN_ARC_CHANNEL_COUNT)
                                ArcChanCount=${Value}
                                ;;
                        RMAN_FILESPERSET)
                                FilesPerSet=${Value}
                                ;;
                        RMAN_DBF_FILESPERSET)
                                DbfFilesPerSet=${Value}
                                ;;
                        RMAN_ARC_FILESPERSET)
                                ArcFilesPerSet=${Value}
                                ;;
                        RMAN_MAXOPENFILES)
                                MaxOpenFiles=${Value}
                                ;;
                        RMAN_DBF_MAXOPENFILES)
                                DbfMaxOpenFiles=${Value}
                                ;;
                        RMAN_ARC_MAXOPENFILES)
                                ArcMaxOpenFiles=${Value}
                                ;;
                        RMAN_RATE)
                                Rate=${Value}
                                ;;
                        RMAN_DBF_RATE)
                                DbfRate=${Value}
                                ;;
                        RMAN_ARC_RATE)
                                ArcRate=${Value}
                                ;;
                        RMAN_MAXSETSIZE)
                                MaxSetSize=${Value}
                                ;;
                        RMAN_DBF_MAXSETSIZE)
                                DbfMaxSetSize=${Value}
                                ;;
                        RMAN_ARC_MAXSETSIZE)
                                ArcMaxSetSize=${Value}
                                ;;
                        RMAN_SECTIONSIZE)
                                SectionSize=${Value}
                                ;;
                        RMAN_DBF_SECTIONSIZE)
                                DbfSectionSize=${Value}
                                ;;
                        RMAN_BLKSIZE)
                                BlkSize=${Value}
                                ;;
                        RMAN_CMD_DEBUG)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        CmdDebug=${True}
                                else
                                        CmdDebug=${False}
                                fi
                                ;;
                        RMAN_CMD_DEBUG_LEVEL)
                                CmdDebugLvl=${Value}
                                ;;
                        RMAN_POST_RUN_SQL)
                                PostRunSQL=${Value}
                                ;;
                        RMAN_SBT_LIBRARY)
                                # Allow a comment after the value.
                                SBTLibrary=$(echo ${Value} | ${AWK} '{print $1}')
                                ;;
                        RMAN_FIX_AIX_SBT_LIBRARY)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "NO" || "${Value}" = "FALSE" || "${Value}" = "OFF" || "${Value}" = "${False}" ]]
                                then
                                        FixAIXSBTLibrary=${False}
                                fi
                                ;;
                        RMAN_ARC_INCLUDE)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        ArcInclude=${True}
                                else
                                        ArcInclude=${False}
                                fi
                                ;;
                        RMAN_BKUPFRA_RUN)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        BkupFRARun=${True}
                                else
                                        BkupFRARun=${False}
                                fi
                                ;;
                        RMAN_DELOBSOLETE_RUN)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        DelObsoleteRun=${True}
                                else
                                        DelObsoleteRun=${False}
                                fi
                                ;;
                        RMAN_DELOBSOLETE_RECOVERY_WINDOW_CHK)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        DelObsolete_RecWindowChk=${True}
                                else
                                        DelObsolete_RecWindowChk=${False}
                                fi
                                ;;
                        RMAN_DELOBSOLETE_FORCE)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        DelObsoleteForce=${True}
                                else
                                        DelObsoleteForce=${False}
                                fi
                                ;;
                        RMAN_ARC_ALARM_FREEKB)
                                ArcAlarmFreeKB=${Value}
                                ;;
                        RMAN_ARC_BKUP_FREEKB)
                                ArcBkupFreeKB=${Value}
                                ;;
                        RMAN_NB_ORA_SERV)
                                NBOraServ=${Value}
                                ;;
                        RMAN_NB_ORA_CLIENT)
                                NBOraClient=${Value}
                                ;;
                        RMAN_CLONE_NB_ORA_SERV)
                                CloneNBOraServ=${Value}
                                ;;
                        RMAN_CLONE_NB_ORA_CLIENT)
                                CloneNBOraClient=${Value}
                                ;;
                        RMAN_NB_ORA_POLICY)
                                NBOraPolicy=${Value}
                                ;;
                        RMAN_NB_ORA_CLASS)
                                NBOraPolicy=${Value}
                                ;;
                        RMAN_DBF_NB_ORA_POLICY)
                                DbfNBOraPolicy=${Value}
                                ;;
                        RMAN_DBF_NB_ORA_CLASS)
                                DbfNBOraPolicy=${Value}
                                ;;
                        RMAN_CLONE_DBF_NB_ORA_POLICY)
                                CloneDbfNBOraPolicy=${Value}
                                ;;
                        RMAN_ARC_NB_ORA_POLICY)
                                ArcNBOraPolicy=${Value}
                                ;;
                        RMAN_ARC_NB_ORA_CLASS)
                                ArcNBOraPolicy=${Value}
                                ;;
                        RMAN_NB_ORA_SCHED)
                                NBOraSched=${Value}
                                ;;
                        RMAN_DBF_NB_ORA_SCHED)
                                DbfNBOraSched=${Value}
                                ;;
                        RMAN_CLONE_DBF_NB_ORA_SCHED)
                                CloneDbfNBOraSched=${Value}
                                ;;
                        RMAN_ARC_NB_ORA_SCHED)
                                ArcNBOraSched=${Value}
                                ;;
                        RMAN_DBF_PROXY_COPY)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        DbfProxyCopy=${True}
                                else
                                        DbfProxyCopy=${False}
                                fi
                                ;;
                        RMAN_DBF_NB_ORA_PC_STREAMS)
                                DbfNBOraPCStreams=${Value}
                                ;;
                        RMAN_DBF_NB_ORA_PC_SCHED)
                                DbfNBOraPCSched=${Value}
                                ;;
                        RMAN_BKUPFRA_USE_ARCH_POLICY)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        BkupFraUseArchPolicy=${True}
                                else
                                        BkupFraUseArchPolicy=${False}
                                fi
                                ;;
                        RMAN_DBF_CLONE)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        DbfClone=${True}
                                else
                                        DbfClone=${False}
                                fi
                                ;;
                        SBU_SOURCE_HOST)
                                CloneSourceHost=${Value}
                                ;;
                        SBU_SOURCE_DB_SID)
                                CloneSourceSid=${Value}
                                ;;
                        SBU_CLONE_HOST)
                                CloneMountHost=${Value}
                                ;;
                        SBU_CLONE_DB_SID)
                                CloneMountSid=${Value}
                                ;;
                        RMAN_DG_2ND_ORACLE_SID)
                                DG_2nd_ORACLE_SID=${Value}
                                ;;
                        RMAN_DG_2ND_AVAMAR_AVTAR_FILE)
                                DG_2nd_AvamarAvtarFile=${Value}
                                ;;
                        RMAN_TDPO_OPTFILE)
                                TDPO_OPTFILE=${Value}
                                ;;
                        RMAN_TABLESPACE)
                                (( TablespaceI = TablespaceI + 1 ))
                                Tablespace[${TablespaceI}]=${Value}
                                ;;
                        RMAN_SPFILE_BKUPDIR|RMAN_SPFILE_BKUP_DIR)
                                SPFileBkupDir=${Value}
                                ;;
                        RMAN_DBF_BKUPDIR)
                                (( DbfBkupDirI = DbfBkupDirI + 1 ))
                                DbfBkupDir[${DbfBkupDirI}]=${Value}
                                ;;
                        RMAN_ARC_BKUPDIR)
                                (( ArcBkupDirI = ArcBkupDirI + 1 ))
                                ArcBkupDir[${ArcBkupDirI}]=${Value}
                                ;;
                        RMAN_BACKUP_DIR)
                                BackupDir=${Value}
                                ;;
                        RMAN_FILENAME_FORMAT)
                                FileNameFormat=${Value}
                                ;;
                        # Added to handle GG installation with 2 archive destinations, where the GG could not be deleted.
                        # (J.Thorn - 06/19/09)
                        RMAN_ARC_DEST_DIR)
                                ArchiveDestBackup="like '${Value}/%'"
                                ArchiveDestBackupDir="${Value}"
                                ;;
                        # Added to provide email for BKUPARC
                        RMAN_BKUPARC_EMAIL)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        BkupArcEmail=${True}
                                fi
                                ;;
                        RMAN_BKUPCTL_EMAIL)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        BkupCtlEmail=${True}
                                fi
                                ;;
                        RMAN_AVAMAR_AVTAR_FILE)
                                AvamarAvtarFile=$(echo ${Value} | ${AWK} '{print $1}')
                                ;;
# only used for v.226, then commented out.
# added back for V.231+
                        RMAN_AVAMAR_UPDATE_AVTAR_FILE)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        AvamarFileUpdate=${True}
                                else
                                        AvamarFileUpdate=${False}
                                fi
                                ;;
                        RMAN_DDBOOST_STORAGE)
                                DDBoostStorage=$(echo ${Value} | ${AWK} '{print $1}')
                                ;;
                        RMAN_DDBOOST_BKUP_HOST)
                                DDBoostBkupHost=$(echo ${Value} | ${AWK} '{print $1}')
                                ;;
                        RMAN_RUN_ORARMAN_BLD_RECOVERY)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        RunBldRecovery=${True}
                                fi
                                ;;
                        RMAN_NOTIFY_EMAIL_MONITOR)
                                NotifyEmailMonitor=${Value}
                                ;;
                        RMAN_NOTIFY_EMAIL_MONITOR_FLAG)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "NO" || "${Value}" = "FALSE" || "${Value}" = "OFF" || "${Value}" = "${False}" ]]
                                then
                                        NotifyEmailMonitor_Flag=${False}
                                fi
                                ;;
                        RMAN_EDS_LOGGER)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        EDSLogger=${True}
                                fi
                                ;;
                        RMAN_BYPASS_EBR_VIP_CHECK)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        BypassEbrVipChk=${True}
                                fi
                                ;;
                        RMAN_DEBUG)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        Debug=${True}
                                        set -xv
                                fi
                                ;;
                        RMAN_VERBOSE)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        Verbose=${True}
                                fi
                                ;;
                        DEBUG)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        Debug=${True}
                                        DebugOpt="-D"
                                        set -xv
                                fi
                                ;;
                        VERBOSE)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
                                if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
                                then
                                        Verbose=${True}
                                        VerboseOpt="-V"
                                fi
                                ;;
                        *)
                                continue
                                ;;
                esac
        done < ${ConfigFile}

        # This is required to handle a instance specific config file
        # over ruleing a global config file.
        if (( TablespaceI > 0 ))
        then
                TablespaceCnt=${TablespaceI}
        fi

        if (( DbfBkupDirI > 0 ))
        then
                DbfBkupDirCnt=${DbfBkupDirI}
        fi

        if (( ArcBkupDirI > 0 ))
        then
                ArcBkupDirCnt=${ArcBkupDirI}
        fi

        return 0

} # End of ReadConfigFile


#-----------------------------------------------------------------------------
# Function   : DiskFree
# Description: Perform a "df -k", or equivalent and reports the filesystem
#              mount point and the amount of space available.
#-----------------------------------------------------------------------------
function DiskFree
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: DiskFree ${*}" >&2

        typeset Filesystem=${1}
        typeset WrapFlag=${False}
        typeset Available
        typeset Mounted
        typeset Total

        ${DF} ${Filesystem} 2>/dev/null | grep -iv '^filesystem' |
        while read Line
        do
                set -- ${Line}
                if (( ${#} == 1 ))
                then
                        WrapFlag=${True}
                        continue
                fi

                if [[ ${WrapFlag} = ${False} ]]
                then
                        Total="${2}"
                        Available=${4}
                        Mounted="${6}"
                else
                        Total="${1}"
                        Available=${3}
                        Capacity="${4}"
                        Mounted="${5}"
                        WrapFlag=${False}
                fi

                echo "${Mounted}" "${Total}" "${Available}"

        done

} # End of function: DiskFree

#-----------------------------------------------------------------------------
# Function   : AcquireLock
# Description: Use a lock file to make sure on only one of these is running
#              at one time.  Store the process id in the lock file so that
#              we can handle stale locks from a crash.
#----------------------------------------------------------------------------
function AcquireLock
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: AcquireLock ${*}" >&2

        typeset -u Command=${1}
        typeset StaleLock
        typeset LockPid
        typeset RunPid
        typeset ReturnCode

        # Setup the Lock Directory
        if [[ ! -d ${LockDir} ]]
        then
                mkdir -p ${LockDir} 2>/dev/null
        fi
        if [[ ! -w ${LockDir} ]]
        then
                LockDir=/tmp
        fi

        # If backup BKUPFRA is running, we need to make sure that BKUPDB is not running.
        # Also, if MONFRA is running, we do not want to execute if we are running a BKUPFRA or BKUPDB

        if [[ ${Command} = "BKUPFRA" || ${Command} = "MONFRA" ]]
        then
                LockFile=${LockDir}/${ScriptName}_${ORACLE_SID}_BKUPDB.lck
        else
                LockFile=${LockDir}/${ScriptName}_${ORACLE_SID}_${Command}.lck
        fi

        if [[ ${Verbose} = ${True} ]]
        then
                print "Lock File: ${LockFile}" >&2
        fi





        if [[ ! -f ${LockFile} ]]
        then
                # Try to acquire the lock
                print "${Pid}" > ${LockFile}
                ReturnCode=${?}
                if (( ${ReturnCode} != 0 ))
                then
                        ReportMsg "" "Unable to create a lock file: ${LockFile}"
                        return 1
                fi
                for i in 1 2 3
                do
                        LockPid=$(cat ${LockFile} 2>/dev/null)
                        if [[ ${Pid} != ${LockPid} ]]
                        then
                                ReportMsg "" "Unable to Acquire a lock to start"
                                return 1
                        fi
                        sleep 1
                done
        else
                # Check to see if the lock is valid or stale
                StaleLock=${False}
                for i in 1 2 3
                do
                        if [[ -n ${RunPid} ]]
                        then
                                unset RunPid
                        fi
                        LockPid=$(cat ${LockFile} 2>/dev/null)
                        if [[ -n ${LockPid} ]]
                        then
                                RunPid=$(${PS} -p ${LockPid} | grep ${LockPid} | ${AWK} '{print $2}')
                        fi
                        if [[ ${RunPid} != ${LockPid} ]]
                        then
                                StaleLock=${True}
                        else
                                StaleLock=${False}
                                break
                        fi
                        sleep 1
                done


                if [[ ${StaleLock} = ${False} ]]
                then
                        ReportMsg "" "Process already running"
                        return 1
                else
                        ReportMsg "WARNING" "Lock appears to be stale, removing it"
                        rm -f ${LockFile}

                        # Try to acquire the lock
                        print "${Pid}" > ${LockFile}
                        ReturnCode=${?}
                        if (( ${ReturnCode} != 0 ))
                        then
                                ReportMsg "" "Unable to create a Lock file: ${LockFile}"
                                return 1
                        fi
                        for i in 1 2 3
                        do
                                LockPid=$(cat ${LockFile} 2>/dev/null)
                                if [[ ${Pid} != ${LockPid} ]]
                                then
                                        ReportMsg "" "Unable to acquire a lock to start"
                                        return 1
                                fi
                                sleep 1
                        done
                fi
        fi

        CleanupLock=${True}

        return 0

} # End of AcquireLock


#----------------------------------------------------------------------------
# Name: RunSql
# Desc: Run a SQL Command and leave output in the temp file, for the calling
#       routine to get, and set SqlError, if an error was detected.
#----------------------------------------------------------------------------
function RunSql
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: RunSql ${*}" >&2

        typeset SqlCommand="${*}"
        typeset SqlError=0

        ${ORACLE_HOME}/bin/sqlplus -silent /nolog <<-EOF > ${TmpFile1} 2>&1
                SET SQLPROMPT "SQL> ";
                CONNECT ${SqlConnect};
                WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK;
                SET ECHO ON
                SET LINESIZE 512
                SET PAGESIZE 0
                ${SqlCommand}
                EXIT;
        EOF
        ExitStatus=${?}
        if (( ${ExitStatus} == 0 ))
        then
                egrep '(ORA-|ERROR:)' ${TmpFile1} > /dev/null 2>&1
                ExitStatus=${?}
                if (( ${ExitStatus} == 0 ))
                then
                        SqlError=1
                fi
        else
                SqlError=1
        fi

        # Append the tempfile to the scripts trace file so that there is some
        # history for debuging.
        print "\nFrom Function: RunSql" >> ${TrcFile} 2>&1
        print "${SqlCommand}\n" >> ${TrcFile} 2>&1
        cat ${TmpFile1} >> ${TrcFile} 2>&1

        return ${SqlError}

} # End of RunSql


#----------------------------------------------------------------------------
# Name: InstanceStatus
# Desc: Make sure the instance is running and determine if is in ARCHIVELOG
#       Mode.
#----------------------------------------------------------------------------
function InstanceStatus
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: InstanceStatus ${*}" >&2

        typeset SqlError
        typeset ReturnCode=0
        typeset Procs Proc Result
        typeset ProcCnt=0

        Procs=$(${PS} -e 2>/dev/null | cut -c1-132 | sed -e 's/ *$//' | grep -v grep | \
                egrep "ora_pmo._${ORACLE_SID}\$|ora_dbw._${ORACLE_SID}\$|ora_lgw._${ORACLE_SID}\$|ora_smo._${ORACLE_SID}\$")
        for Proc in pmo dbw lgw smo
        do
                echo ${Procs} | grep "ora_${Proc}._${ORACLE_SID}" >/dev/null 2>&1
                Result=${?}
                if (( ${Result} == 0 ))
                then
                        (( ProcCnt = ProcCnt + 1 ))
                fi
        done

        if (( ${ProcCnt} != 4 ))
        then
                ReportMsg "" "Instance is not running, or background processes missing!"
                ReturnCode=1
        fi

        if (( ${ReturnCode} == 0 ))
        then
                SqlConnect="/ as sysdba"
                SqlCommand="SELECT 'Cmd1:'||dbid||':'||open_mode||':'||log_mode||':'||database_role from v\$database;
                        SELECT 'Cmd2:'||banner FROM v\$version WHERE banner LIKE 'Oracle%Edition Release%';
                        SELECT distinct 'Cmd3:'||value FROM v\$parameter where name like 'log_archive_dest_%' and lower(value) like '%location%';
                        SELECT 'Cmd4:'||value FROM v\$parameter WHERE name like 'log_archive_dest' and value is not null;
                        SELECT 'Cmd5:'||value FROM v\$parameter where name = 'spfile' and value is not null;"

                RunSql "${SqlCommand}"
                SqlError=${?}

                if (( ${SqlError} != 0 ))
                then
                        ReportMsg "" "Database connection failed, or SQL command failed!"
                        ReturnCode=1
                fi
        fi

        if (( ${ReturnCode} == 0 ))
        then
                DbId=$(grep "^Cmd1:" ${TmpFile1} | ${AWK} -F ':' '{print $2}')
                OpenMode=$(grep "^Cmd1:" ${TmpFile1} | ${AWK} -F ':' '{print $3}')
                LogMode=$(grep "^Cmd1:" ${TmpFile1} | ${AWK} -F ':' '{print $4}')
                DBRole=$(grep "^Cmd1:" ${TmpFile1} | ${AWK} -F ':' '{print $5}')
                Release=$(grep "^Cmd2:" ${TmpFile1} | sed -e 's/.*Release //' -e 's/ .*//')
                MajorRel=$(echo ${Release} | ${AWK} -F '.' '{print $1}')
                if [[ "${LogMode}" != "NOARCHIVELOG" && "${LogMode}" != "ARCHIVELOG" ]]
                then
                        ReportMsg "" "Failed to determine ARCHIVELOG mode!"
                        ReturnCode=1
                else
                        if [[ "${LogMode}" = "ARCHIVELOG" ]]
                        then
                                #----------------------------------------------------------------------
                                # Parameter can be specified in several ways
                                #----------------------------------------------------------------------
                                # log_archive_dest_n = LOCATION=/oraarch/pkg1/fs101/dbsid/ ...
                                # log_archive_dest_n = LOCATION="/oraarch/pkg1/fs101/dbsid/" ...
                                # log_archive_dest_n = location="/oraarch/pkg1/fs101/dbsid/", ...
                                # log_archive_dest_n = location=use_db_recovery_file_dest ...
                                # log_archive_dest_n = SERVICE=servicename ...
                                # log_archive_dest = /oraarch/pkg1/fs101/dbsid/
                                #----------------------------------------------------------------------
                                ArcLogDestDir=$(grep -i "^Cmd3:locat" ${TmpFile1} | head -n 1 | ${AWK} '{print $1}' | sed -e 's/.*=//' -e 's/\"//g' -e 's/,//g')
                                if [[ -z ${ArcLogDestDir} ]]
                                then
                                        ArcLogDestDir=$(grep "^Cmd4:" ${TmpFile1} | head -n 1 | sed -e 's/^Cmd4://' -e 's/ *$//')
                                fi

                                # If part of the log format is on the destination, strip it off.
                                ArcLogDestType=$(echo ${ArcLogDestDir} | tr '[:upper:]' '[:lower:]')
                                if [[ ${ArcLogDestType} = "use_db_recovery_file_dest" ]]
                                then
                                        ArcLogDestType="FRA"
                                #
                                # if .cfg paramerter rman_arc_dest_dir is set, then this is the directory that we want to evaluate
                                #
                                elif [[ ! -z ${ArchiveDestBackupDir} ]]
                                then
                                        ArcLogDestDir=${ArchiveDestBackupDir}
                                elif [[ ! -d ${ArcLogDestDir} ]]
                                then
                                        ArcLogDestDir=$(dirname "${ArcLogDestDir}")
                                fi
                        fi

                        DGStandby=$(echo ${DBRole} | grep "STANDBY" 2>/dev/null)
                        if [[ -z ${DGStandby} ]]
                        then
                                DGStandby=${False}
                        else
                                DGStandby=${True}
                        fi

                        SPFileName=$(grep "^Cmd5:" ${TmpFile1} | sed -e 's/^Cmd5://' -e 's/ *$//')
                        if [[ -n "${SPFileName}" ]] && [[ ${Command} = "BKUPDB" || ${Command} = "BKUPTS" || ${Command} = "BKUPCTL" ]]
                        then
                                SqlConnect="/ as sysdba"
                                SqlCommand="CREATE PFILE='${SPFileBkupName}' from SPFILE='${SPFileName}';"
                                RunSql "${SqlCommand}"
                                SqlError=${?}
                                if (( ${SqlError} != 0 ))
                                then
                                        ReportMsg "" "SPFILE Backup Failed, or SQL command failed!"
                                        ReturnCode=1
                                fi
                        fi
                fi
        fi
     #
        # Identify database name
        #
        SqlConnect="/ as sysdba"
        SqlCommand="select 'Value:'||lower(name) from v"'$database'";"
        RunSql "${SqlCommand}"
        SqlError=${?}
        if (( ${SqlError} != 0 ))
        then
                ReportMsg "" "SPFILE Backup Failed, or SQL command failed!"
                ReturnCode=1
        fi
        DatabaseName=$(grep "^Value:" ${TmpFile1} | awk -F':' '{print $2}')

        if [[ ${Verbose} = ${True} ]]
        then
                print "Release: ${Release}"
                print "DBID: ${DbId}"
                print "OpenMode: ${OpenMode}"
                print "LogMode: ${LogMode}"
                print "DatabaseRole: ${DBRole}"
                print "DatabaseName: ${DBName}"
                print "ArcLogDestDir: ${ArcLogDestDir}"
                print "SPFileName: ${SPFileName}"
                print "Function: InstanceStatus, Return Code: ${ReturnCode}"
        fi

        return ${ReturnCode}

} # End of InstanceStatus


#----------------------------------------------------------------------------
# Name: SetMediaVendorEnv
# Desc: Setup Environment for the Media Vendor
#----------------------------------------------------------------------------
function SetMediaVendorEnv
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: SetMediaVendorEnv ${*}" >&2

        typeset Command=${1}
        typeset MediaVendor=${2}
        typeset ReturnCode=0
        typeset ParmsOpt
        typeset SBTLibraryTmp

        if [[ -n ${BlkSize} ]]
        then
                if [[ -z ${ParmsOpt} ]]
                then
                        ParmsOpt="BLKSIZE=${BlkSize}"
                else
                        ParmsOpt="${ParmsOpt},BLKSIZE=${BlkSize}"
                fi
        fi
        if [[ -n ${SBTLibrary} ]]
        then
                if [[ -r ${SBTLibrary} ]]
                then
                        if [[ ${OSName} = "AIX" && ${FixAIXSBTLibrary} = ${True} ]]
                        then
                                SBTLibraryTmp="${SBTLibrary}(shr.o)"
                        else
                                SBTLibraryTmp="${SBTLibrary}"
                        fi
                        if [[ -z ${ParmsOpt} ]]
                        then
                                ParmsOpt="SBT_LIBRARY=${SBTLibraryTmp}"
                        else
                                ParmsOpt="${ParmsOpt},SBT_LIBRARY=${SBTLibraryTmp}"
                        fi
                elif [[ ${MediaVendor} = "DUMMY" ]]
                then
                        if [[ -z ${ParmsOpt} ]]
                        then
                                ParmsOpt="SBT_LIBRARY=${SBTLibrary}"
                        else
                                ParmsOpt="${ParmsOpt},SBT_LIBRARY=${SBTLibrary}"
                        fi
                else
                        ReportMsg "" "SBT_LIBRARY File Not Found or Not Readable: ${SBTLibrary}"
                        ReturnCode=1
                fi
        fi

        case ${MediaVendor} in

                DDBOOST)
                        Parms="PARMS='${ParmsOpt}'"
                        if [[ -z ${DDBoostStorage} || -z ${DDBoostBkupHost} ]]
                        then
                                ReportMsg "" "Missing .cfg file paremeters RMAN_DDBOOST_STORAGE_HOST and RMAN_DDBOOST_BKUP_SERVER";
                                ReturnCode=1
                        else
                                if [[ -z ${ParmsOpt} ]]
                                then
                                        Parms="PARMS='ENV=(STORAGE_UNIT=${DDBoostStorage}, BACKUP_HOST=${DDBoostBkupHost}, ORACLE_HOME=${ORACLE_HOME})'"
                                else
                                        Parms="PARMS='${ParmsOpt},ENV=(STORAGE_UNIT=${DDBoostStorage}, BACKUP_HOST=${DDBoostBkupHost}, ORACLE_HOME=${ORACLE_HOME})'"
                                fi
                        fi
                        ;;
                AVAMAR)
                        Parms="PARMS='${ParmsOpt}'"
                        AvamarGrid=`head -1 /usr/local/avamar/var/cid.bin`
                        ExitCode=${?}
                        if (( ${ExitCode} != 0 ))
                        then
                                CleanupAndExit ${ExitCode}
                        fi
#
#                       Code and ChkAvamarPath function was used for 1000+ database where Avamar domain
#                       was changed, and we wanted to automte this avamar flags file change without
#                       manual action by the DBA.  The log file is not a reliable source, so after the
#                       change, we removed this check by commenting out the call.
#
                        if [[ ${AvamarFileUpdate} = ${True} ]]
                        then
                                ChkAvamarFlagsFile
                                ExitCode=${?}
                                if (( ${ExitCode} != 0 ))
                                then
                                        CleanupAndExit ${ExitCode}
                                fi
                        fi

                        RAC_Check
                        ExitCode=${?}
                        if (( ${ExitCode} != 0 ))
                        then
                                CleanupAndExit ${ExitCode}
                        fi
                        ;;
                TSM)
                        if [[ -z ${TDPO_OPTFILE} ]]
                        then
                                ReportMsg "" "Missing TSM TDPO_OPTFILE file"
                                ReturnCode=1
                        else
                                if [[ -z ${ParmsOpt} ]]
                                then
                                        Parms="PARMS='ENV=(TDPO_OPTFILE=${TDPO_OPTFILE})'"
                                else
                                        Parms="PARMS='${ParmsOpt},ENV=(TDPO_OPTFILE=${TDPO_OPTFILE})'"
                                fi
                        fi
                        ;;
                NETBACKUP)
                        if [[ -f /usr/openv/netbackup/bp.conf ]]
                        then
                                BpConf=/usr/openv/netbackup/bp.conf
                        elif [[ -f /opt/openv/netbackup/bp.conf ]]
                        then
                                BpConf=/opt/openv/netbackup/bp.conf
                        fi

                        if [[ -z ${NB_ORA_SERV} ]]
                        then
                                if [[ ${DbfClone} = ${True} && -n ${CloneNBOraServ} ]]
                                then
                                        NB_ORA_SERV=${CloneNBOraServ}
                                elif [[ -n ${NBOraServ} ]]
                                then
                                        NB_ORA_SERV=${NBOraServ}
                                else
                                        if [[ -r ${BpConf} ]]
                                        then
                                                NB_ORA_SERV=$(grep "^SERVER = " ${BpConf} 2>/dev/null | head -1 | ${AWK} '{print $3}')
                                        fi
                                fi
                        fi

                        if [[ -z ${NB_ORA_CLIENT} ]]
                        then
                                if [[ ${DbfClone} = ${True} && -n ${CloneNBOraClient} ]]
                                then
                                        NB_ORA_CLIENT=${CloneNBOraClient}
                                elif [[ -n ${NBOraClient} ]]
                                then
                                        NB_ORA_CLIENT=${NBOraClient}
                                else
                                        if [[ -r ${BpConf} ]]
                                        then
                                                NB_ORA_CLIENT=$(grep "^CLIENT_NAME = " ${BpConf} 2>/dev/null | head -1 | ${AWK} '{print $3}')
                                        fi
                                fi
                        fi
                        # Strip off the domain
                        ShortName=${NB_ORA_CLIENT%%.*}

                        if [[ -z ${NB_ORA_POLICY} ]]
                        then
                                case ${Command} in
                                        BKUPDB|BKUPTS|BKUPFRA|BKUPCTL)
                                                if [[ ${DbfClone} = ${True} && -n ${CloneDbfNBOraPolicy} ]]
                                                then
                                                        NB_ORA_POLICY=${CloneDbfNBOraPolicy}
                                                        NB_ORA_CLASS=${CloneDbfNBOraPolicy}
                                                elif [[ -n ${DbfNBOraPolicy} ]]
                                                then
                                                        NB_ORA_POLICY=${DbfNBOraPolicy}
                                                        NB_ORA_CLASS=${DbfNBOraPolicy}
                                                elif [[ -n ${NBOraPolicy} ]]
                                                then
                                                        NB_ORA_POLICY=${NBOraPolicy}
                                                        NB_ORA_CLASS=${NBOraPolicy}
                                                else
                                                        NB_ORA_POLICY="${ShortName}_${ORACLE_SID}"
                                                        NB_ORA_CLASS="${ShortName}_${ORACLE_SID}"
                                                fi
                                                if [[ ${Command} = "BKUPFRA" && ${BkupFraUseArchPolicy} = ${True} ]]
                                                then
                                                        if [[ -n ${ArcNBOraPolicy} ]]
                                                        then
                                                                NB_ORA_POLICY=${ArcNBOraPolicy}
                                                                NB_ORA_CLASS=${ArcNBOraPolicy}
                                                        fi
                                                fi
                                                ;;
                                        BKUPARC)
                                                if [[ -n ${ArcNBOraPolicy} ]]
                                                then
                                                        NB_ORA_POLICY=${ArcNBOraPolicy}
                                                        NB_ORA_CLASS=${ArcNBOraPolicy}
                                                elif [[ -n ${NBOraPolicy} ]]
                                                then
                                                        NB_ORA_POLICY=${NBOraPolicy}
                                                        NB_ORA_CLASS=${NBOraPolicy}
                                                else
                                                        NB_ORA_POLICY="${ShortName}_${ORACLE_SID}_arch"
                                                        NB_ORA_CLASS="${ShortName}_${ORACLE_SID}_arch"
                                                fi
                                                ;;
                                esac
                        fi

                        # The default Schedule name is Default-Application-Backup, NBU environment was fixed
                        # so the default has been changed from Default-Policy to Default-Application-Backup
                        if [[ -z ${NB_ORA_SCHED} ]]
                        then
                                case ${Command} in
                                        BKUPDB|BKUPTS|BKUPFRA|BKUPCTL)
                                                if [[ ${DbfClone} = ${True} && -n ${CloneDbfNBOraSched} ]]
                                                then
                                                        NB_ORA_SCHED=${CloneDbfNBOraSched}
                                                elif [[ -n ${DbfNBOraSched} ]]
                                                then
                                                        NB_ORA_SCHED=${DbfNBOraSched}
                                                elif [[ -n ${NBOraSched} ]]
                                                then
                                                        NB_ORA_SCHED=${NBOraSched}
                                                else
                                                        NB_ORA_SCHED="Default-Application-Backup"
                                                fi
                                                ;;
                                        BKUPARC)
                                                if [[ -n ${ArcNBOraSched} ]]
                                                then
                                                        NB_ORA_SCHED=${ArcNBOraSched}
                                                elif [[ -n ${NBOraSched} ]]
                                                then
                                                        NB_ORA_SCHED=${NBOraSched}
                                                else
                                                        NB_ORA_SCHED="Default-Application-Backup"
                                                fi
                                                ;;
                                esac
                        fi


                        if [[ -z ${ParmsOpt} ]]
                        then
                                Parms="PARMS='ENV=(NB_ORA_SERV=${NB_ORA_SERV},NB_ORA_CLIENT=${NB_ORA_CLIENT},NB_ORA_POLICY=${NB_ORA_POLICY},NB_ORA_SCHED=${NB_ORA_SCHED})'"
                        else
                                Parms="PARMS='${ParmsOpt},ENV=(NB_ORA_SERV=${NB_ORA_SERV},NB_ORA_CLIENT=${NB_ORA_CLIENT},NB_ORA_POLICY=${NB_ORA_POLICY},NB_ORA_SCHED=${NB_ORA_SCHED})'"
                        fi

#                       Assignment for RESTOREVAL function, to create a 2nd channel to access backups from the OffHost server.
#                       if running RESTOREVAL on Clone, then set the 2nd channel as Primary DB server.
#
                        if [[ ${DbfClone} = ${True} ]]
                        then
                                NB_ORA_2nd_CLIENT=${NBOraClient}
                        elif [[ -n ${CloneNBOraClient} ]]
                        then
                                NB_ORA_2nd_CLIENT=${CloneNBOraClient}
                        fi
#
#                       For RESTVAL function create a 2nd Channel if a Off Host Backup
#
                        if [[ ${Command} = "RESTOREVAL" && -n ${NB_ORA_2nd_CLIENT} ]]
                        then
                                if [[ -z ${ParmsOpt} ]]
                                then
                                        Parms2="PARMS='ENV=(NB_ORA_SERV=${NB_ORA_SERV},NB_ORA_CLIENT=${NB_ORA_2nd_CLIENT})'"
                                else
                                        Parms2="PARMS='${ParmsOpt},ENV=(NB_ORA_SERV=${NB_ORA_SERV},NB_ORA_CLIENT=${NB_ORA_2nd_CLIENT})'"
                                fi
                        fi
                        if [[ ${Command} = "BKUPDB" && ${DbfProxyCopy} = ${True} ]]
                        then
                                if [[ -z ${DbfNBOraPCSched} || -z ${DbfNBOraPCStreams} ]]
                                then
                                        ReportMsg "" "Both RMAN_NB_ORA_PC_SCHED and RMAN_NB_ORA_PC_STREAMS must be set for Proxy Copy"
                                        ReturnCode=1
                                else
                                        NB_ORA_PC_SCHED=${DbfNBOraPCSched}
                                        NB_ORA_PC_STREAMS=${DbfNBOraPCStreams}
                                fi
                        fi
#
#                       This section provides the option of a BKUPDB to FRA without checking to see if the EBR vip is running
#                       on the current RAC node. If the RMAN_BYPASS_EBR_VIP_CHECK .cfg parameter is set to TRUE, then we
#                       will check to see if it is a BKUPDB to FRA.  And if so, we will let it proceed without checking to
#                       to see if the floating EBR vip exists on the current server.
#
                        if [[ ${BypassEbrVipChk} = ${True} ]]
                        then
                           echo "BypassEbrVipChk is True"
                           if [[ ! ( ${ChanType} = "DISK" && ${Command} = "BKUPDB" ) ]] then
                                echo "Running RAC_Check because this job runs to Tape"
                                RAC_Check
                                ExitCode=${?}
                                if (( ${ExitCode} != 0 ))
                                then
                                        CleanupAndExit ${ExitCode}
                                fi

                            fi
                        else
                                RAC_Check
                                ExitCode=${?}
                                if (( ${ExitCode} != 0 ))
                                then
                                        CleanupAndExit ${ExitCode}
                                fi
                        fi
                        ;;
                DUMMY)
                        if [[ -z ${BackupDir} ]]
                        then
                                ReportMsg "" "Missing Oracle Dummy API BACKUP_DIR"
                                ReturnCode=1
                        else
                                if [[ -z ${ParmsOpt} ]]
                                then
                                        Parms="PARMS='ENV=(BACKUP_DIR=${BackupDir})'"
                                else
                                        Parms="PARMS='${ParmsOpt},ENV=(BACKUP_DIR=${BackupDir})'"
                                fi
                        fi
                        ;;
                *)
                        if [[ -z ${ParmsOpt} ]]
                        then
                                Parms=""
                        else
                                Parms="PARMS='${ParmsOpt}'"
                        fi
        esac

        if [[ ${Verbose} = ${True} ]]
        then
                print "Function: SetMediaVendorEnv ${Command}, Return Code: ${ReturnCode}"
        fi

        return ${ReturnCode}

} # End of SetMediaVendorEnv


#-----------------------------------------------------------------------------
# Function   : GenCmdFile
# Description: Create the RMAN Command File to execute.
#-----------------------------------------------------------------------------
function GenCmdFile
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: GenCmdFile ${*}" >&2

        typeset -u Command=${1}
        typeset ReturnCode=0

        print "${ORACLE_HOME}/bin/rman cmdfile ${CmdFile}" >> ${LogFile} 2>&1
        print "\n# CMDFILE BEGIN:" >> ${LogFile} 2>&1

        print "connect target;" > ${CmdFile} 2>&1

        if [[ ${CatActive} = ${True} ]]
        then
                # Confirm that the RMAN catalog connection is available, if not send a warning email and continue.
                if [[ -n ${CatSchema} && -n ${CatPassword} && -n ${CatAlias} ]]
                then
                        SqlConnect="${CatSchema}/${CatPassword}@${CatAlias}"
                        RunSql "SELECT 'User:'||USER FROM DUAL;"
                        SqlError=${?}
                        if (( ${SqlError} == 0 ))
                        then
                                print "connect catalog ${CatSchema}/${CatPassword}@${CatAlias};" >> ${CmdFile} 2>&1
                        else
                                if [[ ${Command} != "SHOWALL"  ]]
                                then
                                        ReportMsg "WARNING" "The RMAN Catalog connection failed, executing orarman -c ${Command} with out connection to RMAN catalog"
                                fi
                        fi
                else
                        if [[ ${Command} != "SHOWALL"  ]]
                        then
                                ReportMsg "WARNING" "The RMAN Catalog connection failed. RMAN Catalog variables undefined, executing orarman -c ${Command} without connection to RMAN catalog"
                        fi
                fi
        fi
        if [[ ${Command} != "SHOWALL"  ]]
        then
                SetMediaVendorEnv ${Command} ${MediaVendor}
                ReturnCode=${?}
        fi

        case ${Command} in
                BKUPDB|BKUPTS)
                        print "show all;" >> ${CmdFile} 2>&1
                        DBBkupCmds
                        ReturnCode=${?}
                        ;;
                BKUPARC)
                        print "show all;" >> ${CmdFile} 2>&1
                        ArcBkupCmds
                        ReturnCode=${?}
                        ;;
                BKUPFRA)
                        print "show all;" >> ${CmdFile} 2>&1
                        FRABkupCmds
                        ReturnCode=${?}
                        ;;
                BKUPCTL)
                        CtlBkupCmds
                        ReturnCode=${?}
                        ;;
                RESTOREVAL)
                        print "show all;" >> ${CmdFile} 2>&1
                        RestoreValidateCmds
                        ReturnCode=${?}
                        ;;
                RESYNCCAT)
                        print "resync catalog;" >> ${CmdFile} 2>&1
                        ;;
                SHOWALL)
                        print "show all;" >> ${CmdFile} 2>&1
                        ;;
                DELOBSOLETE)
                        print "show all;" >> ${CmdFile} 2>&1
                        DelObsolete=${True}
                        DeleteCmds
                        ReturnCode=${?}
                        ;;
                DELEXPIRED)
                        print "show all;" >> ${CmdFile} 2>&1
                        DelExpired=${True}
                        DeleteCmds
                        ReturnCode=${?}
                        ;;
                UNREGDB)
                        print "unregister database noprompt;" >> ${CmdFile} 2>&1
                        ;;
                REGDB)
                        print "register database;" >> ${CmdFile} 2>&1
                        print "configure retention policy to recovery window of 35 days;" >> ${CmdFile} 2>&1
                        ;;
                CRCAT)
                        print "create catalog;" >> ${CmdFile} 2>&1
                        ;;
                CHGARCXCHK)
                        print "change archivelog all crosscheck;" >> ${CmdFile} 2>&1
                        ;;
        esac

        if [[ -n ${PostRunSQL} ]]
        then
                print "sql '${PostRunSQL}';" >> ${CmdFile} 2>&1
        fi

        print "exit;" >> ${CmdFile} 2>&1

        cat ${CmdFile} >> ${LogFile} 2>&1
        print "# CMDFILE END:\n" >> ${LogFile} 2>&1

        if [[ ${Verbose} = ${True} ]]
        then
                print "Function: GenCmdFile ${Command}, Return Code: ${ReturnCode}"
        fi

        return ${ReturnCode}

} # End of GenCmdFile


#-----------------------------------------------------------------------------
# Function   : DBBkupCmds
# Description: Backup the Database
#-----------------------------------------------------------------------------
function DBBkupCmds
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: DBBkupCmds ${*}" >&2

        typeset ReturnCode=0

        if [[ -n ${DbfChanType} ]]
        then
                ChanType=${DbfChanType}
        elif [[ -z ${ChanType} ]]
        then
                if [[ ${MediaVendor} = "TSM" || ${MediaVendor} = "NETBACKUP" || ${MediaVendor} = "AVAMAR" || ${MediaVendor} = "DDBOOST" || ${MediaVendor} = "DUMMY" ]]
                then
                        ChanType=sbt_tape
                elif [[ ${MediaVendor} = "NONE" ]]
                then
                        ChanType=DISK
                else
                        ReportMsg "WARNING" "Unable to determine correct channel type to use"
                        (( ReturnCode = ReturnCode + 1 ))
                fi
        fi

        # Determine if and what to set the FILESPERSET option to.
        if (( ${FilesPerSetOpt} > 0 ))
        then
                FilesPerSetCmd="filesperset ${FilesPerSetOpt}"
        elif (( ${DbfFilesPerSet} > 0 ))
        then
                FilesPerSetCmd="filesperset ${DbfFilesPerSet}"
        elif (( ${FilesPerSet} > 0 ))
        then
                FilesPerSetCmd="filesperset ${FilesPerSet}"
        else
                if [[ -n ${FilesPerSetCmd} ]]
                then
                        unset FilesPerSetCmd
                fi
        fi

        # Determine if and what to set the MAXSETSIZE option to.
        if [[ -n ${DbfMaxSetSize} ]]
        then
                MaxSetSizeCmd="maxsetsize ${DbfMaxSetSize}"
        elif [[ -n ${MaxSetSize} ]]
        then
                MaxSetSizeCmd="maxsetsize ${MaxSetSize}"
        else
                if [[ -n ${MaxSetSizeCmd} ]]
                then
                        unset MaxSetSizeCmd
                fi
        fi

        # Determine if and what to set the SECTION SIZE option to.
        # To use this option, Oracle must be at 11G+ and we need to test for that
        #

        if [[ -n ${DbfSectionSize} ]] && (( ${MajorRel} > 10 ))
        then
                SectionSizeCmd="section size ${DbfSectionSize}"
        elif [[ -n ${SectionSize} ]] && (( ${MajorRel} > 10 ))
        then
                SectionSizeCmd="section size ${SectionSize}"
        else
                if [[ -n ${SectionSizeCmd} ]]
                then
                        unset SectionSizeCmd
                fi
        fi


        # Determine if and what to set the MAXOPENFILES option to.
        if [[ -n ${MaxOpenFilesOpt} ]]
        then
                MaxOpenFilesCmd="maxopenfiles=${MaxOpenFilesOpt}"
        elif [[ -n ${DbfMaxOpenFiles} ]]
        then
                MaxOpenFilesCmd="maxopenfiles=${DbfMaxOpenFiles}"
        elif [[ -n ${MaxOpenFiles} ]]
        then
                MaxOpenFilesCmd="maxopenfiles=${MaxOpenFiles}"
        else
                if [[ -n ${MaxOpenFilesCmd} ]]
                then
                        unset MaxOpenFilesCmd
                fi
        fi

        # Determine if and what to set the RATE option to.
        if [[ -n ${DbfRate} ]]
        then
                RateCmd="rate=${DbfRate}"
        elif [[ -n ${Rate} ]]
        then
                RateCmd="rate=${Rate}"
        else
                if [[ -n ${RateCmd} ]]
                then
                        unset RateCmd
                fi
        fi


        # Determine the Number of Channels to use.
        if [[ -n ${ChanCountOpt} ]]
        then
                ChanCount=${ChanCountOpt}
        elif [[ -n ${DbfChanCount} ]]
        then
                ChanCount=${DbfChanCount}
        elif (( ${ChanCount} == 0 ))
        then
                ChanCount=1
        fi

        # Determine the Number of Channels to use.
        if [[ -n ${DbfIncrTypeOpt} ]]
        then
                DbfIncrType=${DbfIncrTypeOpt}
        fi
        # Export it so the user_cmd script can see it.
        export DbfIncrType

        if [[ -n ${DbfLevelOpt} ]]
        then
                DbfLevel=${DbfLevelOpt}
        elif [[ -z ${DbfLevel} ]]
        then
                DbfLevel="full"
        fi
        #
        #  The following if block will call a fundtion to confirm that the
        # last level 0 was succesful, and if not, orarman may automatically
        # run a level 0 backup.  To make this check the
        # RMAN_Check_Prev_L0_Bkup(instance_SID.cfg param) must be set to True.
        #
        if [[ ${Command} = "BKUPDB" && ${DbfLevel} = "1"  ]]
        then
                ChkPrevL0Status
                if [[ ${MediaVendor} = "AVAMAR" ]]
                then
                        ChkAvamarFlgChgd
                fi
        fi
        # Export it so the user_cmd script can see it.
        export DbfLevel

        # Starting in Oracle 10.x Incremental Levels 2 - 4 are Obsolete.
        if (( ${MajorRel} >= 10 )) && [[ ${DbfLevel} = 2 || ${DbfLevel} = 3 || ${DbfLevel} = 4 ]]
        then
                DbfLevel="1"
                ReportMsg "WARNING" "Incremental Levels 2 - 4 are obsolete, using level=${DbfLevel}"
        fi
        case ${DbfLevel} in
                "0")
                        DbfLevelCmd="incremental level ${DbfLevel}"
                        ;;
                "1")
                        if [[ ${DbfIncrType} = "C" ]]
                        then
                                DbfLevelCmd="incremental level ${DbfLevel} cumulative"
                        else
                                DbfLevelCmd="incremental level ${DbfLevel}"
                        fi
                        ;;
                "2")
                        DbfLevelCmd="incremental level ${DbfLevel}"
                        ;;
                "3")
                        DbfLevelCmd="incremental level ${DbfLevel}"
                        ;;
                "4")
                        DbfLevelCmd="incremental level ${DbfLevel}"
                        ;;
                "full")
                        DbfLevelCmd=${DbfLevel}
                        ;;
                *)
                        DbfLevel="full"
                        DbfLevelCmd=${DbfLevel}
                        ReportMsg "WARNING" "Invalid Backup Level using level=${DbfLevel}"
                        ;;
        esac

        if [[ ${Verbose} = ${True} && ${ChanType} = 'DISK' ]]
        then
                I=0
                while (( ${I} < ${DbfBkupDirCnt} ))
                do
                        (( I = I + 1 ))
                        printf "DbfBkupDir %3.3s: %s\n" "${I}" "${DbfBkupDir[${I}]}"
                done
        fi
        print "run {" >> ${CmdFile} 2>&1

        if [[ ${CmdDebug} = ${True} ]]
        then
                print "\tdebug on; ">> ${CmdFile} 2>&1
                if [[ -n ${CmdDebugLvl} ]]
                then
                        CmdDebugOpt="debug=${CmdDebugLvl}"
                fi
        fi

        print "\tsql 'alter database backup controlfile to trace';" >> ${CmdFile} 2>&1

        # If the database is currently not Opened then the redo logs can't be switched.
        if [[ "${OpenMode}" = "READ WRITE" && "${DbfBkupType}" = "ONLINE" ]]
        then
                print "\tsql 'alter system archive log current';" >> ${CmdFile} 2>&1
        elif [[ "${OpenMode}" = "READ WRITE" && "${DbfBkupType}" != "ONLINE" ]]
        then
                print "\tsql 'alter system switch logfile';" >> ${CmdFile} 2>&1
        elif [[ ${DGStandby} = ${True} ]]
        then
                # If this is a DG Standby, label the RMAN Tag, and do not switch the logfile.
                BackupTag="${ORACLE_SID}_DGSB_${BackupTagDate}"
        fi
        if [[ ${DbfClone} = ${True} ]]
        then
                # If this Clone database, label the RMAN Tag.
                BackupTag="${ORACLE_SID}_CLN_${BackupTagDate}"
        fi

        if [[ "${OpenMode}" = "READ WRITE" && "${DbfBkupType}" = "OFFLINE" ]]
        then
                print "\tshutdown immediate;" >> ${CmdFile} 2>&1
                print "\tstartup mount;" >> ${CmdFile} 2>&1
        fi
        # Export it so that user_cmd can see it.
        export BackupTag

        if [[ ${ChanType} = 'DISK' ]]
        then
                if (( ${DbfBkupDirCnt} < ${ChanCount} ))
                then
                        if [[ ${FRAActive} = ${False} ]]
                        then
                                ReportMsg "WARNING" "Backup Directories < Channel Count, Using Channel Count = ${DbfBkupDirCnt}"
                        fi
                        ChanCount=${DbfBkupDirCnt}
                fi

                I=0
                while (( ${I} < ${ChanCount} ))
                do
                        (( I = I + 1 ))
                        print "\tallocate channel 't${I}' type ${ChanType} ${CmdDebugOpt} ${MaxOpenFilesCmd} ${RateCmd} ${Parms} format '${DbfBkupDir[${I}]}/dbf_%d_%s_%p_%t';" >> ${CmdFile} 2>&1
                done

                # Updated command id to be more descriptive - JThorn -7/20/09
                print "\tset command id to 'RMAN-BKUPDB Level ${DbfLevel}';" >> ${CmdFile} 2>&1

                # check to add Logical Corrupton check to backup command - JThorn - 01/12/10
                if [[ ${ChkLogCorrupt} = ${True} ]]
                then
                        print "\tbackup check logical " >> ${CmdFile} 2>&1
                else
                        print "\tbackup" >> ${CmdFile} 2>&1
                fi

                print "\t\t${DbfLevelCmd}" >> ${CmdFile} 2>&1
                if [[ -n ${FilesPerSetCmd} ]]
                then
                        print "\t\t${FilesPerSetCmd}" >> ${CmdFile} 2>&1
                fi
                if [[ -n ${SectionSizeCmd} ]]
                then
                        print "\t\t${SectionSizeCmd}" >> ${CmdFile} 2>&1
                elif [[ -n ${MaxSetSizeCmd} ]]
                then
                        print "\t\t${MaxSetSizeCmd}" >> ${CmdFile} 2>&1
                fi
                if [[ ${Command} = "BKUPTS" ]]
                then
                        if [[ ${BkupValidate} = ${False} ]]
                        then
                                print "\t\ttablespace" >> ${CmdFile} 2>&1
                        else
                                print "\t\tvalidate tablespace" >> ${CmdFile} 2>&1
                        fi
                        I=0
                        while (( ${I} < ${TablespaceCnt} ))
                        do
                                (( I = I + 1 ))
                                if (( ${I} == ${TablespaceCnt} ))
                                then
                                        print "\t\t\t${Tablespace[${I}]}" >> ${CmdFile} 2>&1
                                else
                                        print "\t\t\t${Tablespace[${I}]}," >> ${CmdFile} 2>&1
                                fi
                        done
                        if [[ ${BkupValidate} = ${False} && -n ${SkipDays} ]]
                        then
                                print "\t\tnot backed up since time = 'sysdate-${SkipDays}'" >> ${CmdFile} 2>&1
                        fi
                else
                        if [[ ${BkupValidate} = ${False} ]]
                        then
                                print "\t\tdatabase" >> ${CmdFile} 2>&1
                                if [[ -n ${SkipDays} ]]
                                then
                                        print "\t\tnot backed up since time = 'sysdate-${SkipDays}'" >> ${CmdFile} 2>&1
                                fi
                        else
                                print "\t\tvalidate database" >> ${CmdFile} 2>&1
                        fi
                fi
                if [[ ${DbfClone} = ${False} ]]
                then
                        print "\t\tinclude current controlfile" >> ${CmdFile} 2>&1
                fi
                print "\t\ttag = '${BackupTag}';" >> ${CmdFile} 2>&1


        elif [[ ${ChanType} = 'SBT_TAPE' ]]
        then
                I=0
                while (( ${I} < ${ChanCount} ))
                do
                        (( I = I + 1 ))
                        print "\tallocate channel 't${I}' type '${ChanType}' ${CmdDebugOpt} ${MaxOpenFilesCmd} ${RateCmd} ${Parms};" >> ${CmdFile} 2>&1
                        if [[ ${MediaVendor} = "AVAMAR" ]]
                        then
                                if (( ${ChanCount} > 10 ))
                                then
                                        ReportMsg "WARNING" "Channel Count was set to ${ChanCount}, Avamar maximum channel count is 10, value being reset for job run."
                                        ChanCount=10;
                                fi
                                print "\tsend channel='t${I}' '\"--flagfile=${LOCAL_BASE}/etc/${AvamarAvtarFile}\" \"--bindir=${AVAMAR_BASE}/bin\" \"--cacheprefix=${ORACLE_SID}_${I}\"';" >> ${CmdFile} 2>&1
                        fi
                done
                if [[ ${DbfProxyCopy} = ${True} && ${MediaVendor} = "NETBACKUP" ]]
                then
                        print "\tsend 'NB_ORA_PC_SCHED=${NB_ORA_PC_SCHED}';" >> ${CmdFile} 2>&1
                        print "\tsend 'NB_ORA_PC_STREAMS=${NB_ORA_PC_STREAMS}';" >> ${CmdFile} 2>&1
                fi

                # Updated command id to be more descriptive - JThorn -7/20/09
                print "\tset command id to 'RMAN-BKUPDB Level ${DbfLevel}';" >> ${CmdFile} 2>&1

                # Check Logical for corrupton detection
                if [[ ${ChkLogCorrupt} = ${True} ]]
                then
                        print "\tbackup check logical " >> ${CmdFile} 2>&1
                else
                        print "\tbackup" >> ${CmdFile} 2>&1
                fi

                if [[ ${DbfProxyCopy} = ${True} ]]
                then
                        print "\t\tproxy" >> ${CmdFile} 2>&1
                fi
                print "\t\t${DbfLevelCmd}" >> ${CmdFile} 2>&1
                if [[ -n ${FilesPerSetCmd} ]]
                then
                        print "\t\t${FilesPerSetCmd}" >> ${CmdFile} 2>&1
                fi
                if [[ -n ${SectionSizeCmd} ]]
                then
                        print "\t\t${SectionSizeCmd}" >> ${CmdFile} 2>&1
                elif [[ -n ${MaxSetSizeCmd} ]]
                then
                        print "\t\t${MaxSetSizeCmd}" >> ${CmdFile} 2>&1
                fi
                print "\t\tformat 'dbf_%d_%s_%p_%t'" >> ${CmdFile} 2>&1
                if [[ ${Command} = "BKUPTS" ]]
                then
                        if [[ ${BkupValidate} = ${False} ]]
                        then
                                print "\t\ttablespace" >> ${CmdFile} 2>&1
                        else
                                print "\t\tvalidate tablespace" >> ${CmdFile} 2>&1
                        fi
                        I=0
                        while (( ${I} < ${TablespaceCnt} ))
                        do
                                (( I = I + 1 ))
                                if (( ${I} == ${TablespaceCnt} ))
                                then
                                        print "\t\t\t${Tablespace[${I}]}" >> ${CmdFile} 2>&1
                                else
                                        print "\t\t\t${Tablespace[${I}]}," >> ${CmdFile} 2>&1
                                fi
                        done
                        if [[ ${BkupValidate} = ${False} && -n ${SkipDays} ]]
                        then
                                print "\t\tnot backed up since time = 'sysdate-${SkipDays}'" >> ${CmdFile} 2>&1
                        fi
                else
                        if [[ ${BkupValidate} = ${False} ]]
                        then
                                print "\t\tdatabase" >> ${CmdFile} 2>&1
                                if [[ -n ${SkipDays} ]]
                                then
                                        print "\t\tnot backed up since time = 'sysdate-${SkipDays}'" >> ${CmdFile} 2>&1
                                fi
                        else
                                print "\t\tvalidate database" >> ${CmdFile} 2>&1
                        fi
                fi
                if [[ ${DbfClone} = ${False} ]]
                then
                        print "\t\tinclude current controlfile" >> ${CmdFile} 2>&1
                fi
                print "\t\ttag = '${BackupTag}';" >> ${CmdFile} 2>&1
        fi

        # If the database is currently not Opened then the redo logs can't be switched.
        if [[ "${OpenMode}" = "READ WRITE" && "${DbfBkupType}" = "ONLINE" ]]
        then
                print "\tsql 'alter system archive log current';" >> ${CmdFile} 2>&1
        fi

        if [[ "${OpenMode}" = "READ WRITE" && "${DbfBkupType}" = "OFFLINE" ]]
        then
                print "\talter database open;" >> ${CmdFile} 2>&1
        fi

        if [[ ${CmdDebug} = ${True} ]]
        then
                print "\tdebug off; ">> ${CmdFile} 2>&1
        fi

        print "}" >> ${CmdFile} 2>&1

        if [[ ${Verbose} = ${True} ]]
        then
                print "Function: DBBkupCmds, Return Code: ${ReturnCode}"
        fi

        return ${ReturnCode}

} # End of DBBkupCmds


#-----------------------------------------------------------------------------
# Function   : ArcBkupCmds
# Description: Backup the Archived logs
#-----------------------------------------------------------------------------
function ArcBkupCmds
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ArcBkupCmds ${*}" >&2

        typeset ReturnCode=0

        if [[ -n ${ArcChanType} ]]
        then
                ChanType=${ArcChanType}
        elif [[ -z ${ChanType} ]]
        then
                if [[ ${MediaVendor} = "TSM" || ${MediaVendor} = "NETBACKUP" || ${MediaVendor} = "AVAMAR" || ${MediaVendor} = "DDBOOST" || ${MediaVendor} = "DUMMY" ]]
                then
                        ChanType=sbt_tape
                elif [[ ${MediaVendor} = "NONE" ]]
                then
                        ChanType=DISK
                else
                        ReportMsg "WARNING" "Unable to determine correct channel type to use"
                        (( ReturnCode = ReturnCode + 1 ))
                fi
        fi

        # Determine if and what to set the FILESPERSET option to.
        if (( ${FilesPerSetOpt} > 0 ))
        then
                FilesPerSetCmd="filesperset ${FilesPerSetOpt}"
        elif (( ${ArcFilesPerSet} > 0 ))
        then
                FilesPerSetCmd="filesperset ${ArcFilesPerSet}"
        elif (( ${FilesPerSet} > 0 ))
        then
                FilesPerSetCmd="filesperset ${FilesPerSet}"
        else
                if [[ -n ${FilesPerSetCmd} ]]
                then
                        unset FilesPerSetCmd
                fi
        fi

        # Determine if and what to set the MAXSETSIZE option to.
        if [[ -n ${ArcMaxSetSize} ]]
        then
                MaxSetSizeCmd="MAXSETSIZE ${ArcMaxSetSize}"
        elif [[ -n ${MaxSetSize} ]]
        then
                MaxSetSizeCmd="MAXSETSIZE ${MaxSetSize}"
        else
                if [[ -n ${MaxSetSizeCmd} ]]
                then
                        unset MaxSetSizeCmd
                fi
        fi

        # Determine if and what to set the MAXOPENFILES option to.
        if [[ -n ${MaxOpenFilesOpt} ]]
        then
                MaxOpenFilesCmd="maxopenfiles=${MaxOpenFilesOpt}"
        elif [[ -n ${ArcMaxOpenFiles} ]]
        then
                MaxOpenFilesCmd="maxopenfiles=${ArcMaxOpenFiles}"
        elif [[ -n ${MaxOpenFiles} ]]
        then
                MaxOpenFilesCmd="maxopenfiles=${MaxOpenFiles}"
        else
                if [[ -n ${MaxOpenFilesCmd} ]]
                then
                        unset MaxOpenFilesCmd
                fi
        fi

        # Determine if and what to set the RATE option to.
        if [[ -n ${ArcRate} ]]
        then
                RateCmd="rate=${ArcRate}"
        elif [[ -n ${Rate} ]]
        then
                RateCmd="rate=${Rate}"
        else
                if [[ -n ${RateCmd} ]]
                then
                        unset RateCmd
                fi
        fi

        # Determine the Number of Channels to use.
        if [[ -n ${ChanCountOpt} ]]
        then
                ChanCount=${ChanCountOpt}
        elif [[ -n ${ArcChanCount} ]]
        then
                ChanCount=${ArcChanCount}
        elif (( ${ChanCount} == 0 ))
        then
                ChanCount=1
        fi

        if [[ ${Verbose} = ${True} && ${ChanType} = 'DISK' ]]
        then
                I=0
                while (( ${I} < ${ArcBkupDirCnt} ))
                do
                        (( I = I + 1 ))
                        printf "ArcBkupDir %3.3s: %s\n" "${I}" "${ArcBkupDir[${I}]}"
                done
        fi

        print "run {" >> ${CmdFile} 2>&1

        if [[ ${CmdDebug} = ${True} ]]
        then
                print "\tdebug on; ">> ${CmdFile} 2>&1
                if [[ -n ${CmdDebugLvl} ]]
                then
                        CmdDebugOpt="debug=${CmdDebugLvl}"
                fi
        fi

        if [[ ${ChanType} = 'DISK' ]]
        then
                if (( ${ArcBkupDirCnt} < ${ChanCount} ))
                then
                        if [[ ${FRAActive} = ${False} ]]
                        then
                                ReportMsg "WARNING" "Backup Directories < Channel Count, Using Channel Count = ${ArcBkupDirCnt}"
                        fi
                        ChanCount=${ArcBkupDirCnt}
                fi

                I=0
                while (( ${I} < ${ChanCount} ))
                do
                        (( I = I + 1 ))
                        print "\tallocate channel 't${I}' type ${ChanType} ${CmdDebugOpt} ${MaxOpenFilesCmd} ${RateCmd} ${Parms} format '${ArcBkupDir[${I}]}/arc_%d_%s_%p_%t';" >> ${CmdFile} 2>&1
                done

                # Updated command id to be more descriptive - JThorn -7/20/09
                print "\tset command id to 'RMAN-BKUPARC';" >> ${CmdFile} 2>&1

                print "\tbackup" >> ${CmdFile} 2>&1
                if [[ -n ${FilesPerSetCmd} ]]
                then
                        print "\t\t${FilesPerSetCmd}" >> ${CmdFile} 2>&1
                fi
                if [[ -n ${MaxSetSizeCmd} ]]
                then
                        print "\t\t${MaxSetSizeCmd}" >> ${CmdFile} 2>&1
                fi

                # Added  code changes to use ArchiveDestBackup to delete only 1 archive location, installed of ALL.
                # This variable is set in the .cfg file, by setting RMAN_ARC_DEST_DIR to the directory of the
                # destination archivelogs that you would like to use as input and deleted.
                # Usually this is used for Golden Gate installations.
                # (J.Thorn - 6/19/09)

                if [[ -z ${SkipDays} ]]
                then
                        if [[ -z ${ArchiveDestBackup} ]]
                        then
                                print "\t\t(archivelog all delete input);" >> ${CmdFile} 2>&1
                        else
                                print "\t\t(archivelog ${ArchiveDestBackup} delete input);" >> ${CmdFile} 2>&1
                        fi
                else
                        print "\t\t(archivelog until time = 'sysdate-${SkipDays}' ${ArchiveDestBackup} delete input);" >> ${CmdFile} 2>&1
                fi

        elif [[ ${ChanType} = 'SBT_TAPE' ]]
        then
                I=0
                while (( ${I} < ${ChanCount} ))
                do
                        (( I = I + 1 ))
                        print "\tallocate channel 't${I}' type '${ChanType}' ${CmdDebugOpt} ${MaxOpenFilesCmd} ${RateCmd} ${Parms};" >> ${CmdFile} 2>&1
                        if [[ ${MediaVendor} = "AVAMAR" ]]
                        then
                                print "\tsend channel='t${I}' '\"--flagfile=${LOCAL_BASE}/etc/${AvamarAvtarFile}\" \"--bindir=${AVAMAR_BASE}/bin\" \"--cacheprefix=${ORACLE_SID}_${I}\"';" >> ${CmdFile} 2>&1
                        fi
                done

                # Updated command id to be more descriptive - JThorn -7/20/09
                print "\tset command id to 'RMAN-BKUPARC';" >> ${CmdFile} 2>&1
                print "\tbackup" >> ${CmdFile} 2>&1
                if [[ -n ${FilesPerSetCmd} ]]
                then
                        print "\t\t${FilesPerSetCmd}" >> ${CmdFile} 2>&1
                fi
                if [[ -n ${MaxSetSizeCmd} ]]
                then
                        print "\t\t${MaxSetSizeCmd}" >> ${CmdFile} 2>&1
                fi
                print "\t\tformat 'arc_%d_%s_%p_%t'" >> ${CmdFile} 2>&1

                # Added  code changes to use ArchiveDestBackup to delete only 1 archive location, installed of ALL.
                # This variable is set in the .cfg file, by setting RMAN_ARC_DEST_DIR to the directory of the
                # destination archivelogs that you would like to use as input and deleted.
                # Usually this is used for Golden Gate installations.
                # (J.Thorn - 6/19/09)
                if [[ -z ${SkipDays} ]]
                then
                        if [[ -z ${ArchiveDestBackup} ]]
                        then
                                print "\t\t(archivelog all delete input);" >> ${CmdFile} 2>&1
                        else
                                print "\t\t(archivelog ${ArchiveDestBackup} delete input);" >> ${CmdFile} 2>&1
                        fi
                else
                        print "\t\t(archivelog until time = 'sysdate-${SkipDays}' ${ArchiveDestBackup} delete input);" >> ${CmdFile} 2>&1
                fi
        fi

        if [[ ${CmdDebug} = ${True} ]]
        then
                print "\tdebug off; ">> ${CmdFile} 2>&1
        fi

        print "}" >> ${CmdFile} 2>&1

        if [[ ${Verbose} = ${True} ]]
        then
                print "Function: ArcBkupCmds, Return Code: ${ReturnCode}"
        fi

        return ${ReturnCode}

} # End of ArcBkupCmds


#-----------------------------------------------------------------------------
# Function   : CtlBkupCmds
# Description: Backup the Control File
#-----------------------------------------------------------------------------
function CtlBkupCmds
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: CtlBkupCmds ${*}" >&2

        typeset ReturnCode=0

        if [[ -n ${DbfChanType} ]]
        then
                ChanType=${DbfChanType}
        elif [[ -z ${ChanType} ]]
        then
                if [[ ${MediaVendor} = "TSM" || ${MediaVendor} = "NETBACKUP" || ${MediaVendor} = "AVAMAR" || ${MediaVendor} = "DDBOOST" || ${MediaVendor} = "DUMMY" ]]
                then
                        ChanType=sbt_tape
                elif [[ ${MediaVendor} = "NONE" ]]
                then
                        ChanType=DISK
                else
                        ReportMsg "WARNING" "Unable to determine correct channel type to use"
                        (( ReturnCode = ReturnCode + 1 ))
                fi
        fi

        # Set the Number of Channels to 1
        ChanCount=1

        if [[ ${Verbose} = ${True} && ${ChanType} = 'DISK' ]]
        then
                I=0
                while (( ${I} < ${DbfBkupDirCnt} ))
                do
                        (( I = I + 1 ))
                        printf "DbfBkupDir %3.3s: %s\n" "${I}" "${DbfBkupDir[${I}]}"
                done
        fi

        print "show all;" >> ${CmdFile} 2>&1
        print "run {" >> ${CmdFile} 2>&1

        if [[ ${CmdDebug} = ${True} ]]
        then
                print "\tdebug on; ">> ${CmdFile} 2>&1
                if [[ -n ${CmdDebugLvl} ]]
                then
                        CmdDebugOpt="debug=${CmdDebugLvl}"
                fi
        fi

        print "\tsql 'alter database backup controlfile to trace';" >> ${CmdFile} 2>&1

        if [[ ${ChanType} = 'DISK' ]]
        then
                if (( ${DbfBkupDirCnt} < ${ChanCount} ))
                then
                        if [[ ${FRAActive} = ${False} ]]
                        then
                                ReportMsg "WARNING" "Backup Directories < Channel Count, Using Channel Count = ${DbfBkupDirCnt}"
                        fi
                        ChanCount=${DbfBkupDirCnt}
                fi

                I=0
                while (( ${I} < ${ChanCount} ))
                do
                        (( I = I + 1 ))
                        print "\tallocate channel 't${I}' type ${ChanType} ${CmdDebugOpt} ${Parms} format '${DbfBkupDir[${I}]}/ctl_%d_%s_%p_%t';" >> ${CmdFile} 2>&1
                done

                # Updated command id to be more descriptive - JThorn -7/20/09
                print "\tset command id to 'RMAN-BKUPCTL';" >> ${CmdFile} 2>&1

                print "\tbackup current controlfile" >> ${CmdFile} 2>&1
                print "\t\ttag = '${BackupTag}';" >> ${CmdFile} 2>&1

        elif [[ ${ChanType} = 'SBT_TAPE' ]]
        then
                I=0
                while (( ${I} < ${ChanCount} ))
                do
                        (( I = I + 1 ))
                        print "\tallocate channel 't${I}' type '${ChanType}' ${CmdDebugOpt} ${Parms};" >> ${CmdFile} 2>&1
                        if [[ ${MediaVendor} = "AVAMAR" ]]
                        then
                                print "\tsend channel='t${I}' '\"--flagfile=${LOCAL_BASE}/etc/${AvamarAvtarFile}\" \"--bindir=${AVAMAR_BASE}/bin\" \"--cacheprefix=${ORACLE_SID}_${I}\"';" >> ${CmdFile} 2>&1
                        fi
                done

                # Updated command id to be more descriptive - JThorn -7/20/09
                print "\tset command id to 'RMAN-BKUPCTL';" >> ${CmdFile} 2>&1

                print "\tbackup current controlfile" >> ${CmdFile} 2>&1
                print "\t\tformat 'ctl_%d_%s_%p_%t'" >> ${CmdFile} 2>&1
                print "\t\ttag = '${BackupTag}';" >> ${CmdFile} 2>&1
        fi

        if [[ ${CmdDebug} = ${True} ]]
        then
                print "\tdebug off; ">> ${CmdFile} 2>&1
        fi

        print "}" >> ${CmdFile} 2>&1

        if [[ ${Verbose} = ${True} ]]
        then
                print "Function: CtlBkupCmds, Return Code: ${ReturnCode}"
        fi

        return ${ReturnCode}

} # End of CtlBkupCmds


#-----------------------------------------------------------------------------
# Function   : RestoreValidateCmds
# Description: Execute a Restore Validate to confirm backup is available
#-----------------------------------------------------------------------------
function RestoreValidateCmds
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: RestoreValidateCmds ${*}" >&2

        typeset ReturnCode=0

        if [[ ${MediaVendor} = "NETBACKUP" || ${MediaVendor} = "AVAMAR" || ${MediaVendor} = "DDBOOST" || ${MediaVendor} = "DUMMY" ]]
        then
                ChanType=sbt_tape
        elif [[ ${MediaVendor} = "NONE" ]]
        then
                ChanType=DISK
        else
                ReportMsg "WARNING" "Unable to determine correct channel type to use"
                (( ReturnCode = ReturnCode + 1 ))
        fi

        # Determine the Number of Channels to use.
        if [[ -n ${ChanCountOpt} ]]
        then
                ChanCount=${ChanCountOpt}
        elif (( ${ChanCount} == 0 ))
        then
                ChanCount=1
        fi

        print "run {" >> ${CmdFile} 2>&1

        if [[ ${ChanType} = 'SBT_TAPE' && ${MediaVendor} = "NETBACKUP" ]]
        then
                I=0
                while (( ${I} < ${ChanCount} ))
                do
                        (( I = I + 1 ))
                        print "\tallocate channel 'Tape${I}' type '${ChanType}' ${Parms};" >> ${CmdFile} 2>&1

#                       Create 2nd channel to 2nd client for Off Host Backup Strategy

                        if [[ -n ${Parms2} ]]
                        then
                                print "\tallocate channel 'Tape${I}A' type '${ChanType}' ${Parms2};" >> ${CmdFile} 2>&1
                        fi

                done

        elif [[ ${ChanType} = 'SBT_TAPE' && ${MediaVendor} = "AVAMAR" ]]
        then
                I=0
                while (( ${I} < ${ChanCount} ))
                do
                        (( I = I + 1 ))
                        print "\tallocate channel 'Tape${I}' type '${ChanType}' ${Parms};" >> ${CmdFile} 2>&1
                        print "\tsend channel='Tape${I}' '\"--flagfile=${LOCAL_BASE}/etc/${AvamarAvtarFile}\" \"--bindir=${AVAMAR_BASE}/bin\" \"--cacheprefix=${ORACLE_SID}_${I}\"';" >> ${CmdFile} 2>&1

#                       Create 2nd channel to 2nd client for Off Host Backup Strategy

                        if [[ -n ${DG_2nd_ORACLE_SID} ]]
                        then
                                print "\tallocate channel 'Tape${I}A' type '${ChanType}' ${Parms};" >> ${CmdFile} 2>&1
                                print "\tsend channel='Tape${I}A' '\"--flagfile=${LOCAL_BASE}/etc/${DG_2nd_AvamarAvtarFile}\" \"--bindir=${AVAMAR_BASE}/bin\" \"--cacheprefix=${DG_2nd_ORACLE_SID}_${I}\"';" >> ${CmdFile} 2>&1
                        fi

                done
        fi



        print "\tset command id to 'RMAN-RESTVAL';" >> ${CmdFile} 2>&1
        if [[ ${DbfClone} != ${True} && ${DGStandby} != ${True} ]]
        then
                print "\tsql 'alter system switch logfile';" >> ${CmdFile} 2>&1
        fi
        print "\trestore database preview;" >> ${CmdFile} 2>&1
        print "\trestore database validate;" >> ${CmdFile} 2>&1
        print "\trestore archivelog from time 'sysdate-1' preview;" >> ${CmdFile} 2>&1
        print "\trestore archivelog from time 'sysdate-1' validate;" >> ${CmdFile} 2>&1
        print "\trestore controlfile preview;" >> ${CmdFile} 2>&1
        print "\trestore controlfile validate;" >> ${CmdFile} 2>&1
        print "\trestore spfile validate;" >> ${CmdFile} 2>&1
        print "}" >> ${CmdFile} 2>&1

        print "\n***************************************************************"       >> ${LogFile} 2>&1
        print "*   WARNING: The RESTOREVAL function primary should be "                 >> ${LogFile} 2>&1
        print "*   used to verify that the backups are readable from the"               >> ${LogFile} 2>&1
        print "*   defined media server.  This function will use media server"          >> ${LogFile} 2>&1
        print "*   resources as if it were doing a real database restore."              >> ${LogFile} 2>&1
        print "*   This function should be used only occasionally. "                    >> ${LogFile} 2>&1
        print "***************************************************************\n\n"     >> ${LogFile} 2>&1

        if [[ ${Verbose} = ${True} ]]
        then
                print "Function: RestoreValidateCmds, Return Code: ${ReturnCode}"
        fi

        return ${ReturnCode}

} # End of RestoreValidateCmds


#-----------------------------------------------------------------------------
# Function   : FRABkupCmds
# Description: Backup the FRA
#-----------------------------------------------------------------------------
function FRABkupCmds
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: FRABkupCmds ${*}" >&2

        typeset ReturnCode=0

        # FRA backup is always to tape

        if [[ ${MediaVendor} = "TSM" || ${MediaVendor} = "NETBACKUP" || ${MediaVendor} = "AVAMAR" || ${MediaVendor} = "DDBOOST" || ${MediaVendor} = "DUMMY" ]]
        then
                ChanType=sbt_tape
        else
                ReportMsg "WARNING" "Unable to determine correct channel type to use"
                        (( ReturnCode = ReturnCode + 1 ))
        fi

        # Determine the Number of Channels to use.
        if [[ -n ${ChanCountOpt} ]]
        then
                ChanCount=${ChanCountOpt}
        elif (( ${ChanCount} == 0 ))
        then
                ChanCount=1
        fi

        print "run {" >> ${CmdFile} 2>&1

        if [[ ${CmdDebug} = ${True} ]]
        then
                print "\tdebug on; ">> ${CmdFile} 2>&1
                if [[ -n ${CmdDebugLvl} ]]
                then
                        CmdDebugOpt="debug=${CmdDebugLvl}"
                fi
        fi

        # Added by jt7190, 08/27/2008

        # Determine if and what to set the MAXOPENFILES option to.
        if [[ -n ${MaxOpenFilesOpt} ]]
        then
                MaxOpenFilesCmd="maxopenfiles=${MaxOpenFilesOpt}"
        elif [[ -n ${DbfMaxOpenFiles} ]]
        then
                MaxOpenFilesCmd="maxopenfiles=${DbfMaxOpenFiles}"
        elif [[ -n ${MaxOpenFiles} ]]
        then
                MaxOpenFilesCmd="maxopenfiles=${MaxOpenFiles}"
        else
                if [[ -n ${MaxOpenFilesCmd} ]]
                then
                        unset MaxOpenFilesCmd
                fi
        fi

        # Determine if and what to set the FILESPERSET option to.
        if (( ${FilesPerSetOpt} > 0 ))
        then
                FilesPerSetCmd="filesperset ${FilesPerSetOpt}"
        elif (( ${DbfFilesPerSet} > 0 ))
        then
                FilesPerSetCmd="filesperset ${DbfFilesPerSet}"
        elif (( ${FilesPerSet} > 0 ))
        then
                FilesPerSetCmd="filesperset ${FilesPerSet}"
        else
                if [[ -n ${FilesPerSetCmd} ]]
                then
                        unset FilesPerSetCmd
                fi
        fi

        I=0
        while (( ${I} < ${ChanCount} ))
        do
                (( I = I + 1 ))
                print "\tallocate channel 't${I}' type '${ChanType}' ${CmdDebugOpt} ${MaxOpenFilesCmd} ${Parms};" >> ${CmdFile} 2>&1
                if [[ ${MediaVendor} = "AVAMAR" ]]
                then
                        if (( ${ChanCount} > 10 ))
                        then
                                ReportMsg "WARNING" "Channel Count was set to ${ChanCount}, Avamar maximum channel count is 10, value being reset for job run."
                                ChanCount=10;
                        fi
                        print "\tsend channel='t${I}' '\"--flagfile=${LOCAL_BASE}/etc/${AvamarAvtarFile}\" \"--bindir=${AVAMAR_BASE}/bin\" \"--cacheprefix=${ORACLE_SID}_${I}\"';" >> ${CmdFile} 2>&1
                fi
        done

        # Updated command id to be more descriptive - JThorn -7/20/09
        print "\tset command id to 'RMAN-BKUPFRA';" >> ${CmdFile} 2>&1
        print "\tbackup " >> ${CmdFile} 2>&1

        if [[ -n ${FilesPerSetCmd} ]]
        then
                print "\t\t${FilesPerSetCmd}" >> ${CmdFile} 2>&1
        fi
        print " \t\trecovery area;" >> ${CmdFile} 2>&1

        if [[ ${CmdDebug} = ${True} ]]
        then
                print "\tdebug off; ">> ${CmdFile} 2>&1
        fi

        print "}" >> ${CmdFile} 2>&1

        if [[ ${Verbose} = ${True} ]]
        then
                print "Function: FRABkupCmds, Return Code: ${ReturnCode}"
        fi

        return ${ReturnCode}

} # End of FRABkupCmds


#-----------------------------------------------------------------------------
# Function   : MonFRACmds
# Description: Monitor disk space usage for FRA
#-----------------------------------------------------------------------------
function MonFRACmds
{

        echo  `date` "Running orarman MONFRA." >> ${LogFile} 2>&1

        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: MonFRACmds ${*}" >&2

        typeset ReturnCode=0
        typeset ASM_FRA_Found=0

        if [[ ${CmdDebug} = ${True} ]]
        then
                print "\tdebug on; ">> ${CmdFile} 2>&1
                if [[ -n ${CmdDebugLvl} ]]
                then
                        CmdDebugOpt="debug=${CmdDebugLvl}"
                fi
        fi

        # Notify Patrol that the MONFRA has started
        if [[ -n ${PatrolStartNotify} && -x ${PatrolStartNotify} ]]
        then

                BackupName="${ScriptName}-${ORACLE_SID}"

                if [[ -n ${PatrolTag} ]]
                then
                        BackupName="${BackupName}-${PatrolTag}"
                fi
                        ${PatrolStartNotify} "${BackupName}"
        fi

        # Cannot allow BKUPFRA comman to run without RmanFraFullPct set.

        if [[ -z ${RmanFraFullPct} ]]
        then
                ReportMsg "${FailureSeverity}" "MonFRA is not an option, unless RMAN_FRA_FULL_PCT parameter is set"
                CleanupAndExit 1
        fi

        #
        # Check for Bug 4911954, where the Oracle FRA views may be incorrect in 10.2.0.2 and earlier.
        #
        MONFRA_update_for_bug;
        ExitCode=${?}
        if (( ${ExitCode} != 0 ))
        then
                ReportMsg "${FailureSeverity}" "Failed to check for FRA bug 4911954"
                CleanupAndExit ${ExitCode}
        fi

        #
        # Get db_recover_file_dest value.
        #
        SqlConnect="/ as sysdba"
        SqlCommand="select 'Cmd1:'||rpad(value,50) from v"'$parameter'" where name ='db_recovery_file_dest';"
        RunSql "${SqlCommand}"
        SqlError=${?}
        if (( ${SqlError} != 0 ))
        then
                ReportMsg "" " Parameter db_recovery_file_dest check Failed, or SQL command failed!"
                ReturnCode=1
        fi
        export db_recovery_file_dest=$(grep "^Cmd1:" ${TmpFile1} | awk -F':' '{print $2}')

        #
        # Check to see if the db_recovery_file_dest mount point is large enought to support the Used FRA space(unreclaimable)
        # plus used non-Oracle files on this mountpoint.
        #
        echo $db_recovery_file_dest >$TmpDir/arg.file

        #
        # Check to make sure this is not ASM
        #
        grep "+" $TmpDir/arg.file >/dev/null 2>&1
        ExitStatus=${?}
        if (( ${ExitStatus} == 0 ))
        then
                # ASM found, cannont continue
                ASM_FRA_Found=1
                echo "ASM Found ($db_recovery_file_dest) , no OS level disk checking..."
        fi
        if (( ${ASM_FRA_Found} == 0 ))
        then
                Line=$(DiskFree ${db_recovery_file_dest})
                df_MountPoint=$(echo ${Line} | ${AWK} '{print $1}')
                df_TotalKBytes=$(echo ${Line} | ${AWK} '{print $2}')
                df_FreeKB=$(echo ${Line} | ${AWK} '{print $3}')
                let df_UsedKBytes=$df_TotalKBytes-$df_FreeKB
                echo "df_MountPoint=${df_MountPoint}"
                echo "df_TotalKBytes=${df_TotalKBytes}"
                echo "df_UsedKBytes=${df_UsedKBytes}"
        fi

        #
        # Check FRA size and reclaimable space  from v$recovery_file_dest table.
        #

        SqlConnect="/ as sysdba"
        SqlCommand="select 'Cmd1:'||trunc(((space_used-space_reclaimable)/space_limit)*100,0)||':'||trunc(space_limit/1028)||':'||trunc(space_used/1028)||':'||trunc(space_reclaimable/1028) from v\$recovery_file_dest;"
        RunSql "${SqlCommand}"
        SqlError=${?}
        if (( ${SqlError} != 0 ))
        then
                ReportMsg "" "FRA Size check Failed, or SQL command failed!"
                ReturnCode=1
        fi

        export fra_pct_full=$(grep "^Cmd1:" ${TmpFile1} | awk -F':' '{print $2}')
        export fra_space_limit=$(grep "^Cmd1:" ${TmpFile1} | awk -F':' '{print $3}')
        export fra_space_used=$(grep "^Cmd1:" ${TmpFile1} | awk -F':' '{print $4}')
        export fra_space_reclaimable=$(grep "^Cmd1:" ${TmpFile1} | awk -F':' '{print $5}')

        echo "FRA Total Size(KB)    = $fra_space_limit"
        echo "FRA Used (KB)         = $fra_space_used"
        echo "FRA Reclaimable(KB)   = $fra_space_reclaimable"
        echo "FRA PCT Full          = $fra_pct_full%"

        echo  `date` "FRA Actual Pct full   = $fra_pct_full%" >> ${LogFile} 2>&1
        echo  `date` "FRA Total Size(KB)    = $fra_space_limit" >> ${LogFile} 2>&1
        echo  `date` "FRA Used (KB)         = $fra_space_used" >> ${LogFile} 2>&1
        echo  `date` "FRA Reclaimable(KB)   = $fra_space_reclaimable" >> ${LogFile} 2>&1
        echo  `date` "RMAN_FRA_FULL_PCT     = $RmanFraFullPct" >> ${LogFile} 2>&1

        #
        # If this is ASM then we cannot execute any disk space checks.
        #
        if (( ${ASM_FRA_Found} == 0 ))
        then
                #
                # Check to FRA size (db_recovery_dest_size) is larger than the mount point
                #
                if (( ${fra_space_limit} > ${df_TotalKBytes} ))
                then
                        ReportMsg "CRITICAL" "FRA size of ${fra_space_limit}(KB) is larger than the Mount Point ${df_MountPoint} size of ${df_TotalKBytes}(KB), Please correct Immediately."
                fi

                #
                # Check to FRA pct full + FRA Mount Space used (non-oracle) and see
                # if it is larger than the OS allocated mount space.
                #
                let fra_free=${fra_space_limit}-${fra_space_used}+${fra_space_reclaimable}
                let df_free=${df_TotalKBytes}-${df_UsedKBytes}+${fra_space_reclaimable}

                if (( ${fra_free} > ${df_free} ))
                then
                        ReportMsg "WARNING" "FRA free space (${fra_free}KB) is larger than the Disk Mount free (${df_free}KB), please remove non-Oracle files on FRA disk mount $df_MountPoint. This condition may cause the database to hang when writing to the FRA."
                fi

        fi

        #
        # Check if the FRA pct full is greater than the threshold set up in the .cfg file.  If so kick off an BKUPFRA.
        #
        if (( ${fra_pct_full} > ${RmanFraFullPct} ))
        then
                if [[ -x ${LocalBin}/orarman ]]
                then
                        if [[ ${DGStandby} = ${True} ]]
                        then
                                echo  `date` "Running oradgdelarcs ." >> ${LogFile} 2>&1
                                ReportMsg "WARNING" "Running MONFRA, found FRA Pct Full ${fra_pct_full}% was greater than ${RmanFraFullPct}% (RMAN_RMAN_FULL_PCT).  To reclaim FRA space, MONFRA started the oradgdelarcs job to remove applied archivelogs from Standby."
                                ${LocalBin}/oradgdelarcs -s ${ORACLE_SID} ${DebugOpt} ${VerboseOpt}
                        else
                                echo  `date` "Running orarman BKUPFRA." >> ${LogFile} 2>&1
                                ReportMsg "WARNING" "Running MONFRA, found FRA Pct Full ${fra_pct_full}% was greater than ${RmanFraFullPct}% (RMAN_RMAN_FULL_PCT).  To reclaim FRA space, MONFRA started the backup of FRA, by executing 'orarman -c BKUPFRA'."

                                if [[ ${CleanupLock} = ${True} ]]
                                then
                                       rm -f ${LockFile}
                                fi

                                ${LocalBin}/orarman -s ${ORACLE_SID} -c BKUPFRA -T FRA ${ConfigDirOpt} ${DebugOpt} ${VerboseOpt}
                        fi
                        ReturnCode=${?}
                else
                        ReportMsg "WARNING" "Unable to perform Backup FRA, command not found"
                fi
        fi

        #
        # Debug code
        #
        if [[ ${CmdDebug} = ${True} ]]
        then
                print "\tdebug off; ">> ${CmdFile} 2>&1
        fi

        if [[ ${Verbose} = ${True} ]]
        then
                print "Function: MonFRACmd, Return Code: ${ReturnCode}"
        fi

        return ${ReturnCode}

} # End of MonFRACmd


#-----------------------------------------------------------------------------
# Function   : DeleteCmds
# Description: Delete Obsolete or Expired Backups
#-----------------------------------------------------------------------------
function DeleteCmds
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: DeleteCmds ${*}" >&2

        typeset ReturnCode=0

        if [[ -n ${DbfChanType} ]]
        then
                ChanType=${DbfChanType}
        elif [[ -z ${ChanType} ]]
        then
                if [[ ${MediaVendor} = "TSM" || ${MediaVendor} = "NETBACKUP" || ${MediaVendor} = "AVAMAR" || ${MediaVendor} = "DDBOOST" ||${MediaVendor} = "DUMMY" ]]
                then
                        ChanType=sbt_tape
                elif [[ ${MediaVendor} = "NONE" ]]
                then
                        ChanType=DISK
                else
                        ReportMsg "WARNING" "Unable to determine correct channel type to use"
                        (( ReturnCode = ReturnCode + 1 ))
                fi
        fi

        if [[ ${CmdDebug} = ${True} ]]
        then
                print "\tdebug on; ">> ${CmdFile} 2>&1
                if [[ -n ${CmdDebugLvl} ]]
                then
                        CmdDebugOpt="debug=${CmdDebugLvl}"
                fi
        fi

        if [[ ${FRAActive} = ${True} ]]
        then
                # Added check to see if FRA database used Tape.  If not, then we don't want to allocate
                # a channel for sbt_tape.
                if [[ ${MediaVendor} = "TSM" || ${MediaVendor} = "NETBACKUP" || ${MediaVendor} = "AVAMAR" || ${MediaVendor} = "DDBOOST" || ${MediaVendor} = "DUMMY" ]]
                then
                        if [[ ${DelObsolete} = ${True} ]]
                        then
                                print "allocate channel for maintenance type SBT_TAPE ${CmdDebugOpt} ${Parms};" >> ${CmdFile} 2>&1
                                if [[ ${MediaVendor} = "AVAMAR" ]]
                                then
                                        print "\tsend '\"--flagfile=${LOCAL_BASE}/etc/${AvamarAvtarFile}\" \"--bindir=${AVAMAR_BASE}/bin\"';" >> ${CmdFile} 2>&1
                                fi
                        fi
                fi
                print "allocate channel for maintenance type DISK ${CmdDebugOpt};" >> ${CmdFile} 2>&1
        elif [[ ${ChanType} = 'DISK' ]]
        then
                print "allocate channel for maintenance type ${ChanType} ${CmdDebugOpt};" >> ${CmdFile} 2>&1

        elif [[ ${ChanType} = 'SBT_TAPE' ]]
        then
                if [[ ${DelObsolete} = ${True} ]]
                then
                        print "allocate channel for maintenance type ${ChanType} ${CmdDebugOpt} ${Parms};" >> ${CmdFile} 2>&1
                        if [[ ${MediaVendor} = "AVAMAR" ]]
                        then
                                print "\tsend '\"--flagfile=${LOCAL_BASE}/etc/${AvamarAvtarFile}\" \"--bindir=${AVAMAR_BASE}/bin\"';" >> ${CmdFile} 2>&1
                        fi
                fi
                print "allocate channel for maintenance type DISK ${CmdDebugOpt};" >> ${CmdFile} 2>&1
        fi


        if [[ ${DelObsolete} = ${True} ]]
        then
                if [[ ${DelObsoleteForce} = ${True} ]]
                then
                        print "report obsolete;" >> ${CmdFile} 2>&1
                        print "delete force noprompt obsolete;" >> ${CmdFile} 2>&1
                else
                        print "report obsolete;" >> ${CmdFile} 2>&1
                        print "delete noprompt obsolete;" >> ${CmdFile} 2>&1
                fi
        fi

        if [[ ${DelExpired} = ${True} ]]
        then
                print "crosscheck backup;" >> ${CmdFile} 2>&1
                print "crosscheck copy;" >> ${CmdFile} 2>&1
                print "delete noprompt expired backup;" >> ${CmdFile} 2>&1
                print "delete noprompt expired copy;" >> ${CmdFile} 2>&1

        fi

        if [[ ${CmdDebug} = ${True} ]]
        then
                print "\tdebug off; ">> ${CmdFile} 2>&1
        fi

        if [[ ${Verbose} = ${True} ]]
        then
                print "Function: DeleteCmds, Return Code: ${ReturnCode}"
        fi

        return ${ReturnCode}

} # End of DeleteCmds


#-----------------------------------------------------------------------------
# Function   : RunCmdFile
# Description: Run RMAN with that generated Command File, and check for
#              errors
#-----------------------------------------------------------------------------
function RunCmdFile
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: RunCmdFile ${*}" >&2

        typeset -u Command=${1}

        if [[ ${Debug} = ${True} ]]
        then
                # Dump the current environment if in debug mode, helpful for debuging
                print "\n\nOutput of env:" >> ${TrcFile} 2>&1
                env | sort >> ${TrcFile} 2>&1
                print "\n\nOutput of set:" >> ${TrcFile} 2>&1
                set | sort >> ${TrcFile} 2>&1
        fi

        StartDate=$(date +'%m/%d/%Y')
        StartTime=$(date +'%H:%M:%S')

        if [[ ${Command} = "SHOWALL" ]]
        then
                ${ORACLE_HOME}/bin/rman cmdfile ${CmdFile}
                ReturnCode=${?}
        elif [[ ${Command} = "MONFRA" ]]
        then
                ${CmdFile}
                ReturnCode=${?}
        else
                ${ORACLE_HOME}/bin/rman cmdfile ${CmdFile} >> ${LogFile} 2>&1
                ReturnCode=${?}
        fi


        EndDate=$(date +'%m/%d/%Y')
        EndTime=$(date +'%H:%M:%S')

        if [[ -f ${LogFile} && ${Verbose} = ${True} ]]
        then
                cat ${LogFile}
        fi

        # If no archive logs are found to backup an error will be generated
        # by RMAN, but we are going to ignore it.
        if [[ ${Command} = "BKUPARC" ]] && (( ${ReturnCode} != 0 ))
        then
                grep "RMAN-20242:" ${LogFile} >/dev/null 2>&1
                ExitStatus=${?}
                if (( ${ExitStatus} == 0 ))
                then
                        # No Logs to backup, that is okay
                        ReturnCode=0
                        ReportMsg "" "No archived logs found to backup"
                fi
        fi

        printf "%-8.8s %-10.10s %-4.4s %-10.10s %-8.8s %-10.10s %-8.8s %-8.8s\n" \
                "Sid" "Cmd" "RC" "StrtDt" "StrtTm" "EndDt" "EndTm" "Seconds" >> ${LogFile} 2>&1

        printf "%-8.8s %-10.10s %4.4s %-10.10s %-8.8s %-10.10s %-8.8s %8.8s\n" \
                "${ORACLE_SID}" "${Command}" "${ReturnCode}" "${StartDate}" "${StartTime}" \
                "${EndDate}" "${EndTime}" "${SECONDS}" >> ${LogFile} 2>&1

        if [[ ${Verbose} = ${True} ]]
        then
                print "Function: RunCmdFile ${Command}, Return Code: ${ReturnCode}"
        fi

        return ${ReturnCode}

} # End of RunCmdFile


#-----------------------------------------------------------------------------
# Function   : MONFRA_update_for_bug
# Description: This script is a workaround for Oracle bug 4911954 which causes archived
#              logs and backup sets to be prematurely deleted from the flash recovery area.
#              The bug is fixed in Oracle 10.2.0.3
#-----------------------------------------------------------------------------
function MONFRA_update_for_bug
{
        typeset -i SqlError=0
        typeset -i ExitStatus=0
        typeset -i value=0

        ${ORACLE_HOME}/bin/sqlplus -silent / as sysdba <<-EOF > ${TmpFile3} 2>&1
                set heading off
                select NUMBER_OF_FILES - (select sum(NUMBER_OF_FILES) from V\$FLASH_RECOVERY_AREA_USAGE) from v\$recovery_file_dest;
                EXIT;
        EOF
        ExitStatus=${?}

        if (( ${ExitStatus} == 0 ))
        then
                egrep '(ORA-|ERROR:)' ${TmpFile3} > /dev/null 2>&1
                ExitStatus=${?}
                if (( ${ExitStatus} == 0 ))
                then
                        SqlError=1
                fi
        else
                SqlError=1
        fi

        for number in `cat ${TmpFile3}`
        do
                if [ -n $number ]
                then
                        value=$number
                fi
        done

        value=`echo $value | cut -d "." -f1`
        if [ $value -ne 0 ]
        then
                ${ORACLE_HOME}/bin/sqlplus -silent / as sysdba <<-EOF > ${TmpFile3} 2>&1
                        set heading off
                        alter session set events 'immediate trace name kra_options level 1';
                        execute sys.dbms_backup_restore.refreshagedfiles;
                        EXIT;
                EOF
                ExitStatus=${?}
                if (( ${ExitStatus} == 0 ))
                then
                        egrep '(ORA-|ERROR:)' ${TmpFile3} > /dev/null 2>&1
                        ExitStatus=${?}
                        if (( ${ExitStatus} == 0 ))
                        then
                                SqlError=1
                        fi
                else
                        SqlError=1
                fi
                ReportMsg "WARNING" "Oracle Bug 4911954 found in ${ORACLE_SID}.  The number of files in v\$recovery_file_dest had a difference of ${number} when compared to the v\$flash_recovery_area_usage view.  Running fix to update the v\$recovery_file_dest view and were reset while executing ${ScriptName}. Continuing to execute orarman MONFRA..."

        fi

        rm ${TmpFile3}

        if (( ${SqlError} != 0 ))
        then
                ReportMsg "" "Database connection failed, or SQL command failed!"
                Returncode=1
        else
                ReturnCode=0
        fi

        return ${ReturnCode}


} # End of MONFRA_update_for_bug

#-----------------------------------------------------------------------------
# Parse options and arguments from command line.
#-----------------------------------------------------------------------------
AllArcFlag=${False}
DelExpired=${False}
DelObsolete=${False}
DelObsoleteForce=${False}
BkupValidate=${False}
DbfProxyCopy=${False}
DbfClone=${False}
CleanupLock=${False}
DBCorruption=${False}

MajorRel=0
OptCount=0
typeset -u Command
typeset -l CmdOpt
typeset -u MediaVendorOpt
typeset -u DbfIncrTypeOpt
typeset -l DbfLevelOpt
typeset -l DbfBkupTypeOpt
typeset -l SkipTimeOpt
typeset -i FilesPerSetOpt=0

# Echo orarman version to logfile
ScriptName=$(basename ${0})

#
while getopts :s:t:v:c:o:l:n:f:i:m:S:T:C:DV OPT
do
        (( OptCount = OptCount + 1 ))
        case ${OPT} in
                s)      # Oracle System Identifier
                        OracleSid=${OPTARG}
                        ORACLE_SID=${OracleSid}
                        ;;
                c)      # Command to perform
                        Command=${OPTARG}
                        export Command
                        ;;
                o)      # Options to the Command
                        CmdOpt=${OPTARG}
                        if [[ ${CmdOpt} = "allarc" || ${CmdOpt} = "force" ]]
                        then
                                AllArcFlag=${True}
                        fi
                        if [[ ${CmdOpt} = "force" ]]
                        then
                                DelObsoleteForceOpt=${True}
                        fi
                        if [[ ${CmdOpt} = "validate" ]]
                        then
                                BkupValidate=${True}
                        fi
                        if [[ ${CmdOpt} = "proxy" ]]
                        then
                                DbfProxyCopyOpt=${True}
                        fi
                        if [[ ${CmdOpt} = "noproxy" ]]
                        then
                                DbfProxyCopyOpt=${False}
                        fi
                        if [[ ${CmdOpt} = "clone" ]]
                        then
                                DbfCloneOpt=${True}
                        fi
                        if [[ ${CmdOpt} = "noclone" ]]
                        then
                                DbfCloneOpt=${False}
                        fi
                        ;;
                t)      # Backup Type Hot/Online or Cold/Offline
                        DbfBkupTypeOpt=${OPTARG}
                        ;;
                v)      # Backup Media Vendor; TSM, NETBACKUP, AVAMAR, DDBOOST, NONE
                        MediaVendorOpt=${OPTARG}
                        ;;
                l)      # Backup Level
                        DbfLevelOpt=${OPTARG}
                        ;;
                f)      # FILESPERSET
                        FilesPerSetOpt=${OPTARG}
                        ;;
                m)      # MAXOPENFILES
                        MaxOpenFilesOpt=${OPTARG}
                        ;;
                i)      # Incremental Type
                        DbfIncrTypeOpt=${OPTARG}
                        ;;
                n)      # Number of Channels
                        ChanCountOpt=${OPTARG}
                        ;;
                S)      # Skip time Nd - days or Nh - hours or Nm - minutes
                        SkipTimeOpt=${OPTARG}
                        ;;
                T)      # Tag used to distinguish one run from another
                        PatrolTag=${OPTARG}
                        ;;
                C)      # Change Default Configuration Directory
                        ConfigDir=${OPTARG}
                        ConfigDirOpt="-C ${ConfigDir}"
                        ;;
                D)      # Turn Shell Debug mode on
                        set -xv
                        Debug=${True}
                        DebugOpt="-D"
                        ;;
                V)      # Turn Verbose mode on
                        Verbose=${True}
                        VerboseOpt="-V"
                        ;;
                :)      # Missing Argument
                        ReportMsg "WARNING" "Argument missing for option: ${OPTARG}"
                        ShowUsage
                        exit 1;
                        ;;
                \?)     # Invalid Option
                        if [[ ${OPTARG} != '?' ]]
                        then
                                ReportMsg "WARNING" "Invalid option: ${OPTARG}"
                                ShowUsage
                                exit 1
                        else
                                ShowUsage
                                exit 1
                        fi
                        ;;
        esac
done

# Shift the options off the command line, leaving any remaining arguments.
shift $((${OPTIND} - 1))

# No other options should remain, if they do report a usage error
if (( ${#} > 0 ))
then
        ReportMsg "WARNING" "Invalid arguments on the command line!"
        ShowUsage
        CleanupAndExit 1
fi

if (( ${OptCount} == 0 ))
then
        ReportMsg "" "Missing one or more required options!"
        ShowUsage
        CleanupAndExit 1
fi

# If we die unexpectedly, try to perform some cleanup.
trap 'CleanupAndExit 1' HUP INT QUIT ABRT TERM


#-----------------------------------------------------------------------------
# Verify required options and arguments specified are correct.
#-----------------------------------------------------------------------------
if [[ -z ${OracleSid} ]]
then
        ReportMsg "WARNING" "OracleSid option is required!"
        ShowUsage
        CleanupAndExit 1
fi


#-----------------------------------------------------------------------------
# Read in the configuraton files
#-----------------------------------------------------------------------------
typeset -u DbfBkupType
typeset -u ChanType
typeset -u ArcChanType
typeset -u DbfChanType
typeset -u DbfIncrType
typeset -u MediaVendor
typeset -u FileNameFormat
typeset -l DbfLevel
typeset -l DbfLevelCmd
typeset -i FilesPerSet=0
typeset -i DbfFilesPerSet=0
typeset -i ArcFilesPerSet=0
typeset -i DbfBkupDirCnt=0
typeset -i ArcBkupDirCnt=0
typeset -i ChanCount=0
typeset -i RmanFraFullPct=50


FRAActive=${False}
FRANoEmail=${False}
CatActive=${True}
ArcInclude=${False}
DelObsolete=${False}
DelObsoleteRun=${False}
FixAIXSBTLibrary=${True}
DelObsolete_RecWindowChk=${True}
MsgWarning=""
BkupArcEmail=${False}
BkupCtlEmail=${False}
RunBldRecovery=${False}
BkupFraUseArchPolicy=${False}

AVAMAR_BASE="/usr/local/avamar"
# only used for v.226, then commented out, then added back for V.231+.
AvamarFileUpdate=${True}

# Check for System Global configuration file first.
if [[ -r ${ConfigDir}/global.cfg ]]
then
        ReadConfigFile ${ConfigDir}/global.cfg
fi

# Check for an Owner configuration file next.
if [[ -r ${ConfigDir}/owner_${UserName}.cfg ]]
then
        ReadConfigFile ${ConfigDir}/owner_${UserName}.cfg
else
        if [[ -r ${ConfigDir}/global_${UserName}.cfg ]]
        then
                ReportMsg "INFORMATIONAL" "Configuration files named \"global_${UserName}.cfg\" should be converted to \"owner_${UserName}.cfg\"."
                ReadConfigFile ${ConfigDir}/global_${UserName}.cfg
        fi
fi

# If we have an Instance level configuration file read it and let
# its values override the previous configuration file's
if [[ -r ${ConfigDir}/instance_${OracleSid}.cfg ]]
then
        ReadConfigFile ${ConfigDir}/instance_${OracleSid}.cfg
else
        if [[ -r ${ConfigDir}/${OracleSid}.cfg ]]
        then
                ReportMsg "INFORMATIONAL" "The configuration file named \"${OracleSid}.cfg\" should be converted to \"instance_${OracleSid}.cfg\"."
                ReadConfigFile ${ConfigDir}/${OracleSid}.cfg
        fi
fi



#-----------------------------------------------------------------------------
# Verify remaining options and arguments specifed are correct.
#-----------------------------------------------------------------------------

# Unset TWO_TASK, this script is designed to run against a local instance
if [[ -n ${TWO_TASK} ]]
then
        unset TWO_TASK
fi

if [[ -f ${LocalBin}/oraprof ]]
then
        . ${LocalBin}/oraprof ${OracleSid}
        if (( ${oraenv_rc} != 0 ))
        then
                ReportMsg "${FailureSeverity}" "Environment setup script failed: ${LocalBin}/oraprof ${OracleSid}"
                exit;
#               CleanupAndExit 1  # cant cleanup since no tmp or log files have been set up.
        fi
else
        ReportMsg "${FailureSeverity}" "Environment setup script not found: ${LocalBin}/oraprof"
        CleanupAndExit 1
fi

# Figure out if we are doing a backup of a cloned copy
if [[ -n ${DbfCloneOpt} ]]
then
        # Command Line can override configuration file.
        DbfClone=${DbfCloneOpt}
fi

# Figure out if we need to do a Proxy Copy backup or not.
if [[ -n ${DbfProxyCopyOpt} ]]
then
        # Command Line can override configuration file.
        DbfProxyCopy=${DbfProxyCopyOpt}
fi

# Log Directory and File
LogDir=${RmanLogDir:-${LogDir}}
if [[ ${DbfClone} = ${True} && -n ${CloneLogDir} ]]
then
        LogDir=${CloneLogDir}
fi
if [[ ! -d ${LogDir} || ! -w ${LogDir} ]]
then
        mkdir -p ${LogDir}
        rc=${?}
        if (( ${rc} != 0 )) || [[ ! -w ${LogDir} ]]
        then
                LogDir=/tmp
        fi
fi

# Temporary Directory and Files
TmpDir=${RmanTmpDir:-${TmpDir}}

if [[ ${DbfClone} = ${True} && -n ${CloneTmpDir} ]]
then
        TmpDir=${CloneTmpDir}
fi
if [[ ! -d ${TmpDir} || ! -w ${TmpDir} ]]
then
        mkdir -p ${TmpDir}
        rc=${?}
        if (( ${rc} != 0 )) || [[ ! -w ${TmpDir} ]]
        then
                TmpDir=/tmp
        fi
fi

# For some of the commands include the job type in the output file names.
# Make the default to include the type but allow for old format as well.
NamePrefix="${ScriptName}_${ORACLE_SID}"
case ${Command} in
        BKUPDB|BKUPTS)
                if [[ ${FileNameFormat} != "SIMPLE" ]]
                then
                        if [[ ${BkupValidate} = ${False} ]]
                        then
                                NamePrefix="${ScriptName}_${ORACLE_SID}_dbf"
                        else
                                NamePrefix="${ScriptName}_${ORACLE_SID}_val"
                        fi
                fi
                ;;
        BKUPFRA)
                if [[ ${FileNameFormat} != "SIMPLE" ]]
                then
                        NamePrefix="${ScriptName}_${ORACLE_SID}_fra"
                fi
                ;;
        BKUPCTL)
                if [[ ${FileNameFormat} != "SIMPLE" ]]
                then
                        NamePrefix="${ScriptName}_${ORACLE_SID}_ctl"
                fi
                ;;
        MONFRA)
                if [[ ${FileNameFormat} != "SIMPLE" ]]
                then
                        NamePrefix="${ScriptName}_${ORACLE_SID}_monfra"
                fi
                ;;
        RESTOREVAL)
                if [[ ${FileNameFormat} != "SIMPLE" ]]
                then
                        NamePrefix="${ScriptName}_${ORACLE_SID}_restval"
                fi
                ;;
        BKUPARC)
                if [[ ${FileNameFormat} != "SIMPLE" ]]
                then
                        NamePrefix="${ScriptName}_${ORACLE_SID}_arc"
                fi
                ;;
        DELOBSOLETE)
                if [[ ${FileNameFormat} != "SIMPLE" ]]
                then
                        NamePrefix="${ScriptName}_${ORACLE_SID}_del"
                fi
                ;;
        DELEXPIRED)
                if [[ ${FileNameFormat} != "SIMPLE" ]]
                then
                        NamePrefix="${ScriptName}_${ORACLE_SID}_exp"
                fi
                ;;
esac

# Primary Log File
LogFile=${LogDir}/${NamePrefix}_${DateTime}.log


# Trace File
TrcFile=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}.trc

# Temporary Files
TmpFile1=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}_1.tmp
TmpFile2=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}_2.tmp
TmpFile3=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}_3.tmp
TmpFile4=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}_4.tmp
TmpFile5=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}_5.tmp
TmpFile6=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}_6.tmp
TmpFile7=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}_7.tmp
TmpFile8=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}_8.tmp
TmpFile9=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}_9.tmp
TmpFile10=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}_10.tmp
TmpFile11=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}_11.tmp
TmpFile12=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}_12.tmp
TmpFile13=${TmpDir}/${NamePrefix}_${DateTime}_${Pid}_13.tmp

if [[ ${Verbose} = ${True} ]]
then
        print "LogFile: ${LogFile}"
        print "TrcFile: ${TrcFile}"
        print "TmpFile1: ${TmpFile1}"
        print "TmpFile2: ${TmpFile2}"
        print "TmpFile3: ${TmpFile3}"
        print "TmpFile4: ${TmpFile4}"
        print "TmpFile5: ${TmpFile5}"
        print "TmpFile6: ${TmpFile6}"
        print "TmpFile7: ${TmpFile7}"
        print "TmpFile8: ${TmpFile8}"
        print "TmpFile9: ${TmpFile9}"
        print "TmpFile10: ${TmpFile10}"
        print "TmpFile11: ${TmpFile11}"
fi
#
# Find Version because GIT version is different than CVS
#
grep "^# \$Id:" ${LocalBin}/orarman >${TmpFile1}
sed -s s/"# \$Id:"/"\$Id:"/g ${TmpFile1} >${TmpFile2}
ScriptId=`cat ${TmpFile2}`
#
grep "^# Version:" ${LocalBin}/orarman | head -1 >${TmpFile1}
ScriptVersion=`cat ${TmpFile1}`
#
# Version: orarman,v 2.42
#
# Echo orarman version to logfile
echo "${ScriptName}" > ${LogFile} 2>&1
echo "${ScriptId}" >> ${LogFile} 2>&1
echo "${ScriptVersion}" >> ${LogFile} 2>&1

# After the config files has been read, record the start to EDS tables if required.
if [[ ${Command} = "BKUPDB" ]]
then
        EDS_Report Start;
fi

# Backup Directory to dump/backup the SPFile
if [[ -z ${SPFileBkupDir} ]]
then
        if [[ -n ${VTierTop} ]] && [[ -d ${VTierTop}/${UserName} ]]
        then
                SPFileBkupDir=${VTierTop}/${UserName}/oracle/admin/${ORACLE_SID}/backups
        else
                SPFileBkupDir=${UserHome}/admin/${ORACLE_SID}/backups
        fi
fi
if [[ ! -d ${SPFileBkupDir} || ! -w ${SPFileBkupDir} ]]
then
        mkdir -p ${SPFileBkupDir}
        rc=${?}
        if (( ${rc} != 0 )) || [[ ! -w ${SPFileBkupDir} ]]
        then
                SPFileBkupDir=/tmp
        fi
fi
TS=`date +"%Y%m%d_%H%M%S"`
SPFileBkupName=${SPFileBkupDir}/init${ORACLE_SID}_${TS}.txt

# Determine the MediaVendor to use.
if [[ -n ${MediaVendorOpt} ]]
then
        MediaVendor=${MediaVendorOpt}
fi
case ${MediaVendor} in
        TSM|ADSM)
                MediaVendor="TSM"
                ;;
        NBU|NETBACKUP)
                MediaVendor="NETBACKUP"
                ;;
        AVAMAR)
                MediaVendor="AVAMAR"
                ;;
        DDBOOST)
                MediaVendor="DDBOOST"
                ;;
        DUMMY)
                MediaVendor="DUMMY"
                ;;
        *)
                MediaVendor="NONE"
                ChanType="DISK"
                DbfChanType="DISK"
                ArcChanType="DISK"
                ;;
esac

# Check to see if the Force option is set for the delete obsolete.
if [[ ${DelObsoleteForceOpt} = ${True} ]]
then
        DelObsoleteForce=${True}
fi

# Make sure we know if it is a ONLINE or a OFFLINE backups
if [[ -n ${DbfBkupTypeOpt} ]]
then
        DbfBkupType=${DbfBkupTypeOpt}
fi
case ${DbfBkupType} in
        HOT|ONLINE)
                DbfBkupType="ONLINE"
                ;;
        COLD|OFFLINE)
                DbfBkupType="OFFLINE"
                ;;
        *)
                DbfBkupType="ONLINE"
                ;;
esac

if [[ ${DbfClone} = ${True} ]]
then
        if [[ -z ${CloneMountHost} ]]
        then
                ReportMsg "${FailureSeverity}" "Clone Backup requested, but the Clone Mount Host is not set!"
                CleanupAndExit 1
        fi

        if [[ -z ${CloneSourceSid} ]]
        then
                CloneSourceSid=${ORACLE_SID}
        fi
        if [[ -z ${CloneMountSid} ]]
        then
                CloneMountSid=${ORACLE_SID}
        fi
fi

# Verify the Skip Option if set
if [[ -n ${SkipTimeOpt} ]]
then
        SkipTime=${SkipTimeOpt}
fi
if [[ -n ${SkipTime} ]]
then
        if [[ ${SkipTime} = *d ]]
        then
                # Days
                SkipDays=$(echo ${SkipTime} | sed -e 's/d$//')
        elif [[ ${SkipTime} = *h ]]
        then
                # Hours
                SkipDays=$(echo ${SkipTime} | sed -e 's/h$//' | ${AWK} '{printf "%f\n", (1 / 24) * $1}')
        elif [[ ${SkipTime} = *m ]]
        then
                # Minutes
                SkipDays=$(echo ${SkipTime} | sed -e 's/m$//' | ${AWK} '{printf "%f\n", (1 / 1440) * $1}')
        else
                # Error
                ReportMsg "${FailureSeverity}" "Skip requested, but the format is invalid: ${SkipTime}"
                CleanupAndExit 1
        fi
fi

#-----------------------------------------------------------------------------
# Make sure the Instance is up and in the correct archivelog mode.
#-----------------------------------------------------------------------------
InstanceStatus
ExitCode=${?}
if (( ${ExitCode} != 0 ))
then
        ReportMsg "${FailureSeverity}" "Failed to determine the status of the instance!"
        CleanupAndExit ${ExitCode}
fi

if (( ${MajorRel} < 9 ))
then
        ReportMsg "${FailureSeverity}" "Oracle Database Releases less than 9.x are not supported by this version of ${ScriptName}!"
        CleanupAndExit ${ExitCode}
fi

# Set NLS Parameters
export NLS_DATE_FORMAT='YYYY/MM/DD HH24:MI:SS'

# Added to correct problem on AIX with FRA, J. Thorn, M. Roth
SqlConnect="/ as sysdba"
SqlCommand="SELECT 'Cmd1:'||lang||'_'||terr||'.'||cset from
        (select value lang from v\$nls_parameters where PARAMETER='NLS_LANGUAGE'),
        (select value terr from v\$nls_parameters where PARAMETER='NLS_TERRITORY'),
        (select value cset from v\$nls_parameters where PARAMETER='NLS_CHARACTERSET');"

RunSql "${SqlCommand}"

NLSLang=$(grep "^Cmd1:" ${TmpFile1} | sed -e 's/^Cmd1://' -e 's/ *$//')
if [[ -n ${NLSLang} ]]
then
        export NLS_LANG=${NLSLang}
else
        ReportMsg "" "Unable to determine value for NLS_LANG environment variable!"
fi

CmdFile=${TmpDir}/${ScriptName}_${ORACLE_SID}_${DateTime}_${Pid}.cmd
if [[ ${Verbose} = ${True} ]]
then
        print "CmdFile: ${CmdFile}"
fi

# Set initial starttime.  Will be used in event of an early exit from program.
StartDate=$(date +'%m/%d/%Y')
StartTime=$(date +'%H:%M:%S')

# Backup Tag
BackupTagDate=`date +"%m%d%Y_%H%M%S"`
BackupTag="${ORACLE_SID}_${BackupTagDate}"
#
# If we are running Avamar, check and cycle file if a new month.
#
if [[ ${MediaVendor} = "AVAMAR" ]]
then
        CycleAvamarLog;
fi
#
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
# Main Script Logic
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------

case ${Command} in
        BKUPDB|BKUPTS|BKUPFRA)
                # Cannot allow BKUPFRA comman to run withou FRAActive set.
                if [[ ${Command} = "BKUPFRA" && ${FRAActive} = ${False} ]]
                then
                        ReportMsg "${FailureSeverity}" "BKUPFRA is not an option, unless RMAN_FRA_ACTIVE parameter is set to True"
                        CleanupAndExit 1
                fi
                # Notify Patrol that the backup has started
                if [[ -n ${PatrolStartNotify} && -x ${PatrolStartNotify} ]]
                then

                        BackupName="${ScriptName}-${ORACLE_SID}"

                        if [[ -n ${PatrolTag} ]]
                        then
                                BackupName="${BackupName}-${PatrolTag}"
                        fi
                        ${PatrolStartNotify} "${BackupName}"
                fi
                # check BkupFRARun for true, if so execute the BKUPFRA first
                #
                if [[ ${Command} = "BKUPDB" || ${Command} = "BKUPTS" ]] &&
                        [[ ${BkupFRARun} = ${True} && ${BkupValidate} = ${False} ]]
                then
                        if [[ -x ${LocalBin}/orarman ]]
                        then
                                ${LocalBin}/orarman -s ${ORACLE_SID} -c BKUPFRA -T FRA ${ConfigDirOpt} ${DebugOpt} ${VerboseOpt}
                        else
                                ReportMsg "WARNING" "Unable to perform Backup FRA, command not found"
                        fi
                fi


                if [[ "${DbfBkupType}" = "ONLINE" ]] && [[ "${LogMode}" = "NOARCHIVELOG" ]]
                then
                        ReportMsg "${FailureSeverity}" "Database in NOARCHIVELOG mode, ONLINE backup not allowed!"
                        CleanupAndExit 1
                fi

                GenCmdFile ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                then
                        ReportMsg "${FailureSeverity}" "Failed to create the RMAN Command File"
                        CleanupAndExit 1
                fi

                # Acquire a Lock to make sure we are not already running.
                AcquireLock ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 ))
                then
                        ReportMsg "${FailureSeverity}" "Unable to acquire a lock to start ${Command}"
                        CleanupAndExit ${ExitCode}
                fi

                if [[ -n ${DbfBkupUserBegin} ]] && [[ ${Command} = "BKUPDB" || ${Command} = "BKUPTS" || ${Command} = "BKUPFRA" ]]
                then
                        export UserState="UserBegin"
                        eval "(${DbfBkupUserBegin}; echo RC: \${?})" >> ${TmpFile1} 2>&1
                        CmdRc=$(grep "^RC: " ${TmpFile1} 2>/dev/null | tail -1 | ${AWK} '{print $2}')
                        if (( ${CmdRc} != 0 ))
                        then
                                ReportMsg "${FailureSeverity}" "User Begin Script Failed, RC=${CmdRc}"
                                CleanupAndExit ${CmdRc}
                        fi
                fi

                # Run the Command
                RunCmdFile ${Command}
                ExitCode=${?}


                # If we are including the archived redo logs in the backup, kick off the script to
                # backup any currently archived redo logs.
                if [[ ${ArcInclude} = ${True} && ${LogMode} = "ARCHIVELOG" ]]
                then
                        if [[ -x ${LocalBin}/orarman ]]
                        then
                                ${LocalBin}/orarman -s ${ORACLE_SID} -c BKUPARC -o ALLARC ${ConfigDirOpt} ${DebugOpt} ${VerboseOpt}
                        else
                                ReportMsg "WARNING" "Unable to perform archive log backup, command not found"
                        fi
                fi


                #
                # check BkupFRARun for true, if so execute the BKUPFRA after BKUPDB also.
                #
                if [[ ${Command} = "BKUPDB" || ${Command} = "BKUPTS" ]] &&
                        [[ ${BkupFRARun} = ${True} && ${BkupValidate} = ${False} ]]
                then
                        if [[ -x ${LocalBin}/orarman ]]
                        then
                                if [[ ${CleanupLock} = ${True} ]]
                                then
                                        rm -f ${LockFile}
                                        CleanupLock=${False}
                                fi

                                ${LocalBin}/orarman -s ${ORACLE_SID} -c BKUPFRA -T FRA ${ConfigDirOpt} ${DebugOpt} ${VerboseOpt}
                        else
                                ReportMsg "WARNING" "Unable to perform Backup FRA, command not found"
                        fi
                fi
                #
                #  Check to see if we need to create default recovery scripts for a BKUPDB
                #
                if [[ ${Command} = "BKUPDB" && ${RunBldRecovery} = ${True} ]]
                then
                        if [[ -f ${LocalBin}/orarman_bld_recovery ]]
                        then
                                ${LocalBin}/orarman_bld_recovery
                        fi
                fi
                ;;

        BKUPCTL)

                GenCmdFile ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                then
                        ReportMsg "${FailureSeverity}" "Failed to create the RMAN Command File"
                        CleanupAndExit 1
                fi

                # Acquire a Lock to make sure we are not already running.
                AcquireLock ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 ))
                then
                        ReportMsg "${FailureSeverity}" "Unable to acquire a lock to start ${Command}"
                        CleanupAndExit ${ExitCode}
                fi

                # Run the Command
                RunCmdFile ${Command}
                ExitCode=${?}

                ;;
        MONFRA)

                # Acquire a Lock to make sure we are not already running.
                AcquireLock ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 ))
                then
                        ReportMsg "WARNING" "Unable to acquire a lock to start ${Command}"
                fi

                if (( ${ExitCode} == 0 ))
                then
                        MonFRACmds;
                        ExitCode=${?}
                        if (( ${ExitCode} != 0 ))
                        then
                                ReportMsg "${FailureSeverity}" "Failed to Execute MONFRA Command File"
                                CleanupAndExit 1
                        fi
                fi
                ;;
        RESTOREVAL)

                # Acquire a Lock to make sure we are not already running.
                AcquireLock ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 ))
                then
                        ReportMsg "WARNING" "Unable to acquire a lock to start ${Command}"
                fi

                if (( ${ExitCode} == 0 ))
                then
                        GenCmdFile ${Command}
                        ExitCode=${?}
                        if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                        then
                                ReportMsg "${FailureSeverity}" "Failed to create the RMAN Restore Validate Command File"
                        fi
                fi

                if (( ${ExitCode} == 0 ))
                then
                        RunCmdFile ${Command}
                        ExitCode=${?}
                        if (( ${ExitCode} != 0 ))
                        then
                                ReportMsg "${FailureSeverity}" "Failed to Execute RESTOREVAL Command File"
                                CleanupAndExit 1
                        fi
                fi
                ;;
        BKUPARC)

                if [[ "${LogMode}" = "NOARCHIVELOG" ]]
                then
                        ReportMsg "${FailureSeverity}" "Database in NOARCHIVELOG mode, Archive Log backup not allowed!"
                        CleanupAndExit 1
                fi

                if [[ ${ArcLogDestType} = "FRA" ]]
                then
                        #
                        # Added and extra check and a warning to allow a BKUPARC while running a FRA.  This was not allowed in
                        # the past. MediaVendor must be set up to None for this to work.  (J.Thorn 08/24/09)
                        #
                        if [[ ${ArcBkupDirCnt} < 1 ]] || [[ ${MediaVendor} != "NONE"  ]]
                        then
                                ReportMsg "WARNING" "Command: BKUPARC is not valid when archive logs are going to the Flash Recovery Area.  BKUPARC is only valid when RMAN_MEDIA_VENDOR is not set and RMAN_ARC_BKUPDIR is assigned to a valid directory outside of of the FRA."
                                ReportMsg "WARNING" "Command: BKUPARC job has been stopped."
                                CleanupAndExit 0
                        fi
                elif [[ -n ${ArcBkupFreeKB} ]]
                then
                        Line=$(DiskFree ${ArcLogDestDir})
                        FreeKB=$(echo ${Line} | ${AWK} '{print $3}')
                        if [[ ${AllArcFlag} = ${False} ]] && (( ${FreeKB} > ${ArcBkupFreeKB} ))
                        then
                                ReportMsg "" "Archive Log Destination Free Space above Minimum, ${FreeKB} > ${ArcBkupFreeKB}"
                                CleanupAndExit 0
                        fi
                fi

                # Acquire a Lock to make sure we are not already running.
                AcquireLock ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 ))
                then
                        ReportMsg "WARNING" "Unable to acquire a lock to start ${Command}"
                fi

                if (( ${ExitCode} == 0 ))
                then
                        GenCmdFile ${Command}
                        ExitCode=${?}
                        if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                        then
                                ReportMsg "${FailureSeverity}" "Failed to create the RMAN Command File"
                        fi
                fi

                if (( ${ExitCode} == 0 ))
                then
                        RunCmdFile ${Command}
                        ExitCode=${?}
                fi

                if [[ -n ${ArcAlarmFreeKB} ]]
                then
                        Line=$(DiskFree ${ArcLogDestDir})
                        FreeKB=$(echo ${Line} | ${AWK} '{print $3}')
                        if (( ${FreeKB} < ${ArcAlarmFreeKB} ))
                        then
                                ReportMsg "CRITICAL" "Archive Log Destination Free Space below Minimum, ${FreeKB} < ${ArcAlarmFreeKB}"
                        fi
                fi
                ;;

        RESYNCCAT)

                GenCmdFile ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                then
                        ReportMsg "${FailureSeverity}" "Failed to create the RMAN Command File"
                        CleanupAndExit 1
                fi

                RunCmdFile ${Command}
                ExitCode=${?}
                ;;

        SHOWALL)

                GenCmdFile ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                then
                        ReportMsg "${FailureSeverity}" "Failed to create the RMAN Command File"
                        CleanupAndExit 1
                fi

                RunCmdFile ${Command}
                ExitCode=${?}
                ;;

        DELOBSOLETE)

                #
                # Added DelObsolete_RecWindowChk to eliminate the "recovery window 1 day" check, when this
                # value is set in the .cfg file.  - J.Thorn - 09/23/09
                #
                if [[ ${DelObsolete_RecWindowChk} = ${True} ]]
                then
                        GenCmdFile SHOWALL
                        ExitCode=${?}
                        if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                        then
                                ReportMsg "${FailureSeverity}" "Delete Obsolete: Failed to create the RMAN Command File"
                                CleanupAndExit 1
                        fi
                        RunCmdFile SHOWALL > ${TmpFile1} 2>&1
                        ExitCode=${?}
                        if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                        then
                                ReportMsg "${FailureSeverity}" "Delete Obsolete: Failed to run the RMAN Command File"
                                CleanupAndExit 1
                        fi
                        if [[ -f ${TmpFile1} ]]
                        then
                                RecoveryWindow=$(grep -i "RETENTION POLICY TO RECOVERY WINDOW" ${TmpFile1} | ${AWK} '{print $8}')
                        fi

                        if [[ -n ${RecoveryWindow} ]]
                        then
                                if (( ${RecoveryWindow} <= 1 ))
                                then
                                        ReportMsg "${FailureSeverity}" "Delete Obsolete: Recovery Window must be greater than 1 day"
                                        CleanupAndExit 1
                                fi
                        else
                                ReportMsg "${FailureSeverity}" "Delete Obsolete: Recovery Window must be set"
                                CleanupAndExit 1
                        fi
                fi

                GenCmdFile ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                then
                        ReportMsg "${FailureSeverity}" "Delete Obsolete: Failed to create the RMAN Command File"
                        CleanupAndExit 1
                fi

                RunCmdFile ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 ))
                then
                        ReportMsg "${FailureSeverity}" "Failed to Execute DELOBSOLETE - Review ${LogFile} "
                        CleanupAndExit 1
                fi
                ;;
        DELEXPIRED)

                GenCmdFile SHOWALL
                ExitCode=${?}
                if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                then
                        ReportMsg "${FailureSeverity}" "Delete Expired: Failed to create the RMAN Command File"
                        CleanupAndExit 1
                fi
                RunCmdFile SHOWALL > ${TmpFile1} 2>&1
                ExitCode=${?}
                if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                then
                        ReportMsg "${FailureSeverity}" "Delete Expired: Failed to run the RMAN Command File"
                        CleanupAndExit 1
                fi
                GenCmdFile ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                then
                        ReportMsg "${FailureSeverity}" "Delete Expired: Failed to create the RMAN Command File"
                        CleanupAndExit 1
                fi
                RunCmdFile ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 ))
                then
                        ReportMsg "${FailureSeverity}" "Failed to Execute DELEXPIRED - Review ${LogFile} "
                        CleanupAndExit 1
                fi
                ;;

        UNREGDB)

                GenCmdFile ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                then
                        ReportMsg "${FailureSeverity}" "Failed to create the RMAN Command File"
                        CleanupAndExit 1
                fi

                RunCmdFile ${Command}
                ExitCode=${?}
                ;;
        REGDB)

                GenCmdFile ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                then
                        ReportMsg "${FailureSeverity}" "Failed to create the RMAN Command File"
                        CleanupAndExit 1
                fi

                RunCmdFile ${Command}
                ExitCode=${?}
                ;;

        CRCAT)

                GenCmdFile ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                then
                        ReportMsg "${FailureSeverity}" "Failed to create the RMAN Command File"
                        CleanupAndExit 1
                fi

                RunCmdFile ${Command}
                ExitCode=${?}
                ;;

        CHGARCXCHK)

                GenCmdFile ${Command}
                ExitCode=${?}
                if (( ${ExitCode} != 0 )) || [[ ! -f ${CmdFile} ]]
                then
                        ReportMsg "${FailureSeverity}" "Failed to create the RMAN Command File"
                        CleanupAndExit 1
                fi

                RunCmdFile ${Command}
                ExitCode=${?}
                ;;

        *)
                ReportMsg "WARNING" "Invalid Script Command: ${Command}"
                ShowUsage
                CleanupAndExit 1
                ;;
esac


# If we are running the delete obsolete, kick off the script to do it now.
if [[ ${Command} = "BKUPDB" || ${Command} = "BKUPTS" || ${Command} = "BKUPARC" || ${Command} = "BKUPFRA" ]] &&
        [[ ${DelObsoleteRun} = ${True} && ${BkupValidate} = ${False} ]]
then
        if [[ -x ${LocalBin}/orarman ]]
        then
                ${LocalBin}/orarman -s ${ORACLE_SID} -c DELOBSOLETE ${ConfigDirOpt} ${DebugOpt} ${VerboseOpt}
        else
                ReportMsg "WARNING" "Unable to perform Delete Obsolete, command not found"
        fi
fi

CleanupAndExit ${ExitCode}
#----------------------------------------------------------------------------
# Revision History:
# $Log$
#
# Revision 2.42  2016/02/15 jt7190
# 1)    Updated to display Backup Start and End times, when job hits an error and doesnt start the RMAN script.
# 2)    For RAC environments running the EBR vip to control the where the backup can run, modified to allow BKUPDB
#       to FRA on nodes where the EBR vip is not running.  This will not impact BKUPDB jobs to Tape/Media Managers,
#       such as Avamar or NBU.
# 3)    Updated internal process to identify orarman version with GIT code control.
# 4)    Updated Avamar API function call.  No need to specifically check for EBR, NEBR or GPN; the network type will
#       be determined by the path variable read from avagent.log fiel.
# 5)    For EBR manual override of failed API call, add code to read /var/avamar/ORACLE_SID_dd.cfg file to get ddr
#       and ddr-index values.
# 6)    Added additional Avamar debug information to the log file when a job stops because of a Avamar/RMAN error.
# 7)    Corrected bug where DELEXPIRED was executing without a Tape channel if running DELEXPIRED without using a FRA
# 8)    Updated Avamar API function, to allow Avamar local configuration to override the Avamar API.  If Avamar API
#       call returns 0 rows, check /var/avamar/SID_dd.cfg for avamar flag variables, DDR and DDR-INDEX values.
#
# Revision 2.41  2015/07/28 15:52:24  jt7190
# (first release with GIT code control, so all comments after this will be
#  added manually)
# Revision 2.40  2015/07/28 15:52:24  jt7190
# Modified DeleteCmds function to not create a Tape channel for DELEXPIRED
# when rman_fra_active is not true and rman_channel_type is sbt_tape.
#
# Revision 2.39  2015/07/13 15:17:41  jt7190
# Fixed bug where  MONFRA job was kicking off a BKUPFRA and the lockfile was not being removed first.
#
# Revision 2.38  2015/07/01 20:47:49  jt7190
# Fixed a orarman bug in Solaris where a local variable was used as
# a global variable in the ReportMsg function. Added new FoundStatus local
# variable.
#
# Revision 2.37  2015/06/29 21:08:13  jt7190
# Add check to make sure the alert log is available from orarman code prior to
# writing Success or Failure messages for monitor.
#
# Revision 2.36  2015/06/25 13:15:32  jt7190
#
# Updated message for failure to read avagent.log file again.
#
# Revision 2.35  2015/06/24 11:27:23  jt7190
# Updated message for failure to read avagent.log file.
#
# Revision 2.34  2015/06/22 12:30:04  jt7190
#
# Fixed bug found during testing of ChkAvamar function, with DDRChanged variable.
#
# Revision 2.33  2015/06/19 10:54:24  jt7190
# Changed call to use production Avamar API in the ChkAvamarFlags function.
#
# Revision 2.32  2015/06/16 20:09:32  jt7190
# Updated ebr_setup scripts with DSU size to 32768.  Also fixed a syntax error in orarman.
#
# Revision 2.31  2015/06/10 20:28:20  jt7190
# - Added ChkAvamarFlagsFile function to interpret a number of areas and automatically update the
#   avamar configuration flags file when necessary.
# - Added function to cycle thru avtar.log files and compress monthly.
#
# Revision 2.30  2015/02/20 17:05:29  jt7190
# Added check when running BKUPFRA with Avamar, reset channels to 10 if the .cfg file sets it higher than 10.
#
# Revision 2.29  2015/02/11 15:11:26  jt7190
# Corrected bug in MONFRA check for existing running jobs.
#
# Revision 2.28  2015/02/09 17:50:50  jt7190
# - Added new RAC ebr setup scripts, ebr_setup and ebr_service.  These scripts will be used to setup  ASM DSUs for NBU backups.
# - Updated RESTOREVAL function to run Avamar media manager with Oracle Data Guard Primary/Local Standby databases.
# - After the failure of a L 0 backup,  and a level 1 is running next, then automatically modify the L1 to a L0 and execute the backup.
# - Not allow MONFRA job to run when BKUPDB and/or BKUPFRA is currently running.
# - Write successful and failure messages to Oracle Alert log for BKUPDB, BKUPFRA, BKUPRC jobs.
#
# Revision 2.27  2014/08/25 18:39:10  jt7190
# Removed calls to ChkAvamarPath function.
#
# Revision 2.26  2014/08/05 20:48:17  jt7190
# removed "i" character in read config file function.
#
# Revision 2.25  2014/08/04 17:49:56  jt7190
# - Updated to remove warning message when avagent.log file is not readable.
# - Removed default run of orarman_bld_recovery script.  It will not be run by default, but can be executed
#   by setting the rman_run_orarman_bld_recovery=true.
#
# Revision 2.24  2014/07/29 19:03:55  jt7190
# Added ChkAvamarPath function to compare the avagent.log file to get the path variable for the avamar flags file.
# This will allow the Avamar domain to be changed at the Avamar Grid level and the avamar flags fill will be
# automatically modified at backup runtime, while executing orarman.
#
# Revision 2.23  2014/05/07 17:04:54  jt7190
# Update RAC_Check messages to be RAC message and not NBU specific.
#
# Revision 2.21  2014/05/01 21:19:43  jt7190
# *** empty log message ***
#
# Revision 2.20  2014/05/01 19:09:07  jt7190
# For Avamar backups, 1) change the cache file used when allocating a channel to
# use SID to make it unique, and allow multiple vtier databases to run backups
# on the same server, 2) restrict max channel count to 10 for Avamar backups.
#
# Revision 2.19  2014/04/25 12:14:52  jt7190
# Added code to handle Oracle RAC/Avamar backups, with the CRS EBR vip service.
#
# Revision 2.18  2014/04/25 12:12:45  jt7190
# Correct comment
#
# Revision 2.17  2014/02/18 19:54:15  jt7190
# Removed v$database_block_corruptions from MONFRA job.
#
# Revision 2.16  2014/02/10 19:20:52  jt7190
# - Additional info for emails for DELOBSOLETE/DELEXPIRED jobs.
# - During BKUPDB, BKUPTS, BKUPFRA, BKUPARC and BKUPCTL, check v$database_block_corruptions for rows, ad
# n if rows found, email DBA.
# - Use rman_sectionsize parameter from .cfg file only if 11g and higher.
# - Modified tmpfile used by orarman_bld_recovery script to avoid any conflict orarman script.
#
# Revision 2.15  2013/10/22 16:53:07  jt7190
# Added Avamar info to email.
#
# Revision 2.14  2013/10/16 12:05:24  jt7190
# Added NBU log information to logfile/email when a NBU backup failure occurs.
#
# Revision 2.13  2013/10/09 13:47:14  jt7190
# Added Avamar Grid print to email, and set default rman_sectionsize=200G in orarman.cfg.
#
# Revision 2.12  2013/06/21 17:02:48  jt7190
# Correct issue where NBU Tag list was greater that 2500 characters, which
# created a "SP2-0027: Input is too long (> 2499 characters) - line ignored"
# error.  This impacted ARTT reporting.
#
# Revision 2.11  2013/06/10 15:44:23  jt7190
# corrected in FRANoEmail logic to send LDDB/DOD emails even when set to true
#
# Revision 2.10  2013/06/05 21:21:24  jt7190
# Correcting CVS version to 2.10
#
# Revision 2.1  2013/06/05 21:13:15  jt7190
# moving to revision 2.0
#
# Revision 1.100  2013/06/05 21:08:55  jt7190
# orarman script used to not email LDDB process(oracle@bkuptrack.sbc.com) for ARTT when executing the
# BKUPFRA job when .cfg parameter "rman_bkupfra_noemail=true". This new version of orarman will send
# emails to oracle@bkuptrack.sbc.com even when "rman_bkupfra_noemail=true".
#
# Revision 1.99  2013/06/04 18:23:50  jt7190
# Added 3 new EBR service scripts, removed Ping check, that was planned for this release.
#
# Revision 1.98  2013/05/31 19:57:50  jt7190
# fix typo
#
# Revision 1.97  2013/05/31 14:50:54  jt7190
#
# Adding check for ping location for different OSs. This will check for the default path,
# then where we think ping should be located for this OS, and if we cannot find it, then
# we do not check nb_ora_client with the ping command prior to executing the backup job.
#
# Revision 1.96  2013/05/30 13:23:48  jt7190
# - Updated to support RMAN DD Boost as a media server.
# - Updated RESTOREVAL to work with Data Guard Standby databases.
# - Enhancement to MONFRA function to call oradgdelarcs function to remove archivelogs on a
#   Data Guard Standby database.  This action will be triggered when the FRA reaches the defined
#   threshold as defined in the instance_SID.cfg file. This will run without the "oradgdelarcs -K" flag,
#   and will remove all archivelogs that have been applied to the Standby database. This will run only
#   on Standby databases.
# - Provide support for new RAC EBR cluster service.  New RAC install process will be to schedule the
#   orarman job on all nodes.  If the EBR cluster service does not reside on the current node, the
#   job will exit, with no email failure notice.
#
# Revision 1.95  2013/04/12 18:53:27  jt7190
#
# Added MONFRA update to execute oradgdelarcs job when FRA is over the assigned
# threshold.  This function can only run on the Standby.  If the FRA threshold is
# reached on a non-StandbyDB, the BKUPFRA job will execute.
#
# Revision 1.94  2013/03/04 18:06:08  jt7190
#
# 1) Added code for DD Boost Media sever. 2) Removed "alter switchlog file" for
# RESTOREVAL when running on a Standby.
#
# Revision 1.93  2012/11/14 14:58:29  jt7190
#
# Updated variables exports for ACSI variables.
#
# Revision 1.92  2012/11/07 20:18:25  jt7190
#
# Fix typo from last update
#
# Revision 1.91  2012/11/07 14:11:49  jt7190
#
# Corrected variable passing for sending oracle@bkuptrack.sbc.com ARTT details.
#
# Revision 1.90  2012/10/31 18:38:23  jt7190
#
# - Added a ACSI monitor script orarman_acsi_cmd and orarman_asci_cmd.cfg to provide ACSI applications
#   ability to continue monitoring with an existing process.
# - For Off Host Backups, create a 2nd channel for RESTOREVAL function.  This provdes the ability to
#   create a RMAN channel on the DBserver to reference backups with the source NB_ORA_CLIENT value,
#   which is in line with NetBackup 7.1 documentation.
#
# Revision 1.89  2012/02/07 18:50:02  mr7378
# Added support for Dummy API, oracle.disksbt SBT_LIBRARY, for testing.
# Added support to backup the Current Control File, part of the offhost backup changes.
#
# Revision 1.87  2011/11/30 16:44:14  mr7378
# Fixed bug introduced in 1.73 with offline backup, fixed error with MajorRel not being set
#
# Revision 1.86  2011/11/11 15:20:32  jt7190
# Added code to set the archivelog directory to be evaluated for size based
# on .cfg param rman_arc_bkup_freekb, to rman_arc_dest_dir.  Mostly used
# in GG configurations with multiple archivelog destinations.
#
# Revision 1.85  2011/09/28 19:13:14  jt7190
# Added check to only retrieve ARTT email data if running 10g or higher.
#
# Revision 1.84  2011/09/26 14:35:54  jt7190
#
# Fixed bug where the RMAN job would stop if the RMAN catalog connection fails
# because one of the follow parameters was undefined in the .cfg file:
# rman_cat_alias, rman_cat_schema,  rman_cat_password.
# The update will provide a Warning message, but will let the RMAN job continue.
#
# Revision 1.83  2011/09/20 14:21:21  jt7190
#
# Added new function RESTOREVAL, which should be used to validate the
# database backups.  Should be used with new installs to confirm backup
# can be successfully read for restores. Also, added check to MONFRA to
# not allow a second MONFRA job to start if a MONFRA job is already running.
#
# Revision 1.82  2011/09/06 16:44:03  mr7378
# Temporarily disable the standby controlfile backup for the Clone Backup
#
# Revision 1.81  2011/09/06 14:42:16  mr7378
# Relaxed parameter check for Clone Backup to allow SID to default
#
# Revision 1.80  2011/08/31 20:38:35  mr7378
# Added 2 more clone related parameters to force a different NBU Policy and Schedule
#
# Revision 1.79  2011/08/30 16:08:20  mr7378
# Added several new parameters that can be used with the RMAN Backup of the Cloned
# Databases, RMAN_CLONE_NB_ORA_SERV, RMAN_CLONE_NB_ORA_CLIENT, RMAN_CLONE_LOG_DIR
# and RMAN_CLONE_TMP_DIR, these are only used with RMAN_DBF_CLONE is true
#
# Added several new parameters to make configuration simpler and to be consistent
# with other scripts, RMAN_NB_ORA_CLASS, RMAN_NB_ORA_POLICY and RMAN_NB_ORA_SCHED so
# that a database backing up to the FRA has a clearer single set of parameters to set.
# And; TMP_DIR, RMAN_TMP_DIR to be consistent with other scripts.
#
# Revision 1.78  2011/08/08 15:33:26  jt7190
#
# Updated orarman to add default email to ARTT monitoring account, oracle@bkuptrack.sbc.com.
# This can be turned off by setting RMAN_NOTIFY_EMAIL_FLAG to FALSE in the instance_<SID>.cfg file.
#
# Revision 1.77  2011/06/29 18:26:24  jt7190
#
# Added a 2nd change in MONFRA function to define local varaiables without sourcing a tmp file.
#
# Revision 1.76  2011/06/27 19:03:32  jt7190
#
# Updated MONFRA section where select is made to gather data for MONFRA calcs.
# Reading a tmp script to define local variables instead of sourcing it.
#
# Revision 1.75  2011/06/16 19:52:35  mr7378
# Fixed source command on temporary file, that was missing a space from cleanup
#
# Revision 1.74  2011/06/16 13:29:43  mr7378
# Update to use ps command that is compatible with long usernames
#
# Revision 1.73  2011/05/10 17:04:30  mr7378
# Removed Oracle 8.x support, if used against 8.x this version will report an error.
# Added support for SECTION SIZE to better handle large database files.
# Modified how Standby Databases are handled, made it more generic to support any
# database that is backed up while only mounted.
# Added support for RMAN backup of a cloned database, this requires backing up in a
# mounted mode, and backing up control file that is not the current control file.
# Also added new clone specific parameters to identify the Source and Mount host
# names and Oracle SIDs.
# Updated Check Logical to apply to Backups to the Media Manager as well as to Disk.
# Fix Line break on AVAMAR Send Command.
# Replaced a lot of spaces with tabs and cleanup indentation.
#
# Revision 1.72  2011/04/11 15:12:01  jt7190
# Updated check for vtier by looking for /opt/app/${UserName}/oracle/local/etc directory.
#
# Revision 1.71  2011/01/28 14:24:04  jt7190
# Updated comments and readme notes for Avamar enhancement release.
#
# Revision 1.70  2011/01/25 16:05:08  jt7190
# Updated avamar send command for delete obsolete job.
#
# Revision 1.69  2011/01/21 17:49:23  jt7190
# Updated BKUPARC section for Avamar function.
#
# Revision 1.68  2011/01/17 17:12:57  jt7190
# path update for location of Avamar library
#
# Revision 1.67  2011/01/14 20:50:38  jt7190
# 1) Added fix for -F flag at the command line.
# 2) Added code to handle Avamar as a media server.
#
# Revision 1.66  2010/11/10 20:46:34  jt7190
# added NB_ORA_POLICY to email output for AART.
#
# Revision 1.65  2010/11/09 15:58:46  jt7190
# - Added email with successful BKUPARC job, assuming rman_bkuparc_email is set to true in the .cfg file.  Default is no email.
# - Added detailed BKUPARC email upon failure.
#
# Revision 1.64  2010/11/03 18:37:34  jt7190
# *** empty log message ***
#
# Revision 1.62  2010/10/11 17:13:33  jt7190
# fixed status flag during Exit routine.
#
# Revision 1.61  2010/10/08 19:47:04  jt7190
# Added tag/handle print for failed jobs also.
#
# Revision 1.60  2010/10/01 12:36:51  jt7190
# 1) Added additional completion message, to alert that a backup as
# successfully completed with warnings.
# 2) Added additional email info for LDDBA/AART application to use.
#
# Revision 1.59  2010/08/05 15:13:44  jt7190
# Added DELEXPIRED and DELOBSOLETE email notification during failed runs.
# Changed email notification for FRA label on FRA jobs. Added check for
# RMAN catalog connection, if it fails, continue job but with an email Warning.
#
# Revision 1.57  2010/05/19 12:44:45  jt7190
# Added fix for EDS_Report write at the end of job rec for only BKUPDB jobs.
#
# Revision 1.56  2010/04/29 12:31:48  jt7190
# Updated orarman version display during help request.
#
# Revision 1.55  2010/04/06 13:53:42  jt7190
# Added fix for MONFRA when executing against ASM.
# Fixed bug where "-v none" does not run a backup to disk.
#
# Revision 1.54  2010/01/29 16:17:38  jt7190
# Added Readme.orarman for new release, and added comments in orarman.
#
# Revision 1.53  2010/01/19 18:09:34  jt7190
# Removed debug statements.
#
# Revision 1.52  2010/01/19 16:01:00  jt7190
# Updated CVS tag for echoing orarman version to log file.
#
# Revision 1.51  2010/01/18 14:07:30  jt7190
#   Added the ability to backup up Data Guard Standby databases.
#   Added tag identifier "DGSB" for RMAN backup takein on standby database.
#   Added option to "check logical" option for checking for logical corruption using orarman.
#   Added echo of orarman version to logfile.
#
# Revision 1.50  2009/10/09 10:44:06  jt7190
# Updated fra_size date typo, gave example of Patrol entry in DbBAckupMonitorSched.txt,
# and updated release documentation in Readme.orarman.
#
# Revision 1.49  2009/09/30 16:34:28  jt7190
# Modified df_free calc to include fra_space_reclaimable.
#
# Revision 1.48  2009/09/23 18:58:21  jt7190
# 1) adding code to create FRA warnings when:
#    - FRA OS MountPoint is smaller than defined FRA size.
#    - Space on OS MounPoint is smaller than FRA thinks is available
# 2) added fix to EDS_Report- typo replaced "${Sqlcommand}" with "${SqlCommand}"
# 3) added check to skip the requirement that RMAN recovery window cannot be set
#    to 1. RMAN_DELOBSOLETE_RECOVERY_WINDOW_CHK added, default to True, but can be
#    set to true, to allow DELOBSOLETE to run with the recovery window set to 1 day.
# 4) Added "show all" to be executed against most orarman jobs
#
# Revision 1.47  2009/08/25 16:46:29  jt7190
# JT7190 - Added Matt Roths change in v1.45, which was removed when going to v1.46.
#
# Revision 1.46  2009/08/25 16:41:35  jt7190
# JT7190 - Made following oramran changes:
# 1) Allowed BKUPARC where FRA is being used, if MediaVender is set to NONE
# 2) Provided a function description for the RMAN set command.
# 3) Added EDS Reporting option.
# 4) Added calls to orarman_bld_recovery to biuld a recovery script in the log dir..  This is an unsupported feature.
#
# Revision 1.44  2009/07/08 20:11:50  jt7190
# Modified RMAN_ARCHIVE_DEST_BACKUP to RMAN_ARC_DEST_DIR because this
# gave a clearer description of how it is used.  Also, documented in
# orarman.cfg and Readme.orarman files.
#
# Revision 1.43  2009/07/08 20:08:39  jt7190
# *** empty log message ***
#
# Revision 1.42  2009/07/07 16:36:37  jt7190
# 1) Added change to allow new parameter RMAN_ARCHIVE_DEST_BACKUP to be used with
# DG installations to keep a second archivelog directory, so that it does not
# delete arcvhivelogs during a archivelog backup.
# 2) Fixed bug where sbt_tape channel was being declared during DELEXPIRE and
# DELOBSOLETE jobs where FRA was being used,  and NBU was not.  This channel
# was removed for this situation, and only a disk channel will be declared.
#
# Revision 1.41  2009/06/04 18:56:03  jt7190
# Updated orarman with return values and patrol settings for MONFRA and BKUPFRA jobs.
# Updated DbBackupMonitorSched.txt with example of template that matches the orarman_crontab.lis entries.
# Updated crontab_orarman.lis with new tags for MONFRA and BKUPFRA job entries.
# Updated Readme.ora with new Patrol documentation, and add controlfile_keep documentation.
#
# Revision 1.40  2008/11/07 16:11:48  jt7190
# Updated FRActve to FRAActive.
#
# Revision 1.39  2008/10/24 14:03:19  mr7378
# Updated to support RMAN Proxy Copy with NetBackup
#
# Revision 1.38  2008/08/27 19:01:22  jt7190
# Updated FRABkupCmds function to allow FILESPERSET and MAXOPENFILES to be passed
# in for BKUPFRA commands.
# #
#
# Revision 1.38  2008/08/27 13:39  jt7190
#  Updated FRABkupCmds function to allow FILESPERSET and MAXOPENFILES to be passed
#  in for BKUPFRA commands.
#
# Revision 1.37  2008/07/27 15:49:52  mr7378
# Modified SBTLibrary handling to not overwrite original value
#
# Revision 1.36  2008/07/21 20:01:43  mr7378
# Changed handling of SBT_LIBRARY on AIX, the script will automatically
# add the "(shr.o)" on to the end of the value, the  "(shr.o)" is not
# allowed in the configuration file.
#
# Revision 1.35  2008/05/13 18:29:55  mr7378
# Modified the Read Config File function to handle values with parentheses.
# Modified NLS_LANG setting to use RunSql function.
#
# Revision 1.34  2008/05/07 15:25:25  jt7190
# Added email to be sent with BKUPFRA option, also added the ability to
# turn off this status by setting RMAN_BKUPFRA_NOEMAIL to true.
#
# Revision 1.33  2008/04/08 16:19:26  mr7378
# Fix FilesPerSet to be integer everywhere to avoid the ksh93 issues
#
# Revision 1.32  2008/04/02 16:02:07  mr7378
# Added back updates from version 1.28 that were lost, these were to address
# problems with identifing the correct archive log destination and type.
#
# Revision 1.31  2008/03/31 19:07:04  mr7378
# Updated to add LOCAL_BASE & SIS VTierTop.  Corrected default setting
# for the PFile Backup Directory.
#
# Revision 1.30  2008/03/21 14:39:27  jt7190
#  Updated orarman with new features, BKUPFRA, MONFRA, DELEXPIRED. Modified script
#  to work with a db running FRA and NBU.  Added default retention period when
#  executing REBDB. "CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 35 DAYS"
#  Added MONFRA_update_for_bug routine, to check for Bug 4911954, and correct if
#  found CVS:
#
#
# Revision 1.27  2007/05/23 19:38:02  mr7378
# Changed default NBU Schedule name to match the current default.
#
# Revision 1.26  2007/05/17 20:43:47  mr7378
# Added rman_post_run_sql to add a SQL command after the run statement.
#
# Revision 1.25  2007/05/16 13:18:20  mr7378
# Added check before unsetting variables.
#
# Revision 1.24  2007/03/12 22:36:01  mr7378
# Added a -S skip option to skip the backup for database files
# that have been backed up in the specified amount of time, or
# for archived logs that have been created in the specified
# amount of time.
#
# Revision 1.23  2007/01/22 18:41:38  mr7378
# Changed acquire lock of archive log backup to be a warning, and
# modified behaviour to still check space threshold.
#
# Revision 1.22  2006/12/01 14:09:29  mr7378
# Run delete obsolete from command line only, config file parameters
# not recommended.
#
# Revision 1.21  2006/11/03 16:48:49  mr7378
# Modified Start and End Dates to use 4 digit year,
# added maxopenfiles to output status banner.
#
# Revision 1.20  2006/09/15 21:09:08  mr7378
# Major updates, added support for delete obsolete, maxopenfiles,
# rate, rman debug, cumulative incremental, maxsetsize, and
# backup validate.  Also renamed log files to include commands;
# dbf, arc, del, val for easier log file identification.
#
# Revision 1.19  2006/05/16 16:36:25  oracle
# Fix ArcLogDestDir logic when log_archive_dest_1 parameters are used
# Extract and print information on DBID
# Extract location of spfile, and if used, create a backup pfile from the spfile.
#
# Revision 1.18  2006/05/15 18:59:02  mr7378
# Update NBU Class to Policy, Noted new default Schedule Name.
# Added support for SBT_LIBRARY environment variable.
#
# Revision 1.17  2005/10/18 17:34:27  mr7378
# Added option for SBT_LIBRARY setting.
#
# Revision 1.16  2004/06/24 15:05:48  js8335
# Modified to support .cfg file changes for WLM.
#
# Revision 1.15  2003/12/18 21:51:53  js8335
# Add -T parameter for Patrol backup tag.
#
# Revision 1.14  2003/12/08 20:22:57  js8335
# Add calls to Patrol to signal backup start and end.
#
# Revision 1.13  2003/10/22 21:20:47  oracle
# Modified alter database open after failed offline backup,
# it will now check the status of the database before assuming
# it is not already opened.
#
# Revision 1.12  2003/08/11 16:04:46  oracle
# Added rman_blksize parameter to control rman block size.
#
# Revision 1.11  2003/08/06 15:40:53  oracle
# Added LOGGER notification, and add the log file to the email status message that is sent.
#
# Revision 1.10  2003/08/05 21:39:22  oracle
# Added ending email notification with status information.
#
# Revision 1.9  2003/08/05 19:39:34  oracle
# Added Tablespace level backups, added include of control file, set command id.
# Revision 1.8  2003/05/28 15:42:12  oracle
# Updated Lock File cleanup, only cleanup if a lock was aquired.
#
# Revision 1.7  2003/05/20 20:22:08  oracle
# Fixed user begin exit, and change lock file cleanup to happen all the time.
#
# Revision 1.6  2003/05/10 15:33:44  oracle
# Made backup type visible to the user_cmd.
#
# Revision 1.5  2003/05/08 21:54:02  oracle
# Updated NLS variable, modified how MML variables are passed in,
# added the tag command, and restart after offline failure.
#
# Revision 1.4  2002/06/29 04:11:13  oracle
# Added User Begin, Success, and Fail exits, updated process
# check.
#
# Revision 1.3  2002/02/25 20:34:30  oracle
# Modified RMAN format to include DB Name, format meets
# NetBackup recommendation of ending with %t
#
# Revision 1.2  2001/11/13 21:26:13  oracle
# Added change archivelog all validate for 8.0 databases
#
# Revision 1.1  2001/09/18 13:30:33  oracle
# Initial revision


