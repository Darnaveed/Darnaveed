$ cat /opt/app/t1enb1d4/oracle/local/bin/monitor.sh
#!/usr/bin/ksh
#----------------------------------------------------------------------------#
# Script Name : monitor.sh                                                   #
# Language    : Korn Shell (ksh)                                             #
# Description : Monitoring script for critical Oracle functions              #
# Usage       : monitor.sh $Funtion $SID $ArchiveDest                        #
#                                                                            #
#               Where:  $Function        is the function to monitor          #
#                       $SID             is the ORACLE_SID of the database   #
#                       $ArchiveDest     is the archive log destination      #
#                                                                            #
# Functions   : oracle     -  This function checks to see if the Oracle      #
#                             instance is up and available.  If not, a page  #
#                             is sent to the DBA group.                      #
#               sqlnet     -  This function checks to see if the Listener    #
#                             is up.  If not, a page is sent to the DBA      #
#                             group.                                         #
#               alert      -  This function scans the alert log for error    #
#                             messages.  Specified ORA messages can be       #
#                             excluded from reporting.  See the notes in     #
#                             the chk_alert section for details.             #
#               archmon    -  This function determines how much free space   #
#                             exists in the archive destination mount point. #
#                             If 5% or less space is available, a page is    #
#                             sent to the DBA group.                         #
#               tbsrpt     -  This function produces a tablespace            #
#                             utilization report and table/index extent      #
#                             report.  The report is informational only is   #
#                             mailed to the supporting DBA.                  #
#               sessions   -  This function stores the number of currently   #
#                             connected sessions into a database table for   #
#                             monitoring and historical reporting purposes.  #
#                             Additionally it notifies the DBA if the        #
#                             number of sessions is within 90% of the        #
#                             maximum number of allowable processes.         #
#                                                                            #
#                                                                            #
# Notes       : This script was orignally written for the PacBell Oracle     #
#               environment and named 'mon.ksh'.  This current version of    #
#               'mon.sh' has been somewhat rewritten and customized for      #
#               the SWBT Oracle environment.  We have renamed it to avoid    #
#               confusion with the original script which is still in use in  #
#               the PacBell region.                                          #
#                                                                            #
# WARNING     : This script is intended for test and development             #
#               environment only.                                            #
#                                                                            #
#                                                                            #
# Revision History:                                                          #
#                                                                            #
# Name         Date      Change Description                                  #
# -----------  --------  --------------------------------------------------- #
# J. Thorn     01/20/10  Changed 'fgrep $OraError' to  'fgrep "$OraError" '  #
#                        because an error occured when $OraError had spaces  i#
#                        in it.
# J. Thorn     03/09/09  Added code to alert function to allow               #
#                        the code to work with 11g.                          #
# B. Belaska   08/30/05  Added alert log checking for '>>>' messages.        #
# B. Belaska   05/04/05  Added alert log checking for 'SHUTDOWN' messages.   #
#                        This will report on instance shutdown failures.     #
#                        Added alert log checking for 'OS Pid' messages.     #
#                        This will indicate the setting of events.           #
# B. Belaska   07/12/04  Added the reporting of tables and indexes which     #
#                        cannot extend more than 2 times.  This new          #
#                        reporting was added to the 'tbsrpt' function.       #
# B. Belaska   03/10/04  Changed alert log checking of 'WARNING!' to         #
#                        'WARNING'.  This will now detect all warning        #
#                        messages.                                           #
# B. Belaska   02/25/04  Added alert log checking for 'Failure' and 'FULL'   #
#                        which indicates a failure to extend the undo        #
#                        rollback segment in Oracle 9i.                      #
#                        Added alert log checking for lost RPC connections.  #
# B. Belaska   11/15/02  Added the reporting of TEMP tablespace usage when   #
#                        using temp files in Oracle 8i.  Changed the report  #
#                        to show segments with more than 100 extents.        #
# B. Belaska   03/26/02  Added alert log checking for 'WARNING!' which       #
#                        indicates the presence of a fuzzy backup/restore.   #
# B. Belaska   02/21/02  Added alert log checking for new Oracle 8i log      #
#                        archiving error messages.                           #
# B. Belaska   04/19/01  Changed the 'archmon' function to use 'fdf' in      #
#                        obtaining the mount point list.  This eliminates    #
#                        the multi platform problem whereby each had         #
#                        slightly different formats.  In addition, the       #
#                        function can check multiple archive mount points.   #
# B. Belaska   03/10/99  Added the 'SESSIONS' functionality.                 #
# B. Belaska   07/22/98  Fixed a problem with the 'ALERT' function on        #
#                        handling exclusion of specified ORA messages.       #
# B. Belaska   04/23/98  Customized the script for the SWBT environment.     #
# J.Y. Chan    10/15/97  Added check for distributed transaction errors in   #
#                        the alert log                                       #
# C.J. Kunz    08/21/97  Improved documetation,                              #
#                        Improved error handling,                            #
#                        Added archive directory handling                    #
# C.J. Hansen  07/16/97  Initial version                                     #
#                                                                            #
#----------------------------------------------------------------------------#


#----------------------------------------------------------------------------#
#                                                                            #
#     Command Line Input Variables                                           #
#                                                                            #
#----------------------------------------------------------------------------#
Function=$1
OracleSid=$2
ArchiveDest=$3

#----------------------------------------------------------------------------#
#                                                                            #
#     CHECK ORACLE FUNCTION                                                  #
#                                                                            #
#       Check if the database is available by connecting to SQL*PLUS and     #
#       running a dummy query                                                #
#                                                                            #
#----------------------------------------------------------------------------#
chk_oracle()

{
echo $ORACLE_SID

sqlplus -s / <<EOF 1>${Oracle_Monitor}/chk_oracle.log
select 'PERFECT' from dual;
exit
EOF


pwd

cat $Oracle_Monitor/chk_oracle.log | grep "ORA"
    if [ $? -eq 0 ]
    then
        oranotify -n $Script -s $OracleSid -l CRITICAL -m "Oracle is down for $OracleSid" -f ${Oracle_Monitor}/chk_oracle.log
    fi
}


#----------------------------------------------------------------------------#
#                                                                            #
#                                                                            #
#     CHECK ALERT LOG FUNCTION                                               #
#                                                                            #
# This function scan the alert log and notifies the DBA if any error         #
# messages are found.  Valid error messages include ORA, OER, and any        #
# messages having 'All' in them such as 'All online logs need archiving'.    #
#                                                                            #
#                                                                            #
# Certain messages can be excluded by using an exception file.               #
#                                                                            #
# Ora_Exceptions_File:                                                       #
#   This file is a list of all Oracle error messages that you do NOT want    #
#   the script to catch and notify the ODBA. The format of the file is       #
#   a list of the exception error codes on a separate line. If you do not    #
#   want a particular ORA-00600 error message to be reported, include the    #
#   arguments of the error message following the ORA-00600.                  #
#                                                                            #
#   Example Ora_Exceptions_File file:                                        #
#   ---------------------------------------------------------------------    #
#   | ORA-555                                                           |    #
#   | ORA-0777                                                          |    #
#   | ORA-00600 [1234]                                                  |    #
#   | ORA-00600 [6789]                                                  |    #
#   ---------------------------------------------------------------------    #
#                                                                            #
#   This means that the above four error codes would not be captured by the  #
#   alert program.                                                           #
#                                                                            #
#----------------------------------------------------------------------------#
chk_alert()
{
#
# Derive the Major version of the Oracle Software
#
oracle_major_vers=`ls -1 ${ORACLE_HOME}/lib/libcommon*.* 2>/dev/null | head -1 | sed -e 's/.*libcommon//' -e 's/\..*//'`

if [ -z "${oracle_major_vers}" ]
then
        oracle_major_vers=0
fi
#
if [ ${oracle_major_vers} -gt 10 ]
then
        Alert_Log="${ORACLE_BASE}/diag/rdbms/${OracleSid}/${OracleSid}/trace/alert_${OracleSid}.log"
else
        Alert_Log="${Oracle_Admin}/bdump/alert_${OracleSid}.log"
fi
#

if [ -f $Line_File -a -s $Line_File ]
then
    From_Line=`cat $Line_File`
else
    From_Line=1
fi

if [ ! -f $Ora_Exceptions_File ]
then
    touch $Ora_Exceptions_File
fi

Cur_Lines=`wc -l $Alert_Log | awk '{print $1}'`
# If the $Cur_Lines is less than the last line the script looked at last,
# it probably means that the alert.log file has been cycled. So assume
# that the file has not been read from and set $From_Line = 1

if [ $Cur_Lines -lt $From_Line ]
then
    From_Line=1
fi
if [ $From_Line -ne $Cur_Lines ]
then

   Pct=`disk_free | grep \${ArchiveDest}| awk '{print \$5}'| sed s/%/""/g`
   if [ $OSName = "SUNOS" ]
   then

    tail +$From_Line $Alert_Log | grep '^O' | grep -v 'ORACLE' | grep -v 'ORA-00600' | awk -F": " '{print $1}' | awk -F" " '{print $1}' | sort | uniq > ${Oracle_Monitor}/alert_errors_non600.log
    tail +$From_Line $Alert_Log | grep '^All' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail +$From_Line $Alert_Log | grep '^Corrupt' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail +$From_Line $Alert_Log | grep 'Archiving' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail +$From_Line $Alert_Log | grep 'I/O error' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail +$From_Line $Alert_Log | grep '^WARNING' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail +$From_Line $Alert_Log | grep '^Failure' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail +$From_Line $Alert_Log | grep '^FULL' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail +$From_Line $Alert_Log | grep 'RPC' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail +$From_Line $Alert_Log | grep 'SHUTDOWN' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail +$From_Line $Alert_Log | grep 'OS Pid' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail +$From_Line $Alert_Log | grep 'DISTRIB' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail +$From_Line $Alert_Log | grep '^>>>' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail +$From_Line $Alert_Log| grep 'ORA-00600' | awk -F": " '{print $3}' | awk -F"," '{print $1}' | sort | uniq > ${Oracle_Monitor}/alert_errors_600.log

  else

    tail -n +$From_Line $Alert_Log | grep '^O' | grep -v 'ORACLE' | grep -v 'ORA-00600' | awk -F": " '{print $1}' | awk -F" " '{print $1}' | sort | uniq > ${Oracle_Monitor}/alert_errors_non600.log
    tail -n +$From_Line $Alert_Log | grep '^All' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail -n +$From_Line $Alert_Log | grep '^Corrupt' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail -n +$From_Line $Alert_Log | grep 'Archiving' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail -n +$From_Line $Alert_Log | grep 'I/O error' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail -n +$From_Line $Alert_Log | grep '^WARNING' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail -n +$From_Line $Alert_Log | grep '^Failure' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail -n +$From_Line $Alert_Log | grep '^FULL' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail -n +$From_Line $Alert_Log | grep 'RPC' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail -n +$From_Line $Alert_Log | grep 'SHUTDOWN' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail -n +$From_Line $Alert_Log | grep 'OS Pid' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail -n +$From_Line $Alert_Log | grep 'DISTRIB' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail -n +$From_Line $Alert_Log | grep '^>>>' | sort | uniq >> ${Oracle_Monitor}/alert_errors_non600.log
    tail -n +$From_Line $Alert_Log| grep 'ORA-00600' | awk -F": " '{print $3}' | awk -F"," '{print $1}' | sort | uniq > ${Oracle_Monitor}/alert_errors_600.log

   fi


    cat $Ora_Exceptions_File | grep ORA-00600 | awk '{print $2}' | sort | uniq > ${Oracle_Monitor}/alert_except_600.log
    cat $Ora_Exceptions_File | grep -v 'ORA-00600' | sort | uniq > ${Oracle_Monitor}/alert_except_non600.log
    cat ${Oracle_Monitor}/alert_errors_600.log ${Oracle_Monitor}/alert_errors_non600.log > ${Oracle_Monitor}/alert_errors_all.log
    cat ${Oracle_Monitor}/alert_except_600.log ${Oracle_Monitor}/alert_except_non600.log > ${Oracle_Monitor}/alert_except_all.log

    if [ -f ${Oracle_Monitor}/error_matches.log ]
    then
        rm ${Oracle_Monitor}/error_matches.log
    fi
#
# Search the exceptions file for each entry in the errors file.  Write matches
# to a matched exceptions file.
#
    while read OraError
    do
        fgrep "$OraError" ${Oracle_Monitor}/alert_except_all.log >> ${Oracle_Monitor}/error_matches.log
    done < ${Oracle_Monitor}/alert_errors_all.log

#
# Compare the line count of the errors file with the matched exceptions file.
# If there are more lines in the errors file than in the matched exceptions,
# some errors are not excluded from notification.  In this case send an alert.
#
    err_cntr=`cat ${Oracle_Monitor}/alert_errors_all.log | wc -l`
    if [ -f ${Oracle_Monitor}/error_matches.log ]
    then
        match_cntr=`cat ${Oracle_Monitor}/error_matches.log | wc -l`
    else
        match_cntr=0
    fi
    if [ err_cntr -gt match_cntr ]
    then
        echo "The following error messages were found in the Alert Log..." > ${Oracle_Monitor}/alert_messages.log
        echo " " >> ${Oracle_Monitor}/alert_messages.log
        cat ${Oracle_Monitor}/alert_errors_all.log >> ${Oracle_Monitor}/alert_messages.log
        oranotify -n $Script -s $OracleSid -l WARNING -m "Error messages in $OracleSid Alert Log" -f ${Oracle_Monitor}/alert_messages.log
    fi
    echo $Cur_Lines > $Line_File
fi
}


#----------------------------------------------------------------------------#
#                                                                            #
#     DF FUNCTION                                                            #
#                                                                            #
#       Perform a "df -k", or equivalent and format the results              #
#       consistantly across HP, IBM, SUN, and Linux.                         #
#                                                                            #
#----------------------------------------------------------------------------#
disk_free()
{
        # Determine the correct df command and options for this OS.
        OSName=$(uname -s 2>/dev/null)
        case ${OSName} in
                "HP-UX")
                        DF="/usr/bin/df -kP"
                        ;;
                "SunOS")
                        DF="/usr/bin/df -k"
                        ;;
                "AIX")
                        DF="/usr/bin/df -kP"
                        ;;
                "Linux")
                        DF="/bin/df -kP"
                        ;;
                *)
                        DF="/usr/bin/df -k"
                        ;;
        esac

        printf "%-40s %11s %11s %11s %8s %s\n" \
                "Filesystem" "Kbytes" "Used" "Available" "Capacity" "Mounted on"

        Wrapped="n"
        ${DF} ${*} 2>/dev/null | grep -iv '^filesystem' |
        while read Line
        do
                set -- ${Line}
                if (( ${#} == 1 ))
                then
                        Filesystem="${1}"
                        Wrapped="y"
                else
                        if [[ ${Wrapped} = "n" ]]
                        then
                                Filesystem="${1}"
                                shift 1
                        fi
                        Kbytes=${1}
                        Used=${2}
                        Available=${3}
                        Capacity="${4}"
                        Mounted="${5}"

                        printf "%-40s %11s %11s %11s %8s %s\n" \
                                "${Filesystem}" "${Kbytes}" "${Used}" "${Available}" "${Capacity}" "${Mounted}"
                        Wrapped="n"
                fi
        done

} # End of function: disk_free

#----------------------------------------------------------------------------#
#                                                                            #
#     CHECK SQLNET FUNCTION                                                  #
#                                                                            #
#       Check the status of the Listener                                     #
#                                                                            #
#----------------------------------------------------------------------------#
chk_sqlnet()

{
$SqlNet_Cmd > ${Oracle_Monitor}/chk_sqlnet.log

grep "The command completed successfully" ${Oracle_Monitor}/chk_sqlnet.log

if [ $? -ne 0 ]
then
    echo "SQL*NET Listener is down on $Host" > /${Oracle_Monitor}/chk_sqlnet.log
    oranotify -n $Script -s $OracleSid -l CRITICAL -m "SQL*NET is down on $Host" -f ${Oracle_Monitor}/chk_sqlnet.log
fi
}


#----------------------------------------------------------------------------#
#                                                                            #
#     TABLESPACE REPORT FUNCTION                                             #
#                                                                            #
#       Produce tablespace and extent report                                 #
#                                                                            #
#----------------------------------------------------------------------------#
tablespace_rpt()

{
sqlplus -s / <<EOF

spool ${Oracle_Monitor}/tablespace.rpt

set heading off
set feedback off
set pagesize 60
set linesize 80
set verify off
column sumb             format 99,999,999,999
column largest          format 99,999,999,999
column tablespace_name  format a20             heading 'Tablespace'
column segment_name     format a22             heading 'Segment Name'
column segment_type     format a6              heading 'Type'
column owner            format a8              heading 'Owner'
column extents          format 9999            heading 'Exts'
column max_extents      format 9999            heading 'Max|Exts'
column next_extent      format 999,999,999     heading 'Next Ext'
column bytes            format 99,999,999,999  heading 'Seg Size'
column Tot_Size         format 999,999,999,999 heading 'Total Size'
column Tot_Free         format 99,999,999,999  heading 'Total Free'
column Pct_Free         format 999             heading 'Pct|Free'
column Chunks_Free      format 9999            heading 'Free|Segs'
column Max_Free         format 99,999,999,999  heading 'Contiguous Free'

select  'Report for SID=$OracleSid generated on '|| to_char(sysdate,'DD-MON-YY HH24:MI:SS') from sys.dual
/

set heading on
ttitle center 'SPACE AVAILABLE IN TABLESPACES' skip 2

select a.tablespace_name,sum(a.tots) Tot_Size,
     sum(a.sumb) Tot_Free,
     sum(a.sumb)*100/sum(a.tots) Pct_Free,
     sum(a.largest) Max_Free,sum(a.chunks) Chunks_Free
from
     (
     select tablespace_name,0 tots,sum(bytes) sumb,
     max(bytes) largest,count(*) chunks
     from dba_free_space a
     group by tablespace_name
     union
     select tablespace_name,sum(bytes) tots,0,0,0 from
      dba_data_files
     group by tablespace_name
     union
     select tablespace_name,sum(bytes) tots,0,0,0 from
      dba_temp_files
     group by tablespace_name) a
     group by a.tablespace_name
/


ttitle center 'SEGMENTS WITH MORE THAN 100 EXTENTS'  skip 2

select owner,segment_name,segment_type,bytes,extents,
     max_extents,next_extent
     from  dba_segments
     where segment_type in ('TABLE','INDEX') and extents > 100
     order by owner,segment_name
/


set pause off
set verify off
set pagesize 60
set linesize 132
set trimout on
set trimspool on
column segment_name     format a30
column tablespace_name  format a30
column segment_type     format a5
column owner            format a12

ttitle center 'SEGMENTS WHERE THERE''S NO ROOM FOR THE NEXT EXTENT IN KB'  skip 2

select
        owner,
        segment_name,
        segment_type type,
        tablespace_name,
        next_extent/1024 next_kb,
        max_free/1024 max_free_kb
from
        dba_segments,
        (select tablespace_name tblspc, max(bytes) max_free from dba_free_space group by dba_free_space.tablespace_name) free_space
where
        dba_segments.tablespace_name = free_space.tblspc and
        segment_type in ('TABLE', 'INDEX') and
        next_extent > max_free
order by
        tablespace_name,
        owner,
        segment_name,
        segment_type
/

spool off

exit
EOF


#  Check the table extents
echo " " >> ${Oracle_Monitor}/tablespace.rpt
table_exts >> ${Oracle_Monitor}/tablespace.rpt
echo " " >> ${Oracle_Monitor}/tablespace.rpt


#  Check the index extents
echo " " >> ${Oracle_Monitor}/tablespace.rpt
index_exts >> ${Oracle_Monitor}/tablespace.rpt
echo " " >> ${Oracle_Monitor}/tablespace.rpt


#  Email the report to the DBA
oranotify -n $Script -s $OracleSid -l WARNING -m "Tablespace Report for $OracleSid" -f ${Oracle_Monitor}/tablespace.rpt

}


#
#  Show the tables which cannot extend for more than 2 extents
#

table_exts()

{
sqlplus -s / <<EOF >/tmp/table_exts_$$
set echo off
set termout off
set verify off
set serveroutput on

DECLARE
max_ext            INTEGER := 0;
count_exts         INTEGER := 0;
potential_extents  INTEGER := 0;
dtb_owner            dba_tables.owner%TYPE;
dtb_table_name       dba_tables.table_name%TYPE;
dtb_tablespace_name  dba_tables.tablespace_name%TYPE;
dtb_next_extent      dba_tables.next_extent%TYPE;

CURSOR tables_crsr IS
  select unique owner, table_name, tablespace_name, next_extent from dba_tables
    where tablespace_name not in ('SYSTEM','TOOLS','USERS','TEMP')
  order by owner, table_name;
CURSOR free_crsr (tbsp in VARCHAR2) IS
  SELECT bytes FROM dba_free_space WHERE tbsp = tablespace_name;

BEGIN
DBMS_OUTPUT.ENABLE(100000);
OPEN tables_crsr;

LOOP
  FETCH tables_crsr INTO dtb_owner, dtb_table_name, dtb_tablespace_name, dtb_next_extent;
  EXIT WHEN tables_crsr%NOTFOUND;
  OPEN free_crsr(dtb_tablespace_name);
  count_exts := 0;
  LOOP
    FETCH free_crsr INTO max_ext;
    EXIT WHEN free_crsr%NOTFOUND;

    count_exts := count_exts + trunc(max_ext/dtb_next_extent);
  END LOOP;

  IF count_exts <= 2 THEN
    DBMS_OUTPUT.PUT_LINE(rpad(dtb_owner,10,' ') || rpad(dtb_table_name,25, ' ') || rpad(dtb_tablespace_name,25,' ') || ' ' || to_char(dtb_next_extent/1024/1024,'999999') || ' MB    ' || count_exts);
  END IF;

  CLOSE free_crsr;
END LOOP;

END;
/

EOF


echo " "
echo "            TABLES WHICH CANNOT EXTEND MORE THAN 2 EXTENTS"
echo " "
echo "Owner     Table Name               Tablespace                    Next    Exts"
echo "--------  -----------------------  -------------------------     ------   ---"
lc=$(wc -l /tmp/table_exts_$$ | awk '{print $1}')
if [ $lc -gt 3 ] ;then
  sort -k 2,2 /tmp/table_exts_$$ | grep "MB"
else
  echo "All tables are able to obtain 2 or more extents"
fi
echo " "

}


#
#  Show the indexes which cannot extend for more than 2 extents
#

index_exts()

{
sqlplus -s / <<-EOF >/tmp/index_exts_$$
set echo off;
set termout off;
set verify off;
set serveroutput on;

DECLARE
max_ext            INTEGER := 0;
count_exts         INTEGER := 0;
potential_extents  INTEGER := 0;
dtb_owner            dba_indexes.owner%TYPE;
dtb_index_name       dba_indexes.index_name%TYPE;
dtb_tablespace_name  dba_indexes.tablespace_name%TYPE;
dtb_next_extent      dba_indexes.next_extent%TYPE;

CURSOR indexes_crsr IS
  select unique owner, index_name, tablespace_name, next_extent from dba_indexes
    where tablespace_name not in ('SYSTEM','TOOLS','USERS','TEMP')
  order by owner, index_name;
CURSOR free_crsr (tbsp in VARCHAR2) IS
  SELECT bytes FROM dba_free_space WHERE tbsp = tablespace_name;

BEGIN
DBMS_OUTPUT.ENABLE(100000);
OPEN indexes_crsr;

LOOP
  FETCH indexes_crsr INTO dtb_owner, dtb_index_name, dtb_tablespace_name, dtb_next_extent;
  EXIT WHEN indexes_crsr%NOTFOUND;
  OPEN free_crsr(dtb_tablespace_name);
  count_exts := 0;
  LOOP
    FETCH free_crsr INTO max_ext;
    EXIT WHEN free_crsr%NOTFOUND;

    count_exts := count_exts + trunc(max_ext/dtb_next_extent);
  END LOOP;

  IF count_exts <= 2 THEN
    DBMS_OUTPUT.PUT_LINE(rpad(dtb_owner,10,' ') || rpad(dtb_index_name,25, ' ') || rpad(dtb_tablespace_name,25,' ') || ' ' || to_char(dtb_next_extent/1024/1024,'999999') || ' MB    ' || count_exts);
  END IF;

  CLOSE free_crsr;
END LOOP;

END;
/

EOF

echo " "
echo "            INDEXES WHICH CANNOT EXTEND MORE THAN 2 EXTENTS"
echo " "
echo "Owner     Index Name               Tablespace                    Next    Exts"
echo "--------  -----------------------  -------------------------     ------   ---"
lc=$(wc -l /tmp/index_exts_$$ | awk '{print $1}')
if [ $lc -gt 3 ] ;then
  sort -k 2,2 /tmp/index_exts_$$ | grep "MB"
else
  echo "All indexes are able to obtain 2 or more extents"
fi
echo " "

}


#----------------------------------------------------------------------------#
#                                                                            #
#     CHECK ARCHMON FUNCTION                                                 #
#                                                                            #
#       This function monitors the free space in the archive log             #
#       destination.  If the available space becomes 5% or less, then a      #
#       page is sent to the DBA.                                             #
#                                                                            #
#                                                                            #
#----------------------------------------------------------------------------#
chk_archmon()
{

# Determine the space utilization of the Archive directory
Pct=`disk_free | grep \${ArchiveDest}| awk '{print \$5}'| sed s/%/""/g`

if [ $Pct -ge 95 ]
then
    echo "Archive Log Dest for $OracleSid is more than ${Pct}% full!" > ${Oracle_Monitor}/archmon.log
    oranotify -n $Script -s $OracleSid -l CRITICAL -m "Full Archive Log Dest for $OracleSid" -f ${Oracle_Monitor}/archmon.log
fi
}


#----------------------------------------------------------------------------#
#                                                                            #
#     CHECK SESSIONS FUNCTION                                                #
#                                                                            #
#       This function monitors the number of connected sessions and stores   #
#       the information in a historical table for later querying.            #
#       In addition, it compares the number of connected sessions to the     #
#       'processes' init.ora parameter.  If the number of sessions is within #
#       90% of the maximum process limit, a notification is sent to the DBA. #
#                                                                            #
#       Note: prior to using this functionality a session monitor table      #
#             must be created in the OPS$ORACLE schema.  The DDL follows:    #
#                                                                            #
#                                                                            #
#               CREATE TABLE session_monitor_tbl                             #
#                 (                                                          #
#                   sample_date             date,                            #
#                   active_session_cnt      number,                          #
#                   inactive_session_cnt    number                           #
#                 )                                                          #
#                 TABLESPACE users                                           #
#                 STORAGE (                                                  #
#                           initial      256k                                #
#                           next         256k                                #
#                           maxextents   100                                 #
#                           pctincrease    0                                 #
#                         );                                                 #
#                                                                            #
#                                                                            #
#----------------------------------------------------------------------------#
chk_sessions()

{
sqlplus -s / <<EOF

set verify off
set heading off
set feedback off
set pagesize 0

variable rc              number
variable max_processes   number
variable nbr_sessions    number


DECLARE
    active_session_cnt     number;
    inactive_session_cnt   number;

BEGIN

-- Insert current session counts into the SESSION_MONITOR_TBL

    select count(*)
        into active_session_cnt
    from v\$session
        where status = 'ACTIVE';

    select count(*)
        into inactive_session_cnt
    from v\$session
        where status = 'INACTIVE';

    insert into session_monitor_tbl
        values (sysdate, active_session_cnt, inactive_session_cnt);
    commit;


-- Clean up the table by keep a rolling 7 days worth of history

    delete from session_monitor_tbl
        where sample_date < (sysdate - 7);
    commit;


-- Set a return code to 1 if the number of current sessions is within
-- 90% of the maximum number of allowable processes

    select to_number(value) into :max_processes
        from v\$parameter
    where name = 'processes';

    :nbr_sessions := active_session_cnt + inactive_session_cnt;

    if :nbr_sessions >= (:max_processes * .9)
    then
        :rc := 1;
    else
        :rc := 0;
    end if;

END;
/


-- Spool the return code to a Unix file

spool ${Oracle_Monitor}/sessions_rc.log

print rc;

spool off


exit
EOF


# Notify the DBA if total number of current sessions is within 90% of the
# maximum number of allowable processes

grep "0" ${Oracle_Monitor}/sessions_rc.log

if [ $? -ne 0 ]
then
    echo "Current sessions for $OracleSid are within 90% of maximum processes!" > ${Oracle_Monitor}/sessions.msg
    oranotify -n $Script -s $OracleSid -l WARNING -m "Current sessions near limit"  -f ${Oracle_Monitor}/sessions.msg
fi
}


#----------------------------------------------------------------------------#
#                                                                            #
#     MAIN BODY                                                              #
#                                                                            #
# To add custom functions, place them at the end after archmon.              #
#                                                                            #
#----------------------------------------------------------------------------#
#----------------------------------------------------------------------------#
#                                                                            #
#     Customizable Variables                                                 #
#                                                                            #
#       Ora_Monitor = set to location of where script output files are to be #
#                     written                                                #
#       Ora_Exceptions_File = set to location of the ORA error exclusion     #
#                             file                                           #
#       Alert_Log = set to location of the alert log                         #
#       Line_File = identifies the line to start from in the alert log. This #
#                   variable is managed by the script.                       #
#       SqlNet_Cmd = set value to "lsnrctl status" for SQL*NET V2            #
#                    set value to "tcpctl status" for SQL*NET V1             #
#                                                                            #
#----------------------------------------------------------------------------#
OSName=`uname -s | tr '[:lower:]' '[:upper:]'`
case ${OSName} in
        "HP-UX")
                ID="/usr/bin/id -un"
                SHELL="/usr/bin/ksh"
                ;;
        "SUNOS")
                ID="/usr/xpg4/bin/id -un"
                SHELL="/usr/bin/ksh"
                ;;
        "AIX")
                ID="/usr/bin/id -un"
                SHELL="/usr/bin/ksh"
                ;;
        "LINUX")
                ID="/usr/bin/id -un"
                SHELL="/bin/bash --posix"
                ;;
        *)
                ${ECHO} "ERROR: ${ScriptName}: This Operating System is Not Supported: ${OSName}" >&2
                exit 1
                ;;
esac

# Current host name
LocalHost=$(uname -n)

# Current users name
UserName=$(${ID})

if [[ -d /opt/app/${UserName} ]]
then
        export LOCAL_BASE=/opt/app/${UserName}/oracle/local
elif [[ -d /pac/${UserName}/app ]]
then
        export LOCAL_BASE=/pac/${UserName}/app/oracle/local
else
        export LOCAL_BASE=${HOME}/local
fi

#
# For Oracle 11g, ORACLE_BASE needs to be set
if [[ -d /opt/app/${UserName} ]]
then
        export ORACLE_BASE=/opt/app/${UserName}/oracle
elif [[ -d /pac/${UserName}/app ]]
then
        export ORACLE_BASE=/pac/${UserName}/app/oracle
else
        export ORACLE_BASE=${HOME}
fi

# Script Defaults
if [[ -d ${LOCAL_BASE}/etc ]]
then
        ConfigDir=${LOCAL_BASE}/etc
else
        ConfigDir=/var/opt/oracle
fi
#
#----------------------------------------------------------------------------#
#                                                                            #
#     Customizable Variables                                                 #
#                                                                            #
#       Ora_Monitor = set to location of where script output files are to be #
#                     written                                                #
#       Ora_Exceptions_File = set to location of the ORA error exclusion     #
#                             file                                           #
#       Alert_Log = set to location of the alert log                         #
#       Line_File = identifies the line to start from in the alert log. This #
#                   variable is managed by the script.                       #
#       SqlNet_Cmd = set value to "lsnrctl status" for SQL*NET V2            #
#                    set value to "tcpctl status" for SQL*NET V1             #
#                                                                            #
#----------------------------------------------------------------------------#
#
Oracle_Admin=${ORACLE_BASE}/admin/$OracleSid
Oracle_Monitor=${Oracle_Admin}/monitor
Ora_Exceptions_File="${Oracle_Monitor}/alert_exceptions.lst"
Line_File="${Oracle_Monitor}/alert_linefile"
SqlNet_Cmd="lsnrctl status"
Host="`uname -n`"
Script="monitor.sh"
PATH=/usr/bin:/bin:/usr/local/bin:$HOME:${LOCAL_BASE}/bin;  export PATH

#  Add the Oracle bin directory to the path
if [ -f ${LOCAL_BASE}/bin/oraprof ]
then
        . ${LOCAL_BASE}/bin/oraprof $OracleSid
else
        ORAENV_ASK=NO
        ORACLE_SID=${OracleSid}
        . oraenv
fi

case $Function in
    "oracle")
        chk_oracle
        break;;
    "sqlnet")
        chk_sqlnet
        break;;
    "alert")
        chk_alert
        break;;
    "archmon")
        chk_archmon
        break;;
    "tbsrpt")
        tablespace_rpt
        break;;
    "sessions")
        chk_sessions
        break;;
esac

exit 0
#----------------------------------------------------------------------------#
#                                                                            #
# Revision History:                                                          #
# $Log$
# Revision 1.12  2010/01/20 17:47:16  jt7190
# Fixed bug with fgrep command and the variable $OraError.
#
# Revision 1.11  2009/07/29 22:44:43  mr7378
# Updated the df calls to use a new fuction disk_free
#
# Revision 1.10  2009/04/01 17:29:28  cm5933
# fix typo on osname = aix
#
# Revision 1.9  2009/03/30 18:56:57  jt7190
# Added Warning Note describing dev and test usage only.
#
# Revision 1.8  2009/03/20 17:41:30  jt7190
# 1) Update to fix Solaris "tail" command in alert function.
# 2) Update the archmon function to determine what OS prior to issuing a command.
# 3) Include Bob Belaska updates outside of CVS.
# 4) Updated alert function to work with Oracle 11g.
#
# Revision 1.7  2008/03/31 16:10:06  cm5933
# fix path statement, also add -n option to tail + command
#
# Revision 1.6  2008/03/27 02:15:43  cm5933
# Makes changes for ORACLE_BASE/LOCAL_BASE split to support SIS environments
#
# Revision 1.5  2005/12/12 16:13:09  js8335
# Increased size of tablespace name column.
#
# Revision 1.4  2005/03/29 14:19:01  js8335
# Quote variable to prevent errors caused by embeded spaces.
#
# Revision 1.3  2004/08/18 15:15:59  js8335
# Add the required break statements to the case construct.
# Eliminate the messages from fgrep going to stdout.
#
# Revision 1.2  2004/07/12 20:01:17  js8335
# Corrected the setting of the path to the ~/admin directory to support WLM.
#
# Revision 1.1  2004/06/14 19:46:23  js8335
# Initial revision
#----------------------------------------------------------------------------#
t1enb1d4@bltd122(572) t1enb1d41 /opt/app/t1enb1d4/oracle/local/bin
