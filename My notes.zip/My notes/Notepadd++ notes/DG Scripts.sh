$ cat /opt/app/t1enb1d4/oracle/local/bin/oradgmonitor
#! /bin/ksh
# $Id$
# set -x
#-----------------------------------------------------------------------------
# Project Name  : Oracle Utilities
# Script Name   : oradgmonitor
# Language      : Korn Shell (ksh)
# Purpose       : Script to control the management and functionality of an
#                 Oracle Physical Standby Database using Managed Recovery.
#
# Usage         : oradgmonitor -s OracleSid [-C ConfigDir] [-D] [-V] [-P]
#
#                Where:
#                  -s OracleSid     Oracle System Identifier
#
#                  -C ConfigDir     is an alternate configuration directory
#                                   to look for configuration files in.
#                                   Defaults: 1: /opt/app/VTIER/oracle/local/etc
#                                             2: /var/opt/oracle
#                  -I               Get status of standby
#                  -D               Turn on Debug mode for script
#                  -V               Turn on Verbose mode for the script
#                  -P               Patrol Notification Only
#
# Configuration: Valid files include only the following, no other files are
#                read by this script.
#
#                  CONFIG_DIR/global.cfg
#                  CONFIG_DIR/global.cfg
#                  CONFIG_DIR/owner_${LOGNAME}.cfg         -or- CONFIG_DIR/global_${LOGNAME}.cfg
#                  CONFIG_DIR/instance_${ORACLE_SID}.cfg   -or- CONFIG_DIR/${ORACLE_SID}.cfg
# Parameters:
#               REDO_TOLERANCE          = Acceptable tolerance between
#                                         the primary and standby database.
#               REDO_TOLERANCE_CRITICAL = Acceptable log difference between
#                                         the primary and standby database before a
#                                         critical message is sent. Default=10.
#
#-----------------------------------------------------------------------------
set +u

# Set default PATH
export PATH=/usr/bin:/bin

# Set default file permissions.
umask 022

# Script Name
ScriptName=$(basename ${0})

# Determine the OS Name
OSName=`uname -s | tr '[:lower:]' '[:upper:]'`
case ${OSName} in
        "HP-UX")
                /usr/bin/ps -xe > /dev/null 2>&1
                if [ ${?} -eq 0 ]
                then
                        PS="/usr/bin/ps -x"
                else
                        PS="/usr/bin/ps"
                fi
                ID="/usr/bin/id -un"
                SHELL="/usr/bin/ksh"
                ;;
        "SUNOS")
                PS="/usr/bin/ps"
                ID="/usr/xpg4/bin/id -un"
                SHELL="/usr/bin/ksh"
                ;;
        "AIX")
                PS="/usr/bin/ps"
                ID="/usr/bin/id -un"
                SHELL="/usr/bin/ksh"
                ;;
        "LINUX")
                PS="/bin/ps -w"
                ID="/usr/bin/id -un"
                SHELL="/bin/bash --posix"
                ;;
        *)
                ${ECHO} "ERROR: ${ScriptName}: This Operating System is Not Supported: ${OSName}" >&2
                exit 1
                ;;
esac

# Current host name
HostName=$(uname -n)

# Current users name
UserName=$(${ID})

# Home Directory for the current user, HOME not set correctly if "su UID -c" from root
UserHome=`${SHELL} -c "eval echo \~${UserName}"`

# Start Date and time stamps
DateTime=$(date +"%m%d%y_%H%M%S")

# Current Process ID
Pid=${$}

# Define Boolean True
True="1"

# Define Boolean False
False="0"

if [[ -n ${DEBUG} ]]
then
        Debug=${True}
        DebugOpt="-D"
        set -xv
else
        Debug=${False}
        DebugOpt=""
fi

if [[ -n ${VERBOSE} ]]
then
        Verbose=${True}
        VerboseOpt="-V"
else
        Verbose=${False}
        VerboseOpt=""
fi

if [[ -n ${PATROL_NOTIFY} ]]
then
        Ptrlnotify=${True}
        Ptrlnotify_Opt="-P"
else
        Ptrlnotify=${False}
        Ptrlnotify_Opt=""
fi

# vTier Setup
if [[ -d /opt/app/${UserName}/oracle/local/etc ]]
then
        VTierTop=/opt/app
elif [[ -d /pac ]]
then
        VTierTop=/pac
fi

# Script Defaults
if [[ -n ${VTierTop} ]] && [[ -d ${VTierTop}/${UserName} ]]
then
        export LOCAL_BASE=${VTierTop}/${UserName}/oracle/local
        ConfigDir=${LOCAL_BASE}/etc
        LocalAdmin=${UserHome}/oracle/admin
else
        export LOCAL_BASE=${UserHome}/local
        ConfigDir=/var/opt/oracle
        LocalAdmin=${UserHome}/admin
fi

LocalBin=${LOCAL_BASE}/bin
LockDir=${LOCAL_BASE}/locks
LogDir=${LOCAL_BASE}/log
TmpDir=${LOCAL_BASE}/tmp

NotifyCmd="oranotify"

# Pass this option on to other scripts, so that they inherit same features
ConfigDirOpt="-C ${ConfigDir}"

# Failures by default have a severity of Critical
FailureSeverity="CRITICAL"

# Critcal Redo Tolerance will default to 5.
Critical_Tolerance=5

#-----------------------------------------------------------------------------
# Function   : ReportMsg
# Description: Handle all the reporting/logging of messages and errors
#              based on a severity level assigned to it.
#----------------------------------------------------------------------------
function ReportMsg
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ReportMsg ${*}" >&2

        typeset MsgSev MsgText MsgFile MsgFileOpt

        Service=${ORACLE_SID-unknown}

        # Message Severity
        MsgSev="${1}"

        # Message Text
        MsgText="${2}"

        # Message File
        MsgFile="${3}"
        if [[ -f ${MsgFile} ]]
        then
                MsgFileOpt="-f ${MsgFile}"
        fi

        if [[ -n ${MsgSev} ]]
        then

            if [[ ${Ptrlnotify} != ${True} ]]
            then
                print "${MsgSev}: ${ScriptName}: ${Service}: ${MsgText}" >&2
                if [[ -x ${LocalBin}/${NotifyCmd} ]]
                then

                        ${LocalBin}/${NotifyCmd} -s ${Service} -l ${MsgSev} -n ${ScriptName} \
                               -m "${MsgText}" ${MsgFileOpt} ${ConfigDirOpt} ${DebugOpt} ${VerboseOpt}
                fi
            else
               if [[ -f ${TmpFile1} ]]
               then
                 egrep '(ORA-|ERROR:)' ${TmpFile1}
                 print "${ScriptName}: ${MsgSev} ${MsgText}" >&2
               fi
            fi
        else
          print "${ScriptName}: ${MsgText}" >&2
        fi

        if [[ -n ${MsgSev} && -f ${LogFile} ]]
        then
                print "${MsgSev}: ${ScriptName}: ${Service}: ${MsgText}" >> ${LogFile}
        elif [[ -f ${LogFile} ]]
        then
                print "${ScriptName}: ${Service}: ${MsgText}" >> ${LogFile}
        fi

        return

} # End of ReportMsg



#-----------------------------------------------------------------------------
# Name: ShowUsage
# Desc: Print usage syntax.
#-----------------------------------------------------------------------------
function ShowUsage
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ShowUsage ${*}" >&2

        print "\nUSAGE: ${ScriptName} -s OracleSid [-C ConfigDir] [-D] [-V]" >&2
        print "\n   Where:" >&2
        print "      -s OracleSid     Name of the Oracle System Identifier" >&2
        print " " >&2
        print "      -C ConfigDir       Alternate configuration file directory, default = /var/opt/oracle" >&2
        print "      -D                 Turn on Debug mode for script" >&2
        print "      -V                 Turn on Verbose mode for the script" >&2
        print "\n" >&2

        return

} # End of ShowUsage



#-----------------------------------------------------------------------------
# Function   : CleanupAndExit
# Description: Handles the cleanup of temp files.
#----------------------------------------------------------------------------
function CleanupAndExit
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: CleanupAndExit ${*}" >&2

        typeset ExitStatus=${1}

        # Clean Exit, Remove any temporary files, if not in debug mode
        if [[ ${Debug} = ${False} ]]
        then
                rm -f ${TrcFile} 2>/dev/null
                rm -f ${TmpFile1} 2>/dev/null
                rm -f ${TmpFile2} 2>/dev/null
        fi

        exit

} # End of CleanupAndExit



#-----------------------------------------------------------------------------
# Function   : ReadConfigFile
# Description: Read in the configuration file.  Configuration file is in the
#              format of:
#                 parameter [=] value
#              where parameter must begin in column 1 and start with an alpha
#              character.  The parameter is case insensitve and the equal
#              sign is optional.  The value can contain defined environment
#              variables, such as $ORACLE_SID which is defined by the script
#              itself before the configuration file is read.  For Example:
#                 TNS_ADMIN = /var/opt/oracle
#-----------------------------------------------------------------------------
function ReadConfigFile
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ReadConfigFile ${*}" >&2

        typeset ConfigFile=${1}
        typeset Parameter
        typeset Value

        while read Line
        do
                Line=$(echo ${Line} | grep -i ^[a-z] | sed -e 's/=/ /')
                if [[ -z ${Line} ]]
                then
                        continue
                fi

                set -- ${Line}
                Parameter=$(echo ${1} | tr '[:lower:]' '[:upper:]')
                shift 1
                Value="${*}"

                case ${Parameter} in
                        REDO_TOLERANCE)
                                Tolerance="$(eval echo ${Value})"
                                ;;
                        REDO_TOLERANCE_CRITICAL)
                                Critical_Tolerance="$(eval echo ${Value})"
                                ;;
                        LOCAL_BIN)
                                LocalBin="$(eval echo ${Value})"
                                export PATH=${PATH}:${LocalBin}
                                ;;
                        LOG_DIR)
                                LogDir="$(eval echo ${Value})"
                                ;;
                        *)
                                continue
                                ;;
                esac

        done < ${ConfigFile}

        return 0

} # End of ReadConfigFile



#-----------------------------------------------------------------------------
# Function   : RunSql
# Description: Run a SQL Command and leave output in the temp file, for the
#              calling routine to get, and set SqlError, if an error was
#              detected.
#-----------------------------------------------------------------------------
function RunSql
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: RunSql ${*}" >&2

        typeset SqlError
        typeset SqlCommand="${*}"
        SqlConnect="/ as sysdba"

        ${ORACLE_HOME}/bin/sqlplus -silent /nolog <<-EOF > ${TmpFile1} 2>&1
                SET SQLPROMPT "SQL> ";
                CONNECT ${SqlConnect};
                SET HEADING OFF
                SET FEEDBACK OFF
                ${SqlCommand}
                EXIT;
        EOF

        ExitStatus=${?}
        if (( ${ExitStatus} == 0 ))
        then
                egrep '(ORA-|ERROR:)' ${TmpFile1} > /dev/null 2>&1
                ExitStatus=${?}
                if (( ${ExitStatus} == 0 ))
                then
                        SqlError=1
                else
                        SqlError=0
                fi
        else
                SqlError=1
        fi

        # Append the tempfile to the scripts trace file
        # if the command returned an error.
        if [[ ${SqlError} -eq 1 ]]
        then
                print "\nFrom Function: RunSql" >> ${TrcFile} 2>&1
                print "${SqlCommand}\n" >> ${TrcFile} 2>&1
                cat ${TmpFile1} >> ${TrcFile} 2>&1
        fi

        return ${SqlError}

} # End of RunSql


#----------------------------------------------------------------------------
# Name: CheckTolerance
# Desc: Get the last archivelog sequence# from the primary and standby database
#       and compute the difference and compare it to the tolerance.
#----------------------------------------------------------------------------
function CheckTolerance
{

        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: CheckTolerance ${*}" >&2

        LastSequence=""
        TmpLastSequence=""
        RunSql "SELECT ARCHIVED_SEQ#, APPLIED_SEQ# FROM V\$ARCHIVE_DEST_STATUS;"
        ExitStatus=${?}
        if (( ${ExitStatus} != 0 ))
        then
                ReportMsg "WARNING" "Database Not Responding to Query."
                return ${ExitStatus}
                CleanupAndExit 1
        fi

        primary_sequence=$(tail -1 ${TmpFile1} | awk '{print $1}')
        standby_sequence=$(tail -1 ${TmpFile1} | awk '{print $2}')

        let sequence_difference=${primary_sequence}-${standby_sequence}

        Today=`date +%m/%d/%y--%H:%M:%S`
        echo "${Today} primary=${primary_sequence} standby=${standby_sequence} Diff=${sequence_difference}" \
         >> ${ToleranceLogFile}

        if [ "${sequence_difference}" -gt "${Critical_Tolerance}" ]
        then
                ReportMsg "CRITICAL" "The primary and standby databases are out of tolerance. Difference = ${sequence_difference}"
        elif [ "${sequence_difference}" -gt "${Tolerance}" ]
        then
                ReportMsg "WARNING" "The primary and standby databases are out of tolerance. Difference = ${sequence_difference}"
        fi

        TmpLastSequence=$(tail -1 ${ToleranceLogFile} | awk '{print $2, $3, $4, $5}')
        LastSequence="$LastSequence $TmpLastSequence"
        # LastSequence="$LastSequence -- $TmpLastSequence"

        return

} # End of CheckTolerance



#----------------------------------------------------------------------------
# Name: GetStandbyStatus
# Desc: Get status of standby instance
#----------------------------------------------------------------------------
function GetStandbyStatus
{

        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: GetStandbyStatus ${*}" >&2

        RunSql "SELECT 'DATA#' dum1, status from V\$INSTANCE;
                SELECT 'DATA:'|| open_mode || ':'||DATABASE_ROLE FROM V\$DATABASE;"

        ExitStatus=${?}
        if (( ${ExitStatus} != 0 ))
        then
                ReportMsg "${FailureSeverity}" "Standby Database Not Responding to Query. Database could be down or possibly a username/passwd issue."
                return ${ExitStatus}
                CleanupAndExit 1
        fi

        DBStatus=$(grep "^DATA#" ${TmpFile1})
        DBMode=$(grep "^DATA:" ${TmpFile1})

        printf "oradgmonitor: ${DBStatus}\n"
        printf "oradgmonitor: ${DBMode}\n"

        return

} # GetStandbyStatus


#-----------------------------------------------------------------------------
# Parse options and arguments from command line.
#-----------------------------------------------------------------------------
typeset OptCount=0
while getopts :s:C:IDVP OPT
do
        (( OptCount = OptCount + 1 ))
        case ${OPT} in

                s)      # Oracle System Identifier
                        OracleSid=${OPTARG}
                        ;;
                C)      # Change Default Configuration Directory
                        ConfigDir=${OPTARG}
                        ConfigDirOpt="-C ${ConfigDir}"
                        ;;
                I)      # Status of standby
                        StndbyStatus=${True}
                        ;;
                D)      # Turn Shell Debug mode on
                        set -xv
                        Debug=${True}
                        DebugOpt="-D"
                        ;;
                V)      # Turn Verbose mode on
                        Verbose=${True}
                        VerboseOpt="-V"
                        ;;
                P)      # Turn Patrol notification on
                        Ptrlnotify=${True}
                        Ptrlnotify_Opt="-P"
                        ;;
                :)      # Missing Argument
                        ReportMsg "WARNING" "Argument missing for option: ${OPTARG}"
                        ShowUsage
                        CleanupAndExit 1
                        ;;
                \?)     # Invalid Option
                        ReportMsg "WARNING" "Invalid option: ${OPTARG}"
                        ShowUsage
                        CleanupAndExit 1
                        ;;
        esac
done

# Shift the options off the command line, leaving any remaining arguments.
shift $((${OPTIND} - 1))

# No other options should remain, if they do report a usage error
if (( ${#} > 0 ))
then
        ReportMsg "WARNING" "Invalid arguments on the command line!"
        ShowUsage
        CleanupAndExit 1
fi

if (( ${OptCount} == 0 ))
then
        ReportMsg "" "Missing one or more required options!"
        ShowUsage
        CleanupAndExit 1
fi


#-----------------------------------------------------------------------------
# Verify remaining options and arguments specifed are correct.
#-----------------------------------------------------------------------------
if [[ -z ${OracleSid} ]]
then
        ReportMsg "" "ORACLE_SID option is required!"
        ShowUsage
        CleanupAndExit 1
else
        ORACLE_SID=${OracleSid}
        # Export it for user exit scripts
        export ORACLE_SID
fi

if [[ -f ${LocalBin}/oraprof ]]
then
        . ${LocalBin}/oraprof ${ORACLE_SID}
        if (( ${oraenv_rc} != 0 ))
        then
                ReportMsg "${FailureSeverity}" "Environment setup script failed: ${LocalBin}/oraprof ${ORACLE_SID}"
                CleanupAndExit 1
        fi
else
        ReportMsg "${FailureSeverity}" "Environment setup script not found: ${LocalBin}/oraprof"
        CleanupAndExit 1
fi

#---------------------------------------------------------------------
# Read in the configuraton files
#---------------------------------------------------------------------
#---------------------------------------------------------------------
# Check for System Global configuration file first.
if [[ -r ${ConfigDir}/global.cfg ]]
then
        ReadConfigFile ${ConfigDir}/global.cfg
fi

# If we have a Instance configuration file read it and let its values
# override the ones from the Global and Owner configuration files
if [[ -r ${ConfigDir}/instance_${ORACLE_SID}.cfg ]]
then
        ReadConfigFile ${ConfigDir}/instance_${ORACLE_SID}.cfg
fi

# Log Directory and File
if [[ ! -d ${LogDir} || ! -w ${LogDir} ]]
then
        mkdir -p ${LogDir}
        rc=${?}
        if (( ${rc} != 0 )) || [[ ! -w ${LogDir} ]]
        then
                LogDir=/tmp
        fi
fi

LogFile=${LogDir}/${ScriptName}_${ORACLE_SID}_${DateTime}.log

if [[ ${Command} = "status" ]]
then
        rm -f ${LogFile}
fi

# Trace File
TrcFile=${LogDir}/${ScriptName}_${ORACLE_SID}_${DateTime}.trc
if [[ ${Verbose} = ${True} ]]
then
        print "TrcFile: ${TrcFile}"
fi

# Temporary Directory and Files
if [[ ! -d ${TmpDir} || ! -w ${TmpDir} ]]
then
        mkdir -p ${TmpDir}
        rc=${?}
        if (( ${rc} != 0 )) || [[ ! -w ${TmpDir} ]]
        then
                TmpDir=/tmp
        fi
fi

TmpFile1=${TmpDir}/${ScriptName}_${ORACLE_SID}_${DateTime}_1.tmp
if [[ ${Verbose} = ${True} ]]
then
        print "TmpFile1: ${TmpFile1}"
fi

TmpFile2=${TmpDir}/${ScriptName}_${ORACLE_SID}_${DateTime}_2.tmp
if [[ ${Verbose} = ${True} ]]
then
        print "TmpFile2: ${TmpFile2}"
fi

# Define the LogFile Directory
if [[ ! -d ${LocalAdmin}/${ORACLE_SID}/monitor ]]
then
        mkdir -p ${LocalAdmin}/${ORACLE_SID}/monitor
fi

#-----------------------------------------------------------------------------
# Cycle the Tolerance logfile so it doesn't grow unchecked.
#-----------------------------------------------------------------------------
ToleranceLogFile=${LocalAdmin}/${ORACLE_SID}/monitor/${ScriptName}.log

LoglinesMax=${LoglinesMax-1024}

if [[ -f ${ToleranceLogFile} ]]
then
        Lines=$(wc -l ${ToleranceLogFile} | awk '{print $1}')
        if (( ${Lines} > ${LoglinesMax} ))
        then
                mv ${ToleranceLogFile} ${ToleranceLogFile}.old
        fi
fi

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
# Main Script Logic
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
ExitStatus=0
ReturnCode=0
SqlError=0

if [[ ${StndbyStatus} = ${True} ]]
then
        GetStandbyStatus
else
        RunSql "SELECT DATABASE_ROLE from V\$DATABASE;"
        grep "PRIMARY" ${TmpFile1} >/dev/null
        ExitStatus=${?}
        if (( ${ExitStatus} == 1 ))
        then
                CheckTolerance
                ReportMsg "" "Tolerance Allowed : ${Tolerance}"
                ReportMsg "" "Critical Tolerance: ${Critical_Tolerance}"
                ReportMsg "" "Redo Tolerance    : ${LastSequence}"
        fi
fi

CleanupAndExit ${ExitStatus}
#
#-----------------------------------------------------------------------------
# Revision History:
#
# $Log$
# Revision 1.8  2011/03/10 21:34:07  jt7190
#
# 1) Modified oradgdelarcs to delete archivelogs with a single statement.
# 2) Added additional check for vtier env to /opt/app/<username>/oracle/local/etc.
#
# Revision 1.7  2010/08/13 13:02:37  jt7190
# Added files oradgdelarcs and crontab_oradg.lis to package. updated
# oradgmonitor to remove connect to Primary from Standby to process this
# check on archivelogs.
#
# Revision 1.6  2010/07/14 13:30:15  jt7190
# Remove "Error:" string from parameter passed to orastatus
#
# Revision 1.5  2010/07/09 19:27:46  jt7190
# Removed a : from a parameter that was being passed into oranotify.
#
# Revision 1.4  2010/06/02 16:40:31  jt7190
# adding history comments.
#

# Revision 1.1  2010/05/01 13:30:33  oracle
# Initial revision - taken from original code from Steve Merz.

you have mail in /var/spool/mail/t1enb1d4
t1enb1d4@bltd122(575) t1enb1d41 /opt/app/t1enb1d4/oracle/local/bin
$










$ cat /opt/app/t1enb1d4/oracle/local/bin/oradgchkreco
#! /bin/ksh
# $Id$
#-----------------------------------------------------------------------------
# Project Name : Oracle Utilites
# Script Name  : oradgchkreco
# Description  : This is a wrapper script used primarily for standby database
#                managed recovery that simply checks to see if the managed recovery
#                process (mrpX) is running.
#
# Usage        : oradgchkreco ORACLE_SID command
#
# Example: 00 * * * * $HOME/local/bin/oradgchkreco SID $HOME/local/bin/oradgmanagedreco -s SID -c start
#
#-----------------------------------------------------------------------------
#Initial revision
#
#-----------------------------------------------------------------------------
set +u
PATH=/bin:/usr/bin export PATH

# Determine the some commands based on the Platform
OSName=$(uname -s | tr '[:lower:]' '[:upper:]')
case ${OSName} in
        "HP-UX")
                ID="/usr/bin/id -un"
                SHELL="/usr/bin/ksh"
                ;;
        "SUNOS")
                ID="/usr/xpg4/bin/id -un"
                SHELL="/usr/bin/ksh"
                ;;
        "AIX")
                ID="/usr/bin/id -un"
                SHELL="/usr/bin/ksh"
                ;;
        "LINUX")
                ID="/usr/bin/id -un"
                SHELL="/bin/bash --posix"
                ;;
        *)
                ${ECHO} "ERROR: ${ScriptName}: This Operating System is Not Supported: ${OSName}" >&2
                exit 1
                ;;
esac


# Script Name
ScriptName=$(basename ${0})

# Current host name
HostName=$(uname -n)

# Current users name
UserName=$(${ID})

# Current users Home Directory
UserHome=$(eval echo ~${UserName})

# vTier Setup
if [[ -d /opt/app/${UserName}/oracle/local/etc ]]
then
        VTierTop=/opt/app
elif [[ -d /pac/${UserName} ]]
then
        VTierTop=/pac
fi

# Script Defaults
if [[ -n ${VTierTop} ]] && [[ -d ${VTierTop}/${UserName} ]]
then
        export LOCAL_BASE=${VTierTop}/${UserName}/oracle/local
        ConfigDir=${LOCAL_BASE}/etc
else
        export LOCAL_BASE=${UserHome}/local
        ConfigDir=/var/opt/oracle
fi

LocalBin=${LOCAL_BASE}/bin
LockDir=${LOCAL_BASE}/locks
LogDir=${LOCAL_BASE}/log
TmpDir=${LOCAL_BASE}/tmp

NotifyCmd="oranotify"

# Pass this option on to other scripts, so that they inherit same features
ConfigDirOpt="-C ${ConfigDir}"

# Failures by default have a severity of Critical
FailureSeverity="CRITICAL Error:"


if [ ${#} -lt 2 ]
then
 echo "USAGE: ${ScriptName} ORACLE_SID Command" >&2
 exit 1
fi
OraSid=${1}
shift 1
Command=${*}

#
# Added oraprof call to set up env variables and confirm that oratab existed in the correct place.
# Needed to add oraprof, because it looks in standard locations, vtier locations and pac locations
# for oratab.
#
#
if [[ -f ${LocalBin}/oraprof ]]
then
        . ${LocalBin}/oraprof ${OraSid}
        if (( ${oraenv_rc} != 0 ))
        then
         ${ECHO} "${ScriptName}: Environment setup script failed: ${LocalBin}/oraprof ${OraSid}"
                exit 0
        fi
else
        ${ECHO} "${ScriptName}: Environment setup script not found:  ${LocalBin}/oraprof ${OraSid}"
        exit 0;
fi
#
# Commentted out old code for finding oratabl
#
#if [ -r /opt/app/${LOGNAME}/oracle/local/etc/oratab ]
#then
#        ORATAB=/opt/app/${LOGNAME}/oracle/local/etc/oratab
#else
#        ORATAB=${ConfigDir}/oratab
#        ${ECHO} "${ScriptName}: Oracle Not Installed or Not Configured, \"oratab\" file not found!" >&2
#        exit 0
#fi
#
#export ORACLE_SID=$(grep -i "^${OraSid}:" ${ORATAB} | cut -d: -f1)
#
#echo $ORACLE_SID
#if [ -z "${ORACLE_SID}" ]
#then
# echo "ERROR: ${ScriptName}: ORACLE_SID: ${OraSid} Not Found!" >&2
# exit 1
#fi

ProcCount=0
Procs=`ps -fe | cut -c1-132 | sed -e 's/ *$//' | grep -v grep | egrep "ora_mrp._${OraSid}"'$'`

for Proc in mrp
do
 echo ${Procs} | grep "ora_${Proc}._${OraSid}" >/dev/null 2>&1
 Result=${?}
 if [ ${Result} -eq 0 ]
 then
  let ProcCount=${ProcCount}+1
 fi
done

if [[ ${ProcCount} -eq 1 ]]
then
 ExitStatus=0
else
 eval ${Command}
 ExitStatus=${?}
fi

exit ${ExitStatus}
#
#-----------------------------------------------------------------------------
# Revision History:
#
# $Log$
# Revision 1.2  2011/03/10 21:34:07  jt7190
#
# 1) Modified oradgdelarcs to delete archivelogs with a single statement.
# 2) Added additional check for vtier env to /opt/app/<username>/oracle/local/etc.
#
# Revision 1.1  2010/06/10 12:36:02  jt7190
# Renamed orachkdgreco to oradgchkreco for naming consistency.
#
# Revision 1.3  2010/06/02 20:48:35  jt7190
# Added fixes with oraprof call.
#
# Revision 1.2  2010/06/02 16:40:31  jt7190
# adding history comments.
#

t1enb1d4@bltd122(578) t1enb1d41 /opt/app/t1enb1d4/oracle/local/bin









$ cat /opt/app/t1enb1d4/oracle/local/bin/oradgdelarcs
#!/bin/ksh
# $Id$
# Oradgdelarcs Release Date: 09/01/15
# set -x
#-----------------------------------------------------------------------------
# Project Name : Oracle Utilities
# Script Name   : oradgdelarcs
# Language      : Korn Shell (ksh)
# Purpose       : Script to control the management and functionality of an
#     Oracle Physical Standby Database using Managed Recovery.
#
# Usage         : oradgdelarcs -s OracleSid [-C ConfigDir] [-K <keep hours>] [-D] [-V] [-P]
#
#                Where:
#                  -s OracleSid     Oracle System Identifier
#
#                  -C ConfigDir     is an alternate configuration directory
#                                   to look for configuration files in.
#                                   Defaults: 1: /opt/app/VTIER/oracle/local/etc
#                                             2: /var/opt/oracle
#                  -I               Get status of standby
#     -K      Keep x hours of archivelog after applied to Standby DB
#                  -D               Turn on Debug mode for script
#                  -V               Turn on Verbose mode for the script
#                  -P      Patrol Notification Only
#
# Configuration: Valid files include only the following, no other files are
#                read by this script.
#
#                  CONFIG_DIR/global.cfg
#                  CONFIG_DIR/owner_${LOGNAME}.cfg         -or- CONFIG_DIR/global_${LOGNAME}.cfg
#                  CONFIG_DIR/instance_${ORACLE_SID}.cfg   -or- CONFIG_DIR/${ORACLE_SID}.cfg
# Parameters:
#               REDO_TOLERANCE          = Acceptable tolerance between
#                                         the primary and standby database.
#               REDO_TOLERANCE_CRITICAL = Acceptable log difference between
#                                         the primary and standby database before a
#                                         critical message is sent. Default=10.
#
#-----------------------------------------------------------------------------
set +u

# Set default PATH
export PATH=/usr/bin:/bin

# Set default file permissions.
umask 022

# Script Name
ScriptName=$(basename ${0})

# Determine the OS Name
OSName=`uname -s | tr '[:lower:]' '[:upper:]'`
case ${OSName} in
        "HP-UX")
         PS="env UNIX95=1 /usr/bin/ps -x -o user=LONGUSERNAME -o pid,ppid,cpu,stime,tty,time,args"
         ID="/usr/bin/id -un"
                SHELL="/usr/bin/ksh"
  AWK="/usr/bin/awk"
                ;;
        "SUNOS")
  PS="/usr/bin/ps -o user=LONGUSERNAME -o pid,ppid,pcpu,stime,tty,time,args"
                ID="/usr/xpg4/bin/id -un"
                SHELL="/usr/bin/ksh"
   AWK="/usr/bin/nawk"
                ;;

        "AIX")
  PS="/usr/bin/ps -o user=LONGUSERNAME -o pid,ppid,pcpu,start,tty,time,args"
                ID="/usr/bin/id -un"
                SHELL="/usr/bin/ksh"
  AWK="/usr/bin/awk"
                ;;
        "LINUX")
   PS="/bin/ps -w o user=LONGUSERNAME -o pid,ppid,pcpu,start,tty,time,args"
                ID="/usr/bin/id -un"
                SHELL="/bin/bash --posix"
   AWK="/bin/awk"
                ;;
        *)
                ${ECHO} "ERROR: ${ScriptName}: This Operating System is Not Supported: ${OSName}" >&2
                exit 1
                ;;
esac

# Current host name
HostName=$(uname -n)

# Current users name
UserName=$(${ID})

# Home Directory for the current user, HOME not set correctly if "su UID -c" from root
UserHome=`${SHELL} -c "eval echo \~${UserName}"`

# Start Date and time stamps
DateTime=$(date +"%m%d%y_%H%M%S")

# Current Process ID
Pid=${$}

# Define Boolean True
True="1"

# Define Boolean False
False="0"

if [[ -n ${DEBUG} ]]
then
        Debug=${True}
        DebugOpt="-D"
        set -xv
else
        Debug=${False}
        DebugOpt=""
fi

if [[ -n ${VERBOSE} ]]
then
        Verbose=${True}
        VerboseOpt="-V"
else
        Verbose=${False}
        VerboseOpt=""
fi

if [[ -n ${PATROL_NOTIFY} ]]
then
        Ptrlnotify=${True}
        Ptrlnotify_Opt="-P"
else
        Ptrlnotify=${False}
        Ptrlnotify_Opt=""
fi

# vTier Setup
if [[ -d /opt/app/${UserName}/oracle/local/etc ]]
then
        VTierTop=/opt/app
elif [[ -d /pac ]]
then
        VTierTop=/pac
fi

# Script Defaults
if [[ -n ${VTierTop} ]] && [[ -d ${VTierTop}/${UserName} ]]
then
        export LOCAL_BASE=${VTierTop}/${UserName}/oracle/local
        ConfigDir=${LOCAL_BASE}/etc
 LocalAdmin=${UserHome}/oracle/admin
else
        export LOCAL_BASE=${UserHome}/local
        ConfigDir=/var/opt/oracle
 LocalAdmin=${UserHome}/admin
fi

LocalBin=${LOCAL_BASE}/bin
LockDir=${LOCAL_BASE}/locks
LogDir=${LOCAL_BASE}/log
TmpDir=${LOCAL_BASE}/tmp

NotifyCmd="oranotify"

# Pass this option on to other scripts, so that they inherit same features
ConfigDirOpt="-C ${ConfigDir}"

# Failures by default have a severity of Critical
FailureSeverity="CRITICAL"

# Critcal Redo Tolerance will default to 5.
Critical_Tolerance=5

#-----------------------------------------------------------------------------
# Function   : ReportMsg
# Description: Handle all the reporting/logging of messages and errors
#              based on a severity level assigned to it.
#----------------------------------------------------------------------------
function ReportMsg
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ReportMsg ${*}" >&2

        typeset MsgSev MsgText MsgFile MsgFileOpt

        Service=${ORACLE_SID-unknown}

        # Message Severity
        MsgSev="${1}"

        # Message Text
        MsgText="${2}"

        # Message File
        MsgFile="${3}"
        if [[ -f ${MsgFile} ]]
        then
                MsgFileOpt="-f ${MsgFile}"
        fi

        if [[ -n ${MsgSev} ]]
        then

            if [[ ${Ptrlnotify} != ${True} ]]
            then
                print "${MsgSev}: ${ScriptName}: ${Service}: ${MsgText}" >&2
                if [[ -x ${LocalBin}/${NotifyCmd} ]]
                then

                        ${LocalBin}/${NotifyCmd} -s ${Service} -l ${MsgSev} -n ${ScriptName} \
                               -m "${MsgText}" ${MsgFileOpt} ${ConfigDirOpt} ${DebugOpt} ${VerboseOpt}
                fi
            else
               if [[ -f ${TmpFile1} ]]
               then
                 egrep '(ORA-|ERROR:)' ${TmpFile1}
                 print "${ScriptName}: ${MsgSev} ${MsgText}" >&2
               fi
            fi
        else
          print "${ScriptName}: ${MsgText}" >&2
        fi

        if [[ -n ${MsgSev} && -f ${LogFile} ]]
        then
                print "${MsgSev}: ${ScriptName}: ${Service}: ${MsgText}" >> ${LogFile}
        elif [[ -f ${LogFile} ]]
        then
                print "${ScriptName}: ${Service}: ${MsgText}" >> ${LogFile}
        fi

        return

} # End of ReportMsg



#-----------------------------------------------------------------------------
# Name: ShowUsage
# Desc: Print usage syntax.
#-----------------------------------------------------------------------------
function ShowUsage
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ShowUsage ${*}" >&2

        print "\nUSAGE: ${ScriptName} -s OracleSid [-C ConfigDir] [-D] [-V]" >&2
        print "\n   Where:" >&2
        print "      -s OracleSid     Name of the Oracle System Identifier" >&2
        print " " >&2
        print "      -C ConfigDir      Alternate configuration file directory, default = /var/opt/oracle" >&2
        print "      -K <hours>  Keep archivelogs X hours in the FRA" >&2
        print "      -D                Turn on Debug mode for script" >&2
        print "      -V                Turn on Verbose mode for the script" >&2
        print "\n" >&2

        return

} # End of ShowUsage



#-----------------------------------------------------------------------------
# Function   : CleanupAndExit
# Description: Handles the cleanup of temp files.
#----------------------------------------------------------------------------
function CleanupAndExit
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: CleanupAndExit ${*}" >&2

        typeset ExitStatus=${1}

        # Clean Exit, Remove any temporary files, if not in debug mode
        if [[ ${Debug} = ${False} ]]
        then
         rm -f ${TrcFile} 2>/dev/null
                rm -f ${TmpFile1} 2>/dev/null
                rm -f ${TmpFile2} 2>/dev/null
        fi

        rm -f ${CmdFile} 2>/dev/null

        if [[ ${CleanupLock} = ${True} ]]
        then
                rm -f ${LockFile}
        fi

        exit ${ExitStatus}

} # End of CleanupAndExit



#-----------------------------------------------------------------------------
# Function   : ReadConfigFile
# Description: Read in the configuration file.  Configuration file is in the
#              format of:
#                 parameter [=] value
#              where parameter must begin in column 1 and start with an alpha
#              character.  The parameter is case insensitve and the equal
#              sign is optional.  The value can contain defined environment
#              variables, such as $ORACLE_SID which is defined by the script
#              itself before the configuration file is read.  For Example:
#                 TNS_ADMIN = /var/opt/oracle
#-----------------------------------------------------------------------------
function ReadConfigFile
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: ReadConfigFile ${*}" >&2

        typeset ConfigFile=${1}
        typeset Parameter
        typeset Value

        while read Line
        do
                Line=$(echo ${Line} | grep -i ^[a-z] | sed -e 's/=/ /')
                if [[ -z ${Line} ]]
                then
                        continue
                fi

                set -- ${Line}
                Parameter=$(echo ${1} | tr '[:lower:]' '[:upper:]')
                shift 1
                Value="${*}"

                case ${Parameter} in
                       LOCAL_BIN)
                                LocalBin="$(eval echo ${Value})"
                                export PATH=${PATH}:${LocalBin}
                                ;;
                       LOG_DIR)
                                LogDir="$(eval echo ${Value})"
                                ;;
                       RMAN_CAT_ACTIVE)
                                Value="$(echo ${Value} | tr '[:lower:]' '[:upper:]')"
     if [[ "${Value}" = "YES" || "${Value}" = "TRUE" || "${Value}" = "ON" || "${Value}" = "${True}" ]]
 then
                                        CatActive=${True}
                                else
                                        CatActive=${False}
                                fi
                                ;;
                        RMAN_CAT_ALIAS)
                                CatAlias=${Value}
                                ;;
                        RMAN_CAT_SCHEMA)
                                CatSchema=${Value}
                                ;;
                        RMAN_CAT_PASSWORD)
                                CatPassword=${Value}
                                ;;
                        *)
                                continue
                                ;;
                esac

        done < ${ConfigFile}
        return 0

} # End of ReadConfigFile



#-----------------------------------------------------------------------------
# Function   : RunSql
# Description: Run a SQL Command and leave output in the temp file, for the
#              calling routine to get, and set SqlError, if an error was
#              detected.
#-----------------------------------------------------------------------------
function RunSql
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: RunSql ${*}" >&2

 typeset SqlError
 typeset SqlCommand="${*}"
 SqlConnect="/ as sysdba"

 ${ORACLE_HOME}/bin/sqlplus -silent /nolog <<-EOF > ${TmpFile1} 2>&1
  SET SQLPROMPT "SQL> ";
  CONNECT ${SqlConnect};
  SET HEADING OFF
  SET FEEDBACK OFF
  ${SqlCommand}
  EXIT;
 EOF

 ExitStatus=${?}
 if (( ${ExitStatus} == 0 ))
        then
                egrep '(ORA-|ERROR:)' ${TmpFile1} > /dev/null 2>&1
                ExitStatus=${?}
                if (( ${ExitStatus} == 0 ))
                then
                        SqlError=1
                else
                        SqlError=0
                fi
        else
                SqlError=1
        fi

        # Append the tempfile to the scripts trace file
        # if the command returned an error.
 if [[ ${SqlError} -eq 1 ]]
 then
         print "\nFrom Function: RunSql" >> ${TrcFile} 2>&1
         print "${SqlCommand}\n" >> ${TrcFile} 2>&1
         cat ${TmpFile1} >> ${TrcFile} 2>&1
 fi

        return ${SqlError}

} # End of RunSql


#----------------------------------------------------------------------------
# Name: GetArcsToDelete
# Desc: Create a RMAN scripts that identifies all archivelogs that have been
#       applied and are available to be deleted.
#----------------------------------------------------------------------------
function GetArcsToDelete
{

        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: GetArcsToDelete ${*}" >&2
        LastSequence=""
        TmpLastSequence=""
#
# if KeepAlliedLogsHrs is set then we need to be more restricve and delete specific to the current incarnation. If not
# then we will delete ALL archivelogs that have been applied.
#
        if (( $KeepAppliedLogsHrs > 0 ))
 then
  RunSql "select 'delete noprompt archivelog sequence between '||min(v.sequence#)||' and '||max(v.sequence#)||' thread '||thread#||';' from v\$archived_log v, v\$database_incarnation vi where v.applied='YES' and v.deleted='NO' and v.next_time < sysdate - $KeepAppliedLogsHrs/24 and v.resetlogs_id = vi.resetlogs_id and vi.status='CURRENT'group by v.thread#, v.applied, v.deleted;"
 else
  RunSql "select 'delete noprompt archivelog sequence between '||min(sequence#)||' and '||max(sequence#)||' thread '||thread#||';' from v\$archived_log where applied='YES' and deleted='NO' group by thread#, applied, deleted;"
 fi

        ExitStatus=${?}
        if (( ${ExitStatus} != 0 ))
        then
                ReportMsg "ERROR" "Database Not Responding to Query."
                return ${ExitStatus}
                CleanupAndExit 1
        fi
        return

} # End of GetArcsToDelete


#-----------------------------------------------------------------------------
# Function   : GenCmdFile
# Description: Create the RMAN Command File to execute.
#-----------------------------------------------------------------------------
function GenCmdFile
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: GenCmdFile ${*}" >&2

        typeset -u Command=${1}
        typeset ReturnCode=0

        CmdFile=${TmpDir}/${ScriptName}_${ORACLE_SID}_${DateTime}_${Pid}.cmd

        print "${ORACLE_HOME}/bin/rman cmdfile ${CmdFile}" >> ${LogFile} 2>&1
        print "\n# CMDFILE BEGIN:" >> ${LogFile} 2>&1

        print "connect target;" > ${CmdFile} 2>&1

        if [[ ${CatActive} = ${True} ]]
        then
                if [[ ${Release} = 8.0.* ]]
                then
                        print "connect rcvcat ${CatSchema}/${CatPassword}@${CatAlias};" >> ${CmdFile} 2>&1
                else
                        print "connect catalog ${CatSchema}/${CatPassword}@${CatAlias};" >> ${CmdFile} 2>&1
                fi
        fi
  cat ${TmpFile1} >> ${CmdFile} 2>&1

 if [[ ${Verbose} = ${True} ]]
        then
                print "Function: GenCmdFile ${Command}, Return Code: ${ReturnCode}"
        fi

        return ${ReturnCode}

}


#-----------------------------------------------------------------------------
# Function   : RunCmdFile
# Description: Run RMAN with that generated Command File, and check for
#              errors
#-----------------------------------------------------------------------------
function RunCmdFile
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: RunCmdFile ${*}" >&2

        typeset -u Command=${1}

        if [[ ${Debug} = ${True} ]]
        then
                # Dump the current environment if in debug mode, helpful for debuging
                print "\n\nOutput of env:" >> ${TrcFile} 2>&1
                env | sort >> ${TrcFile} 2>&1
                print "\n\nOutput of set:" >> ${TrcFile} 2>&1
                set | sort >> ${TrcFile} 2>&1
        fi

        StartDate=$(date +'%m/%d/%Y')
        StartTime=$(date +'%H:%M:%S')

        ${ORACLE_HOME}/bin/rman cmdfile ${CmdFile} >> ${LogFile} 2>&1
        ReturnCode=${?}

        EndDate=$(date +'%m/%d/%Y')
        EndTime=$(date +'%H:%M:%S')

        if [[ -f ${LogFile} && ${Verbose} = ${True} ]]
        then
                cat ${LogFile}
        fi

        printf "%-8.8s %-10.10s %-4.4s %-10.10s %-8.8s %-10.10s %-8.8s %-8.8s\n" \
                "Sid" "Cmd" "RC" "StrtDt" "StrtTm" "EndDt" "EndTm" "Seconds" >> ${LogFile} 2>&1

        printf "%-8.8s %-10.10s %4.4s %-10.10s %-8.8s %-10.10s %-8.8s %8.8s\n" \
                "${ORACLE_SID}" "${Command}" "${ReturnCode}" "${StartDate}" "${StartTime}" \
                "${EndDate}" "${EndTime}" "${SECONDS}" >> ${LogFile} 2>&1

        if [[ ${Verbose} = ${True} ]]
        then
                print "Function: RunCmdFile ${Command}, Return Code: ${ReturnCode}"
        fi

        return ${ReturnCode}

} # End of RunCmdFile


#-----------------------------------------------------------------------------
# Function   : AcquireLock
# Description: Use a lock file to make sure on only one of these is running
#              at one time.  Store the process id in the lock file so that
#              we can handle stale locks from a crash.
#----------------------------------------------------------------------------
function AcquireLock
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && print "\nFunction: AcquireLock ${*}" >&2

        typeset -u Command=${1}
        typeset StaleLock
        typeset LockPid
        typeset RunPid
        typeset ReturnCode

        # Setup the Lock Directory
        if [[ ! -d ${LockDir} ]]
        then
                mkdir -p ${LockDir} 2>/dev/null
        fi
        if [[ ! -w ${LockDir} ]]
        then
                LockDir=/tmp
        fi

        LockFile=${LockDir}/${ScriptName}_${ORACLE_SID}_${Command}.lck

        if [[ ${Verbose} = ${True} ]]
        then
                print "Lock File: ${LockFile}" >&2
        fi



        if [[ ! -f ${LockFile} ]]
        then
                # Try to acquire the lock
                print "${Pid}" > ${LockFile}
                ReturnCode=${?}
                if (( ${ReturnCode} != 0 ))
                then
                        ReportMsg "" "Unable to create a lock file: ${LockFile}"
                        return 1
                fi
                for i in 1 2 3
                do
                        LockPid=$(cat ${LockFile} 2>/dev/null)
                        if [[ ${Pid} != ${LockPid} ]]
                        then
                                ReportMsg "" "Unable to Acquire a lock to start"
                                return 1
                        fi
                        sleep 1
                done
        else
                # Check to see if the lock is valid or stale
                StaleLock=${False}
                for i in 1 2 3
                do
                        if [[ -n ${RunPid} ]]
                        then
                                unset RunPid
                        fi
                        LockPid=$(cat ${LockFile} 2>/dev/null)
                        if [[ -n ${LockPid} ]]
                        then
                                RunPid=$(${PS} -p ${LockPid} | grep ${LockPid} | ${AWK} '{print $2}')
                        fi
                        if [[ ${RunPid} != ${LockPid} ]]
                        then
                                StaleLock=${True}
                        else
                                StaleLock=${False}
                                break
                        fi
                        sleep 1
                done



                if [[ ${StaleLock} = ${False} ]]
                then
                        ReportMsg "" "Process already running"
                        return 1
                else
                        ReportMsg "WARNING" "Lock appears to be stale, removing it"
                        rm -f ${LockFile}

                        # Try to acquire the lock
                        print "${Pid}" > ${LockFile}
                        ReturnCode=${?}
                        if (( ${ReturnCode} != 0 ))
                        then
                                ReportMsg "" "Unable to create a Lock file: ${LockFile}"
                                return 1
                        fi
                        for i in 1 2 3
                        do
                                LockPid=$(cat ${LockFile} 2>/dev/null)
                                if [[ ${Pid} != ${LockPid} ]]
                                then
                                        ReportMsg "" "Unable to acquire a lock to start"
                                        return 1
                                fi
                                sleep 1
                        done
                fi
        fi

        CleanupLock=${True}
        return 0

} # End of AcquireLock


#-----------------------------------------------------------------------------
# Parse options and arguments from command line.
#-----------------------------------------------------------------------------

CleanupLock=${False}

typeset OptCount=0
KeepAppliedLogsHrs=0
while getopts :s:C:K:IDVP OPT
do
 (( OptCount = OptCount + 1 ))
 case ${OPT} in

  s) # Oracle System Identifier
   OracleSid=${OPTARG}
   ;;
                C)      # Change Default Configuration Directory
                        ConfigDir=${OPTARG}
                        ConfigDirOpt="-C ${ConfigDir}"
                        ;;
                I)      # Status of standby
                        StndbyStatus=${True}
                        ;;
                K)      # Turn Shell Debug mode on
                        KeepAppliedLogsHrs=${OPTARG}
                        ;;
                D)      # Turn Shell Debug mode on
                        set -xv
                        Debug=${True}
                        DebugOpt="-D"
                        ;;
                V)      # Turn Verbose mode on
                        Verbose=${True}
                        VerboseOpt="-V"
                        ;;
                P)      # Turn Patrol notification on
                        Ptrlnotify=${True}
                        Ptrlnotify_Opt="-P"
                        ;;
  :) # Missing Argument
   ReportMsg "WARNING" "Argument missing for option: ${OPTARG}"
   ShowUsage
   CleanupAndExit 1
   ;;
  \?) # Invalid Option
   ReportMsg "WARNING" "Invalid option: ${OPTARG}"
   ShowUsage
   CleanupAndExit 1
   ;;
 esac
done

# Shift the options off the command line, leaving any remaining arguments.
shift $((${OPTIND} - 1))

# No other options should remain, if they do report a usage error
if (( ${#} > 0 ))
then
 ReportMsg "WARNING" "Invalid arguments on the command line!"
 ShowUsage
 CleanupAndExit 1
fi

if (( ${OptCount} == 0 ))
then
 ReportMsg "" "Missing one or more required options!"
 ShowUsage
 CleanupAndExit 1
fi


#-----------------------------------------------------------------------------
# Verify remaining options and arguments specifed are correct.
#-----------------------------------------------------------------------------
if [[ -z ${OracleSid} ]]
then
        ReportMsg "" "ORACLE_SID option is required!"
        ShowUsage
        CleanupAndExit 1
else
        ORACLE_SID=${OracleSid}
        # Export it for user exit scripts
        export ORACLE_SID
fi

if [[ -f ${LocalBin}/oraprof ]]
then
        . ${LocalBin}/oraprof ${ORACLE_SID}
        if (( ${oraenv_rc} != 0 ))
        then
                ReportMsg "${FailureSeverity}" "Environment setup script failed: ${LocalBin}/oraprof ${ORACLE_SID}"
                CleanupAndExit 1
        fi
else
        ReportMsg "${FailureSeverity}" "Environment setup script not found: ${LocalBin}/oraprof"
        CleanupAndExit 1
fi

#---------------------------------------------------------------------
# Read in the configuraton files
#---------------------------------------------------------------------
#---------------------------------------------------------------------
# Check for System Global configuration file first.
if [[ -r ${ConfigDir}/global.cfg ]]
then
        ReadConfigFile ${ConfigDir}/global.cfg
fi

# If we have a Instance configuration file read it and let its values
# override the ones from the Global and Owner configuration files
if [[ -r ${ConfigDir}/instance_${ORACLE_SID}.cfg ]]
then
        ReadConfigFile ${ConfigDir}/instance_${ORACLE_SID}.cfg
fi

# Log Directory and File
if [[ ! -d ${LogDir} || ! -w ${LogDir} ]]
then
        mkdir -p ${LogDir}
        rc=${?}
        if (( ${rc} != 0 )) || [[ ! -w ${LogDir} ]]
        then
                LogDir=/tmp
        fi
fi

LogFile=${LogDir}/${ScriptName}_${ORACLE_SID}_${DateTime}.log

if [[ ${Command} = "status" ]]
then
 rm -f ${LogFile}
fi

# Trace File
TrcFile=${LogDir}/${ScriptName}_${ORACLE_SID}_${DateTime}.trc
if [[ ${Verbose} = ${True} ]]
then
        print "TrcFile: ${TrcFile}"
fi

# Temporary Directory and Files
if [[ ! -d ${TmpDir} || ! -w ${TmpDir} ]]
then
        mkdir -p ${TmpDir}
        rc=${?}
        if (( ${rc} != 0 )) || [[ ! -w ${TmpDir} ]]
        then
                TmpDir=/tmp
        fi
fi

TmpFile1=${TmpDir}/${ScriptName}_${ORACLE_SID}_${DateTime}_1.tmp
if [[ ${Verbose} = ${True} ]]
then
        print "TmpFile1: ${TmpFile1}"
fi

TmpFile2=${TmpDir}/${ScriptName}_${ORACLE_SID}_${DateTime}_2.tmp
if [[ ${Verbose} = ${True} ]]
then
        print "TmpFile2: ${TmpFile2}"
fi

# Define the LogFile Directory
if [[ ! -d ${LocalAdmin}/${ORACLE_SID}/monitor ]]
then
 mkdir -p ${LocalAdmin}/${ORACLE_SID}/monitor
fi

#-----------------------------------------------------------------------------
# Cycle the Tolerance logfile so it doesn't grow unchecked.
#-----------------------------------------------------------------------------
ToleranceLogFile=${LocalAdmin}/${ORACLE_SID}/monitor/${ScriptName}.log

LoglinesMax=${LoglinesMax-1024}

if [[ -f ${ToleranceLogFile} ]]
then
        Lines=$(wc -l ${ToleranceLogFile} | awk '{print $1}')
        if (( ${Lines} > ${LoglinesMax} ))
        then
                mv ${ToleranceLogFile} ${ToleranceLogFile}.old
        fi
fi

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
# Main Script Logic
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
ExitStatus=0
ReturnCode=0
SqlError=0



# Acquire a Lock to make sure we are not already running.

Command='oradgdelarcs'
AcquireLock ${Command}
ExitCode=${?}
if (( ${ExitCode} != 0 ))
then
 ReportMsg "${FailureSeverity}" "Unable to acquire a lock to start ${Command}"
 CleanupAndExit ${ExitCode}
fi


RunSql "SELECT DATABASE_ROLE from V\$DATABASE;"
grep "PRIMARY" ${TmpFile1} >/dev/null
ExitStatus=${?}
if (( ${ExitStatus} == 1 ))
then
 GetArcsToDelete
 GenCmdFile
 RunCmdFile
else
        echo "This is a primary database, exiting"
fi

CleanupAndExit ${ExitStatus}
#
#-----------------------------------------------------------------------------
# Revision History:
#
# $Log$
# Revision 1.5  2015/06/16 18:43:14  jt7190
# Added lock function to not allow the oradgdelarcs job to run while another
# oradgdelarcs job is running.
#
# Revision 1.4  2013/04/12 18:41:36  jt7190
# Added new feature -K flag to keep archivelogs for x hours.  Defaults to 0.
#
# Revision 1.3  2011/03/10 21:34:07  jt7190
#
# 1) Modified oradgdelarcs to delete archivelogs with a single statement.
# 2) Added additional check for vtier env to /opt/app/<username>/oracle/local/etc.
#
# Revision 1.2  2010/08/16 17:27:55  jt7190
# added "Select distinct" to v$archived_log select.
#
# Revision 1.1  2010/08/13 13:02:37  jt7190
# Added files oradgdelarcs and crontab_oradg.lis to package. updated
# oradgmonitor to remove connect to Primary from Standby to process this
# check on archivelogs.
#
# Revision 1.0  2010/07/14 13:30:15  jt7190
# Initial revision
t1enb1d4@bltd122(579) t1enb1d41 /opt/app/t1enb1d4/oracle/local/bin









$ cat /opt/app/t1enb1d4/oracle/local/bin/oradgmanagedreco
#! /bin/ksh
# $Id$
#-----------------------------------------------------------------------------
# Project Name : Oracle Utilities
# Script Name   : oradgmanagedreco
# Language      : Korn Shell (ksh)
# Purpose       : Script to control the management and functionality of an
#     Oracle Physical Standby Database using Managed Recovery.
#
# Usage         : oradgmanagedreco -s OracleSid -c Command [-C ConfigDir] [-D] [-V]
#
#                Where:
#                  -s OracleSid     Oracle System Identifier
#                  -c Command       Command to perform: (Command/Options are case insensitive)
#                                   START      = Start Managed Recovery
#                                   STOP       = Stop Managed Recovery
#                                   STARTADG   = Starts database in Active Data Guard mode
#                                   READONLY   = Stops Managed Recovery and places the
#       standby Database in READ ONLY mode.
#                                   STATUS     = Status of the standby database.
#
#                  -C ConfigDir     is an alternate configuration directory
#                                   to look for configuration files in.
#                                   Defaults: 1: /opt/app/VTIER/oracle/local/etc
#                                             2: /var/opt/oracle
#                  -D               Turn on Debug mode for script
#                  -V               Turn on Verbose mode for the script
#
# Configuration: Valid files include only the following, no other files are
#                read by this script.
#
#                  CONFIG_DIR/global.cfg
#                  CONFIG_DIR/owner_${LOGNAME}.cfg         -or- CONFIG_DIR/global_${LOGNAME}.cfg
#                  CONFIG_DIR/instance_${ORACLE_SID}.cfg   -or- CONFIG_DIR/${ORACLE_SID}.cfg
#
#-----------------------------------------------------------------------------
set +u

# Default PATH
export PATH=/usr/bin:/bin

# Define Boolean True
True="1"

# Define Boolean False
False="0"

if [[ -n ${DEBUG} ]]
then
        set -xv
        Debug=${True}
        DebugOpt="-D"
else
        Debug=${False}
        DebugOpt=""
fi

# Oracle requires umask setting of 022.
umask 022

# Script Name
ScriptName=$(basename ${0})

# Get the echo command that handles backslash escaped characters
if [[ -z "$(echo -e)" ]]
then
        ECHO="echo -e"
else
        ECHO="echo"
fi

# Determine the OS Name
OSName=`uname -s | tr '[:lower:]' '[:upper:]'`
case ${OSName} in
        "HP-UX")
                /usr/bin/ps -xe > /dev/null 2>&1
                if [ ${?} -eq 0 ]
                then
                        PS="/usr/bin/ps -x"
                else
                        PS="/usr/bin/ps"
                fi
                ID="/usr/bin/id -un"
                SHELL="/usr/bin/ksh"
                ;;
        "SUNOS")
                PS="/usr/bin/ps"
                ID="/usr/xpg4/bin/id -un"
                SHELL="/usr/bin/ksh"
                ;;
        "AIX")
                PS="/usr/bin/ps"
                ID="/usr/bin/id -un"
                SHELL="/usr/bin/ksh"
                export AIXTHREAD_SCOPE="S"
                ;;
        "LINUX")
                PS="/bin/ps -w"
                ID="/usr/bin/id -un"
                SHELL="/bin/bash --posix"
                ;;
        *)
                ${ECHO} "ERROR: ${ScriptName}: This Operating System is Not Supported: ${OSName}" >&2
                exit 1
                ;;
esac

# Current host name
HostName=$(uname -n)

# Current users name
UserName=$(${ID})

# Home Directory for the current user, HOME not set correctly if "su UID -c" from root
UserHome=`${SHELL} -c "eval echo \~${UserName}"`

# Support for vTiers
if [ -d "/opt/app/${UserName}/oracle/local/etc" ]
then
        LocalBase=/opt/app/${UserName}/oracle/local
        ConfigDir=${LocalBase}/etc
elif [ -d "/pac/${UserName}/oracle/local/etc" ]
then
        LocalBase=/pac/${UserName}/oracle/local
        ConfigDir=${LocalBase}/etc
elif [ -d "/pac/${UserName}/app/oracle/local/etc" ]
then
        LocalBase=/pac/${UserName}/app/oracle/local
        ConfigDir=${LocalBase}/etc
else
        LocalBase=${UserHome}/local
        ConfigDir=/var/opt/oracle
fi

# Scripts Process Id
Pid=${$}

# Date Time stamp
LongTS=$(date +"%y%m%d_%H%M%S")
ShortTS=$(date +"%m%d_%H%M")

if [[ -n ${VERBOSE} ]]
then
        Verbose=${True}
        VerboseOpt="-V"
else
        Verbose=${False}
        VerboseOpt=""
fi

# Script Defaults

LocalBin=${LocalBase}/bin

# Logs and Temporary files will go into the temporary directory.
LogDir=${LocalBase}/log
TmpDir=${LocalBase}/tmp

NotifyCmd="oranotify"

# Pass this option on to other scripts, so that they inherit same features
ConfigDirOpt="-C ${ConfigDir}"

# Failures by default have a severity of Critical
FailureSeverity="CRITICAL"

#-----------------------------------------------------------------------------
# Function   : ReportMsg
# Description: Handle all the reporting/logging of messages and errors
#              based on a severity level assigned to it.
#----------------------------------------------------------------------------
function ReportMsg
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && ${ECHO} "\nFunction: ReportMsg ${*}" >&2

        typeset MsgSev MsgText MsgFile MsgFileOpt

        Service=${ORACLE_SID-unknown}

        # Message Severity
        MsgSev="${1}"

        # Message Text
        MsgText="${2}"

        # Message File
        MsgFile="${3}"
        if [[ -f ${MsgFile} ]]
        then
                MsgFileOpt="-f ${MsgFile}"
        fi

        if [[ -n ${MsgSev} ]]
        then
                ${ECHO} "${MsgSev}: ${ScriptName}: ${Service}: ${MsgText}" >&2
                if [[ -x ${LocalBin}/${NotifyCmd} ]]
                then
                        ${LocalBin}/${NotifyCmd} -s ${Service} -l ${MsgSev} -n ${ScriptName} \
                                 -m "${MsgText}" ${MsgFileOpt} ${ConfigDirOpt} ${DebugOpt} ${VerboseOpt}
                fi
        else
                ${ECHO} "${ScriptName}: ${MsgText}" >&2
        fi

        if [[ -n ${MsgSev} && -f ${LogFile} ]]
        then
                ${ECHO} "${MsgSev}: ${ScriptName}: ${Service}: ${MsgText}" >> ${LogFile}
        elif [[ -f ${LogFile} ]]
        then
                ${ECHO} "${ScriptName}: ${Service}: ${MsgText}" >> ${LogFile}
        fi

        return

} # End of ReportMsg



#-----------------------------------------------------------------------------
# Name: ShowUsage
# Desc: Print usage syntax.
#-----------------------------------------------------------------------------
function ShowUsage
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && ${ECHO} "\nFunction: ShowUsage ${*}" >&2

        ${ECHO} "\nUSAGE: ${ScriptName} -s OracleSid -c Command [-C ConfigDir] [-D] [-V]" >&2
        ${ECHO} "\n   Where:" >&2
        ${ECHO} "      -s OracleSid     Name of the Oracle System Identifier" >&2
        ${ECHO} "      -c Command       Command(s) to perform" >&2
        ${ECHO} "                        START     = Start Managed Recovery" >&2
        ${ECHO} "                        STARTADG  = Starts Active Data Guard Mode" >&2
        ${ECHO} "                        STOP      = Stop Managed Recovery" >&2
        ${ECHO} "                        READONLY  = Stops Managed Recovery and places the" >&2
        ${ECHO} "                                    standby database in READ ONLY mode." >&2
        ${ECHO} "                        STATUS    = Reports the status of the standby database." >&2
        ${ECHO} " " >&2
        ${ECHO} "      -C ConfigDir      Alternate configuration file directory, default = /var/opt/oracle" >&2
        ${ECHO} "      -D                Turn on Debug mode for script" >&2
        ${ECHO} "      -V                Turn on Verbose mode for the script" >&2
        ${ECHO} "\n" >&2

        return

} # End of ShowUsage


#-----------------------------------------------------------------------------
# Function   : CleanupAndExit
# Description: Handles the cleanup of temp files.
#----------------------------------------------------------------------------
function CleanupAndExit
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && ${ECHO} "\nFunction: CleanupAndExit ${*}" >&2

        typeset ExitStatus=${1}

        # Clean Exit, Remove any temporary files, if not in debug mode
        if [[ ${Debug} = ${False} ]]
        then
         rm -f ${TrcFile} 2>/dev/null
                # rm -f ${TmpFile1} 2>/dev/null
                rm -f ${TmpFile2} 2>/dev/null
        fi

        exit ${ExitStatus}

} # End of CleanupAndExit



#-----------------------------------------------------------------------------
# Function   : ReadConfigFile
# Description: Read in the configuration file.  Configuration file is in the
#              format of:
#                 parameter [=] value
#              where parameter must begin in column 1 and start with an alpha
#              character.  The parameter is case insensitve and the equal
#              sign is optional.  The value can contain defined environment
#              variables, such as $ORACLE_SID which is defined by the script
#              itself before the configuration file is read.  For Example:
#                 TNS_ADMIN = /var/opt/oracle
#-----------------------------------------------------------------------------
function ReadConfigFile
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && ${ECHO} "\nFunction: ReadConfigFile ${*}" >&2

        typeset ConfigFile=${1}
        typeset Parameter
        typeset Value

        while read Line
        do
                Line=$(echo ${Line} | grep -i ^[a-z] | sed -e 's/=/ /')
                if [[ -z ${Line} ]]
                then
                        continue
                fi

                set -- ${Line}
                Parameter=$(echo ${1} | tr '[:lower:]' '[:upper:]')
                shift 1
                Value="${*}"

                case ${Parameter} in
                        LOCAL_BIN)
                                LocalBin="$(eval echo ${Value})"
                                export PATH=${PATH}:${LocalBin}
                                ;;
                        LOG_DIR)
                                LogDir="$(eval echo ${Value})"
                                ;;
                        *)
                                continue
                                ;;
                esac

        done < ${ConfigFile}

        return 0

} # End of ReadConfigFile


#-----------------------------------------------------------------------------
# Function   : RunSql
# Description: Run a SQL Command and leave output in the temp file, for the
#              calling routine to get, and set SqlError, if an error was
#              detected.
#-----------------------------------------------------------------------------
function RunSql
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && ${ECHO} "\nFunction: RunSql ${*}" >&2

        typeset SqlCommand="${*}"
        typeset SqlError

 ${ORACLE_HOME}/bin/sqlplus -silent /nolog <<-EOF > ${TmpFile1} 2>&1
                        SET SQLPROMPT "SQL> ";
                        CONNECT ${SqlConnect};
                        WHENEVER SQLERROR EXIT SQL.SQLCODE;
                        SET ECHO ON
                        SET LINESIZE 512
                        SET PAGESIZE 0
                        ${SqlCommand}
                        EXIT;
 EOF
        ExitStatus=${?}
        if (( ${ExitStatus} == 0 ))
        then
                egrep '(ORA-|ERROR:)' ${TmpFile1} > /dev/null 2>&1
                ExitStatus=${?}
                if (( ${ExitStatus} == 0 ))
                then
                        SqlError=1
                else
                        SqlError=0
                fi
        else
                SqlError=1
        fi

        # Append the tempfile to the scripts log file so that there is some
        # history for debuging.
        # ReportMsg "" "Instance Command and Output:\n${SqlCommand}" ${TmpFile1}

        return ${SqlError}

} # End of RunSql


#----------------------------------------------------------------------------
# Name: BeginRecovery
# Desc: Start managed recovery of the standby database.
#----------------------------------------------------------------------------
function BeginRecovery
{

        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && ${ECHO} "\nFunction: InstanceStartup ${*}" >&2

 InstanceStatus
 ProcCount=${?}
 if [ ${ProcCount} -eq 0 ]
 then
         RunSql "STARTUP MOUNT;"
         ExitStatus=${?}
         cat ${TmpFile1} >> ${TmpFile2} 2>&1
         if (( ${ExitStatus} != 0 ))
         then
                 ReportMsg "CRITICAL" "STARTUP MOUNT Command Failed"
                 return ${ExitStatus}
         fi
                RunSql "SELECT DATABASE_ROLE from V\$DATABASE;"
                ExitStatus=${?}
                if (( ${ExitStatus} != 0 ))
                then
                        ReportMsg "CRITICAL" "Check for DATABASE_ROLE Failed"
                        return ${ExitStatus}
                fi
                grep "^PRIMARY" ${TmpFile1} > ${SqlFile2} 2>/dev/null
                if [[ -s ${SqlFile2} ]]
                then
                        ReportMsg "" "Found DATABASE_ROLE=PRIMARY"
                        CleanupAndExit 0
                else
                        grep "^PHYSICAL STANDBY" ${TmpFile1} > ${SqlFile2} 2>/dev/null
                        if [[ -s ${SqlFile2} ]]
                        then
                                ReportMsg "" "Found DATABASE_ROLE=PHYSICAL STANDBY"
                                RunSql "SELECT GROUP#,THREAD#,SEQUENCE#,ARCHIVED,STATUS FROM V\$STANDBY_LOG;"
                                ExitStatus=${?}
                                cat ${TmpFile1} >> ${TmpFile2} 2>&1
                                if (( ${ExitStatus} != 0 ))
                                then
                                        ReportMsg "CRITICAL" "Determination of STANDBY LOG Failed"
                                        return ${ExitStatus}
                                fi
                                grep "no rows selected" ${TmpFile1} > ${SqlFile3} 2>/dev/null
                                if [[ -s ${SqlFile3} ]]
                                then
                                        ReportMsg "" "No Standby RedoLogs"
                                        RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE DISCONNECT FROM SESSION;"
                                else
                                        ReportMsg "" "Standby RedoLogs Found"
                                        RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE USING CURRENT LOGFILE DISCONNECT;"
                                fi
                        else
                                ReportMsg "CRITICAL" "Only PRIMARY and PHYSICAL STANDBY DATABASE_ROLE Supported"
                                return ${ExitStatus}
                        fi
                fi
 else
                RunSql "SELECT DATABASE_ROLE from V\$DATABASE;"
                ExitStatus=${?}
                if (( ${ExitStatus} != 0 ))
                then
                        ReportMsg "CRITICAL" "Check for DATABASE_ROLE Failed"
                        return ${ExitStatus}
                fi
                grep "^PRIMARY" ${TmpFile1} > ${SqlFile2} 2>/dev/null
                if [[ -s ${SqlFile2} ]]
                then
                        ReportMsg "" "Found DATABASE_ROLE=PRIMARY"
                        CleanupAndExit 0
                else
                        grep "^PHYSICAL STANDBY" ${TmpFile1} > ${SqlFile2} 2>/dev/null
                        if [[ -s ${SqlFile2} ]]
                        then
    RecoveryStatus
                         ProcCnt=${?}
                         if [ ${ProcCnt} -eq 0 ]
                         then
                                 ReportMsg "" "Found DATABASE_ROLE=PHYSICAL STANDBY"
                                 RunSql "SELECT GROUP#,THREAD#,SEQUENCE#,ARCHIVED,STATUS FROM V\$STANDBY_LOG;"
                                 ExitStatus=${?}
                                 cat ${TmpFile1} >> ${TmpFile2} 2>&1
                                 if (( ${ExitStatus} != 0 ))
                                 then
                                         ReportMsg "CRITICAL" "Determination of STANDBY LOG Failed"
                                         return ${ExitStatus}
                                 fi
                                 grep "no rows selected" ${TmpFile1} > ${SqlFile3} 2>/dev/null
                                 if [[ -s ${SqlFile3} ]]
                                 then
                                         ReportMsg "" "No Standby RedoLogs"
                                         RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE DISCONNECT FROM SESSION;"
                                 else
                                         ReportMsg "" "Standby RedoLogs Found"
                                         RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE USING CURRENT LOGFILE DISCONNECT;"
                                 fi
    else
     ReportMsg "" "Managed Recovery is Currently Running"
    fi
                        else
                                ReportMsg "CRITICAL" "Only PRIMARY and PHYSICAL STANDBY DATABASE_ROLE Supported"
                                return ${ExitStatus}
                        fi
                fi
 fi

 return


} # End of BeginRecovery


#----------------------------------------------------------------------------
# Name: SuspendRecovery
# Desc: Stop managed recovery of the standby database.
#----------------------------------------------------------------------------
function SuspendRecovery
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && ${ECHO} "\nFunction: SuspendRecovery ${*}" >&2

        RecoveryStatus
        ProcCnt=${?}
        if [ ${ProcCnt} -eq 0 ]
        then
  ReportMsg "" "Recovery Status : Managed Recovery Stopped"
 else
  ReportMsg "" "Stopping Managed Recovery of Standby Database: ${ORACLE_SID}"
  RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE CANCEL;"
  ExitStatus=${?}
 fi

 return

} # End of SuspendRecovery


#----------------------------------------------------------------------------
# Name: BeginReadonly
# Desc: Place the standby database in "READ ONLY" mode.
#----------------------------------------------------------------------------
function BeginReadonly
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && ${ECHO} "\nFunction: BeginRecovery ${*}" >&2

 InstanceStatus
 ProcCount=${?}
 if [ ${ProcCount} -eq 0 ]
 then
  RunSql "STARTUP NOMOUNT;
   ALTER DATABASE MOUNT STANDBY DATABASE;"
  ExitStatus=${?}
  if (( ${ExitStatus} != 0 ))
  then
   ReportMsg "" "MOUNT STANDBY DATABASE Command Failed"
   return ${ExitStatus}
  fi
  ReportMsg "" "Placing Standby Database ${ORACLE_SID} in READ ONLY mode"
  RunSql "ALTER DATABASE OPEN READ ONLY;"
  ExitStatus=${?}
 else
  RecoveryStatus
  ProcCnt=${?}
  if [ ${ProcCnt} -eq 0 ]
  then
   ReportMsg "" "Placing Standby Database ${ORACLE_SID} in READ ONLY mode"
   RunSql "ALTER DATABASE OPEN READ ONLY;"
   ExitStatus=${?}
  else
   SuspendRecovery
   sleep 20
   ReportMsg "" "Placing Standby Database ${ORACLE_SID} in READ ONLY mode"
   RunSql "ALTER DATABASE OPEN READ ONLY;"
   ExitStatus=${?}
  fi
 fi

 return

} # End of BeginReadonly

#----------------------------------------------------------------------------
# Name: BeginADG
# Desc: Place the standby database in "READ ONLY" mode.
#----------------------------------------------------------------------------
function BeginADG
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && ${ECHO} "\nFunction: BeginRecovery ${*}" >&2

        InstanceStatus
        ProcCount=${?}
        if [ ${ProcCount} -eq 0 ]
        then
                RunSql "STARTUP;"
                ExitStatus=${?}
                if (( ${ExitStatus} != 0 ))
                then
                        ReportMsg "" "STARTING ADG FOR STANDBY DATABASE Command Failed"
                        return ${ExitStatus}
                fi
                ReportMsg "" "Placing Standby Database ${ORACLE_SID} in ADG mode"
  RunSql "SELECT GROUP#,THREAD#,SEQUENCE#,ARCHIVED,STATUS FROM V\$STANDBY_LOG;"
                ExitStatus=${?}
                cat ${TmpFile1} >> ${TmpFile2} 2>&1
                if (( ${ExitStatus} != 0 ))
                then
                   ReportMsg "CRITICAL" "Determination of STANDBY LOG Failed"
                   return ${ExitStatus}
                fi
                grep "no rows selected" ${TmpFile1} > ${SqlFile3} 2>/dev/null
                if [[ -s ${SqlFile3} ]]
                then
                   ReportMsg "" "No Standby RedoLogs"
                   RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE DISCONNECT FROM SESSION;"
                else
                 ReportMsg "" "Standby RedoLogs Found"
                 RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE USING CURRENT LOGFILE DISCONNECT;"
                fi
                ExitStatus=${?}
  else
                RecoveryStatus
                ProcCnt=${?}
                if [ ${ProcCnt} -eq 0 ]
                then
  # check which mode recovery is running
                 RunSql "SELECT OPEN_MODE FROM V\$DATABASE;"
   ExitStatus=${?}
           grep "MOUNTED" ${TmpFile1} > ${SqlFile2} 2>/dev/null
                 if [[ -s ${SqlFile2} ]]
                 then
                        ReportMsg "" "Standby Database ${ORACLE_SID} is in MOUNT mode"
                        ReportMsg "" "Placing Standby Database ${ORACLE_SID} in ADG mode"
   RunSql "ALTER DATABASE OPEN;"
          RunSql "SELECT GROUP#,THREAD#,SEQUENCE#,ARCHIVED,STATUS FROM V\$STANDBY_LOG;"
                 ExitStatus=${?}
                  cat ${TmpFile1} >> ${TmpFile2} 2>&1
                  if (( ${ExitStatus} != 0 ))
                  then
                     ReportMsg "CRITICAL" "Determination of STANDBY LOG Failed"
                     return ${ExitStatus}
                  fi
                  grep "no rows selected" ${TmpFile1} > ${SqlFile3} 2>/dev/null
                  if [[ -s ${SqlFile3} ]]
                  then
                      ReportMsg "" "No Standby RedoLogs"
                      RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE DISCONNECT FROM SESSION;"
                  else
                          ReportMsg "" "Standby RedoLogs Found"
                          RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE USING CURRENT LOGFILE DISCONNECT;"
                  fi
                        ExitStatus=${?}
   else
                  # recovery is not running but database is in READ ONLY MODE
echo "recovery is not running but database is in READ ONLY MODE"
          ReportMsg "" "Placing Standby Database ${ORACLE_SID} in ADG mode"
                        RunSql "SELECT GROUP#,THREAD#,SEQUENCE#,ARCHIVED,STATUS FROM V\$STANDBY_LOG;"
                        ExitStatus=${?}
                         cat ${TmpFile1} >> ${TmpFile2} 2>&1
                         if (( ${ExitStatus} != 0 ))
                         then
                                ReportMsg "CRITICAL" "Determination of STANDBY LOG Failed"
                                return ${ExitStatus}
                         fi
                         grep "no rows selected" ${TmpFile1} > ${SqlFile3} 2>/dev/null
                         if [[ -s ${SqlFile3} ]]
                         then
                          ReportMsg "" "No Standby RedoLogs"
                          RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE DISCONNECT FROM SESSION;"
                         else
                          ReportMsg "" "Standby RedoLogs Found"
                          RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE USING CURRENT LOGFILE DISCONNECT;"
                         fi
                        ExitStatus=${?}
                 fi
                else
                  RunSql "SELECT OPEN_MODE FROM V\$DATABASE;"
                 ExitStatus=${?}
                 grep "MOUNTED" ${TmpFile1} > ${SqlFile3} 2>/dev/null
                 if [[ -s ${SqlFile3} ]]
                 then
   ReportMsg "" "Standby Database ${ORACLE_SID} is MOUNTED"
   ReportMsg "" "Placing Standby Database ${ORACLE_SID} in ADG mode"
                        RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE CANCEL;"
                        RunSql "ALTER DATABASE OPEN;"
   RunSql "SELECT GROUP#,THREAD#,SEQUENCE#,ARCHIVED,STATUS FROM V\$STANDBY_LOG;"
                        ExitStatus=${?}
                         cat ${TmpFile1} >> ${TmpFile2} 2>&1
                         if (( ${ExitStatus} != 0 ))
                         then
                                ReportMsg "CRITICAL" "Determination of STANDBY LOG Failed"
                                return ${ExitStatus}
                         fi
                         grep "no rows selected" ${TmpFile1} > ${SqlFile3} 2>/dev/null
                         if [[ -s ${SqlFile3} ]]
                         then
                          ReportMsg "" "No Standby RedoLogs"
                          RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE DISCONNECT FROM SESSION;"
                         else
                          ReportMsg "" "Standby RedoLogs Found"
                          RunSql "ALTER DATABASE RECOVER MANAGED STANDBY DATABASE USING CURRENT LOGFILE DISCONNECT;"
                         fi
                        ExitStatus=${?}
                 else
                        ReportMsg "" "Standby Database ${ORACLE_SID} is already in ADG mode. Exiting.."
   CleanupAndExit 0
                 fi
                fi
        fi

        return

} # End of BeginADG


#----------------------------------------------------------------------------
# Name: CheckRecoveryStatus
# Desc: Check the status of the database and see if managed recovery is running
#----------------------------------------------------------------------------
function CheckRecoveryStatus
{

        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && ${ECHO} "\nFunction: CheckRecoveryStatus ${*}" >&2


        # Check the Status of the Standby Instance
        InstanceStatus
        ProcCount=${?}
        if [ ${ProcCount} -eq 0 ]
        then
                ReportMsg "" "Database Status : Not Running"
                ReportMsg "" "Recovery Status : Recovery Stopped"
                CleanupAndExit 0
        fi

        RecoveryStatus
        ProcCnt=${?}
        if [ ${ProcCnt} -eq 1 ]
        then
                ReportMsg "" "Recovery Status : Recovery Running"
        else
                ReportMsg "" "Recovery Status : Recovery Stopped"
        fi

        return

} # End of CheckRecoveryStatus


#-----------------------------------------------------------------------------
# Function   : InstanceStatus
# Description: Check for the required 4 Oracle background processes; pmon,
#              dbwr, lgwr, and smon.
#-----------------------------------------------------------------------------
function InstanceStatus
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && ${ECHO} "\nFunction: InstanceStatus ${*}" >&2

        typeset Procs Proc Result
        typeset ProcCount=0

        Procs=$(ps -fe 2>/dev/null | cut -c1-132 | sed -e 's/ *$//' | grep -v grep | \
                egrep "ora_pmo._${ORACLE_SID}\$|ora_dbw._${ORACLE_SID}\$|ora_lgw._${ORACLE_SID}\$|ora_smo._${ORACLE_SID}\$")
        for Proc in pmo dbw lgw smo
        do
                echo ${Procs} | grep "ora_${Proc}._${ORACLE_SID}" >/dev/null 2>&1
                Result=${?}
                if (( ${Result} == 0 ))
                then
                        (( ProcCount = ProcCount + 1 ))
                fi
        done

        return ${ProcCount}

} # End of InstanceStatus



#-----------------------------------------------------------------------------
# Function   : RecoveryStatus
# Description: Check for the required Oracle background processes; mrp
#-----------------------------------------------------------------------------
function RecoveryStatus
{
        [[ ${Debug} = ${True} ]] && set -xv
        [[ ${Verbose} = ${True} ]] && ${ECHO} "\nFunction: RecoveryStatus ${*}" >&2

        typeset Procs Proc Result
        typeset ProcCnt=0

        Procs=$(ps -fe 2>/dev/null | cut -c1-132 | sed -e 's/ *$//' | grep -v grep | \
                egrep "ora_mrp._${ORACLE_SID}\$")

        for Proc in mrp
        do
                echo ${Procs} | grep "ora_${Proc}._${ORACLE_SID}" >/dev/null 2>&1
                Result=${?}
                if (( ${Result} == 0 ))
                then
                        (( ProcCnt = ProcCnt + 1 ))
                fi
        done

        return ${ProcCnt}

} # End of RecoveryStatus


#-----------------------------------------------------------------------------
# Parse options and arguments from command line.
#-----------------------------------------------------------------------------
typeset OptCount=0
typeset Option
while getopts :s:c:C:DV OPT
do
 (( OptCount = OptCount + 1 ))
 case ${OPT} in
  s) # Oracle System Identifier
   OracleSid=${OPTARG}
   ;;
  c) # Command to perform
   Command="$(echo ${OPTARG} | tr '[:upper:]' '[:lower:]')"
   ;;
                C)      # Change Default Configuration Directory
                        ConfigDir=${OPTARG}
                        ConfigDirOpt="-C ${ConfigDir}"
                        ;;
                D)      # Turn Shell Debug mode on
                        set -xv
                        Debug=${True}
                        DebugOpt="-D"
                        ;;
                V)      # Turn Verbose mode on
                        Verbose=${True}
                        VerboseOpt="-V"
                        ;;
  :) # Missing Argument
   ReportMsg "WARNING" "Argument missing for option: ${OPTARG}"
   ShowUsage
   CleanupAndExit 1
   ;;
  \?) # Invalid Option
   ReportMsg "WARNING" "Invalid option: ${OPTARG}"
   ShowUsage
   CleanupAndExit 1
   ;;
 esac
done

# Shift the options off the command line, leaving any remaining arguments.
shift $((${OPTIND} - 1))

# No other options should remain, if they do report a usage error
if (( ${#} > 0 ))
then
 ReportMsg "WARNING" "Invalid arguments on the command line!"
 ShowUsage
 CleanupAndExit 1
fi

if (( ${OptCount} == 0 ))
then
 ReportMsg "" "Missing one or more required options!"
 ShowUsage
 CleanupAndExit 1
fi


#-----------------------------------------------------------------------------
# Verify remaining options and arguments specifed are correct.
#-----------------------------------------------------------------------------
if [[ -z ${OracleSid} ]]
then
        ReportMsg "" "ORACLE_SID option is required!"
        ShowUsage
        CleanupAndExit 1
else
        ORACLE_SID=${OracleSid}
        # Export it for user exit scripts
        export ORACLE_SID
fi

if [[ -z ${Command} ]]
then
        ReportMsg "" "Command option is required!"
        ShowUsage
        CleanupAndExit 1
fi

if [[ -f ${LocalBin}/oraprof ]]
then
        . ${LocalBin}/oraprof ${ORACLE_SID}
        if (( ${oraenv_rc} != 0 ))
        then
                ReportMsg "${FailureSeverity}" "Environment setup script failed: ${LocalBin}/oraprof ${ORACLE_SID}"
                CleanupAndExit 1
        fi
else
        ReportMsg "${FailureSeverity}" "Environment setup script not found: ${LocalBin}/oraprof"
        CleanupAndExit 1
fi

#---------------------------------------------------------------------
# Read in the configuraton files
#---------------------------------------------------------------------
#---------------------------------------------------------------------
# Check for System Global configuration file first.
if [[ -r ${ConfigDir}/global.cfg ]]
then
        ReadConfigFile ${ConfigDir}/global.cfg
fi

# If we have a Instance configuration file read it and let its values
# override the ones from the Global and Owner configuration files
if [[ -r ${ConfigDir}/instance_${ORACLE_SID}.cfg ]]
then
        ReadConfigFile ${ConfigDir}/instance_${ORACLE_SID}.cfg
fi

# Log File Directory
LogDir=${RCLogDir-${LogDir}}
if [[ ! -d ${LogDir} ]]
then
        mkdir -p ${LogDir}
        rc=${?}
        if (( ${rc} != 0 )) || [[ ! -w ${LogDir} ]]
        then
                LogDir=/tmp
        fi
fi

LogFile=${LogDir}/${ScriptName}_${ORACLE_SID}_${DateTime}.log

# Temporary File Directory
TmpDir=${RCTmpDir-${TmpDir}}
if [[ ! -d ${TmpDir} ]]
then
        mkdir -p ${TmpDir}
        rc=${?}
        if (( ${rc} != 0 )) || [[ ! -w ${TmpDir} ]]
        then
                TmpDir=/tmp
        fi
fi

TmpFile1=${TmpDir}/${ScriptName}_${ORACLE_SID}_${ShortTS}_${Pid}_1.tmp
TmpFile2=${TmpDir}/${ScriptName}_${ORACLE_SID}_${ShortTS}_${Pid}_2.tmp
TmpFile3=${TmpDir}/${ScriptName}_${ORACLE_SID}_${ShortTS}_${Pid}_3.tmp

TempFile=${TmpDir}/${ScriptName}_${ORACLE_SID}_${ShortTS}.tmp

# Temporary File for SQL Scripts
SqlFile1=${TmpDir}/${ScriptName}_${ORACLE_SID}_${ShortTS}_${Pid}_1.sql
# R3.14 need temp files for database role and standby logfiles
SqlFile2=${TmpDir}/${ScriptName}_${ORACLE_SID}_${ShortTS}_${Pid}_2.sql
SqlFile3=${TmpDir}/${ScriptName}_${ORACLE_SID}_${ShortTS}_${Pid}_3.sql
SqlFile4=${TmpDir}/${ScriptName}_${ORACLE_SID}_${ShortTS}_${Pid}_4.sql
SqlFile5=${TmpDir}/${ScriptName}_${ORACLE_SID}_${ShortTS}_${Pid}_5.sql

# Trace File
TrcFile=${LogDir}/${ScriptName}_${ORACLE_SID}_${DateTime}.trc
if [[ ${Verbose} = ${True} ]]
then
        ${ECHO} "TrcFile: ${TrcFile}"
fi

Release=$(${ORACLE_HOME}/bin/sqlplus -? 2>&1 | grep Release | awk '{print $3}' | sed -e 's/^3\./7./')
if [[ -n ${Release} ]]
then
        Release=$(echo ${Release} | sed -e 's/\./ /g' | awk '{print $1"."$2"."$3}')
else
        ReportMsg "${FailureSeverity}" "Unable to determine Oracle Release for ${ORACLE_SID}"
        CleanupAndExit 1
fi

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
# Main Script Logic
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
ExitStatus=0
ReturnCode=0
ExitCode=0
SqlError=0
SqlConnect="/ as sysdba"

 ReportMsg "" ""
 ReportMsg "" "ORACLE_SID   : ${ORACLE_SID}"
 ReportMsg "" "Command      : ${Command}"

 case ${Command} in
  start)
   BeginRecovery
   ;;
  stop)
   SuspendRecovery
   ;;
  readonly)
   BeginReadonly
   ;;
  startadg)
                        BeginADG
                        ;;
  status)
   CheckRecoveryStatus
   ;;
  *)
   ReportMsg "${FailureSeverity}" "Command Invalid: ${Command}"
   ShowUsage
   CleanupAndExit 1
   ;;
 esac

CleanupAndExit ${ExitStatus}

#-----------------------------------------------------------------------------
# Revision History:
#
# $Log$
# Revision 1.9  2014/03/17 11:58:57  jt7190
# Updated oradgmanagedreco script per Olgas changes to correct issue with previous release.
#
# Revision 1.8  2014/01/21 15:39:38  jt7190
# Olga Pogostkina-updated to fixed the bug to start Active Data Guard correctly when standby is already mounted and recovery is in progress.  Process: to stop the recovery, open database, start recovery.
#
# Revision 1.7  2012/05/17 20:58:54  jt7190
#
# updated startdg comments and syntax display.
#
# Revision 1.6  2012/03/05 21:50:05  jt7190
#
# Update to start active guard database in ReadOnly mode, changes by Olga Pogostkina.
#
# Revision 1.5  2011/03/10 21:34:07  jt7190
#
# 1) Modified oradgdelarcs to delete archivelogs with a single statement.
# 2) Added additional check for vtier env to /opt/app/<username>/oracle/local/etc.
#
# Revision 1.4  2010/06/04 14:46:59  jt7190
# changed name from orachkdgreco to oradgchkreco
#
# Revision 1.3  2010/06/04 12:27:14  jt7190
# Include Steve Merz's changes to oradgmanagedreco for vtier envs and DGB.
#
# Revision 1.2  2010/06/02 16:40:31  jt7190
# adding history comments.

t1enb1d4@bltd122(580) t1enb1d41 /opt/app/t1enb1d4/oracle/local/bin











