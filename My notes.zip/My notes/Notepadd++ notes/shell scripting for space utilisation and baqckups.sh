Rman level 0 backup


t1enb1d4@bltd122(563) t1enb1d41 /opt/app/t1enb1d4/oracle/local/log


$ cat /opt/app/t1enb1d4/oracle/local/bin/orachkrun
#! /bin/ksh
#$Id$
#-----------------------------------------------------------------------------
# Project Name : Oracle Utilites
# Script Name  : chkrun
# Description  : This is a wrapper script used to execute other scripts that
#                expect the database to be up and running.  This script
#                simplely checks to see if the database appears to be running
#                and then executes the provided command and returns its exit
#                status code.  If the database is not running, it exits
#                quietly.  This script does not perform any redirection of
#                stdout or stderr.  It was designed for use in fail-over
#                configurations where the database may or may not be running
#                on the current node.
#
# Usage        : chkrun ORACLE_SID command
#
# CRON Example :
# 0 22 * * *   $HOME/local/bin/chkrun ostl41 $HOME/local/bin/orabkupdb -s ostl41 -t COLD >> $HOME/orabkupdb_ostl41.out 2>&1
# 0,30 * * * * $HOME/local/bin/chkrun ostl41 $HOME/local/bin/runbkuplog -s ostl41 >> $HOME/runbkuplog_ostl41.out 2>&1
#
# Revision History: At end of script
#-----------------------------------------------------------------------------
set +u
PATH=/bin:/usr/bin export PATH

ScriptName=`basename ${0}`

OS_NAME=`uname -s | tr '[:lower:]' '[:upper:]'`
export OS_NAME

# Set variables base on operating system.
case ${OS_NAME} in
        HP-UX)
                ID="/usr/bin/id -un"
                ;;
        AIX)
                ID="/usr/bin/id -un"
                ;;
        SUNOS)
                ID="/usr/xpg4/bin/id -un"
                ;;
        LINUX)
                ID="/usr/bin/id -un"
                ;;
        *)
                ;;
esac

# Add Oracle's Local Bin to the PATH
# Current users name
UserName=`${ID}`

if [[ -d /opt/app/${UserName} ]]
then
        export LOCAL_BASE=/opt/app/${UserName}/oracle/local
elif [[ -d /pac/${UserName}/app ]]
then
        export LOCAL_BASE=/pac/${UserName}/app/oracle/local
else
        export LOCAL_BASE=${HOME}/local
fi


# For Oracle 11g, ORACLE_BASE needs to be set
if [[ -d /opt/app/${UserName} ]]
then
        export ORACLE_BASE=/opt/app/${UserName}/oracle
elif [[ -d /pac/${UserName}/app ]]
then
        export ORACLE_BASE=/pac/${UserName}/app/oracle
else
        export ORACLE_BASE=${HOME}
fi


LocalBin=${LOCAL_BASE}/bin
PATH=$PATH:${LocalBin} export PATH


if [ ${#} -lt 2 ]
then
        echo "USAGE: ${ScriptName} ORACLE_SID Command" >&2
        exit 1
fi

OraSid=${1}
shift 1
Command=${*}

if [ ! -r "${LocalBin}/oraprof" ]
then
        echo "ERROR: ${ScriptName}: ${LocalBin}/oraprof File Not Found or Not Readable!" >&2
        exit 1
fi

. ${LocalBin}/oraprof ${OraSid}

if [[ -z "${ORACLE_SID}" || "${ORACLE_SID}" != "${OraSid}" ]]
then
        echo "ERROR: ${ScriptName}: ORACLE_SID: ${OraSid} Not Found!" >&2
        exit 1
fi


# Check to see if main 4 database background processes and INIT.ORA file
# are found, if so assume database is up and running.
ProcCount=0
Procs=`ps -fe 2>/dev/null | cut -c1-132 | sed -e 's/ *$//' | grep -v grep | \
        egrep "ora_pmo._${OraSid}\$|ora_dbw._${OraSid}\$|ora_lgw._${OraSid}\$|ora_smo._${OraSid}"'$'`
# Found bug with trailing dollar sign in sub-shell, single quote last dollar sign
for Proc in pmo dbw lgw smo
do
        echo ${Procs} | grep "ora_${Proc}._${OraSid}" >/dev/null 2>&1
        Result=${?}
        if [ ${Result} -eq 0 ]
        then
                let ProcCount=${ProcCount}+1
        fi
done
if [ ${ProcCount} -eq 4 -a -f ${ORACLE_HOME}/dbs/init${ORACLE_SID}.ora ]
then
        eval ${Command}
        ExitStatus=${?}
else
        ExitStatus=0
fi

exit ${ExitStatus}
#
#-----------------------------------------------------------------------------
# Revision History:
#
#$Log$
#Revision 1.6  2008/03/31 15:04:30  cm5933
#Fix .ne syntax
#
#Revision 1.5  2008/03/27 01:52:52  cm5933
#change local_base and oracle_base to match new /opt/app format
#
#Revision 1.4  2008/03/11 23:22:15  cm5933
#Update script for SIS environment
#
#Revision 1.3  2004/07/12 19:57:09  js8335
#Corrected procedure to determine $HOME/local/bin for WLM.
#Moved log file to bottom.
#
#Revision 1.2  2003/01/21 17:52:11  oracle
#Added /bin to path.
#
#Revision 1.1  2003/01/21 17:28:25  oracle
#Initial revision
#
# Name        Date      Change Description
# ----------  --------  ------------------------------------------------------
# M. Roth     06/25/02  Fixed check for background processes, short SID Name
#                       that is prefix of longer SID gave false results
# M. Roth     11/21/01  Added a cut of long lines from the ps commend before
#                       trying to grep through them.
# M. Roth     05/15/00  Removed the check for the sgadef*.dbf file, because
# M. Roth     09/04/98  Initial version
#--------------------------------------------------------------------------